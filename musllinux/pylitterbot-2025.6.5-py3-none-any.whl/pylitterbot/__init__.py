"""pylitterbot module."""

from ._version import __version__  # noqa: F401
from .account import Account
from .pet import Pet
from .robot import Robot
from .robot.feederrobot import FeederRobot
from .robot.litterrobot import LitterRobot
from .robot.litterrobot3 import LitterRobot3
from .robot.litterrobot4 import LitterRobot4
from .robot.litterrobot5 import LitterRobot5

__all__ = [
    "Account",
    "Robot",
    "LitterRobot",
    "LitterRobot3",
    "LitterRobot4",
    "LitterRobot5",
    "FeederRobot",
    "Pet",
]
