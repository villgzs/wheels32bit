# -*- coding: UTF-8 -*-

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from socket import create_connection, socket
from ssl import SSLContext
from typing import TypedDict

from librouteros.api import Api, AsyncApi
from librouteros.connections import AsyncSocketTransport, SocketTransport
from librouteros.exceptions import ConnectionClosed, FatalError
from librouteros.login import (
    async_plain,
    async_token,  # noqa F401
    plain,
    token,  # noqa F401
)
from librouteros.protocol import ApiProtocol, AsyncApiProtocol


class ConnectKwargs(TypedDict, total=False):
    timeout: float
    port: int
    saddr: str | None
    subclass: type[Api]
    encoding: str
    ssl_wrapper: Callable[[socket], socket] | None
    login_method: Callable[[Api, str, str], None]


class AsyncConnectKwargs(TypedDict, total=False):
    timeout: float
    port: int
    saddr: str | None
    subclass: type[AsyncApi]
    encoding: str
    ssl_wrapper: SSLContext | None
    login_method: Callable[[AsyncApi, str, str], Awaitable[None]]


DEFAULTS: ConnectKwargs = {
    "timeout": 10,
    "port": 8728,
    "saddr": None,
    "subclass": Api,
    "encoding": "ASCII",
    "ssl_wrapper": None,
    "login_method": plain,
}

ASYNC_DEFAULTS: AsyncConnectKwargs = {
    "timeout": 10,
    "port": 8728,
    "saddr": None,
    "subclass": AsyncApi,
    "encoding": "ASCII",
    "ssl_wrapper": None,
    "login_method": async_plain,
}


def connect(
    host: str,
    username: str,
    password: str,
    *,
    timeout: float = DEFAULTS["timeout"],
    port: int = DEFAULTS["port"],
    saddr: str | None = DEFAULTS["saddr"],
    subclass: type[Api] = DEFAULTS["subclass"],
    encoding: str = DEFAULTS["encoding"],
    ssl_wrapper: Callable[[socket], socket] | None = DEFAULTS["ssl_wrapper"],
    login_method: Callable[[Api, str, str], None] = DEFAULTS["login_method"],
) -> Api:
    """
    Connect and login to routeros device.
    Upon success return an Api class.

    :param host: Hostname to connect to. May be ipv4,ipv6,FQDN.
    :param username: Username to login with.
    :param password: Password to login with. Only ASCII characters allowed.
    :param timeout: Socket timeout. Defaults to 10.
    :param port: Destination port to be used. Defaults to 8728.
    :param saddr: Source address to bind to.
    :param subclass: Subclass of Api class. Defaults to Api class from library.
    :param encoding: String encoding to use.
    :param ssl_wrapper: Callable (e.g. ssl.SSLContext.wrap_socket()) to wrap socket with.
    :param login_method: Callable with login method.
    """
    transport: SocketTransport = create_transport(
        host=host, port=port, saddr=saddr, timeout=timeout, ssl_wrapper=ssl_wrapper
    )
    protocol: ApiProtocol = ApiProtocol(transport=transport, encoding=encoding)
    api: Api = subclass(protocol=protocol)

    try:
        login_method(api, username, password)
        return api
    except (ConnectionClosed, FatalError):
        transport.close()
        raise


async def async_connect(
    host: str,
    username: str,
    password: str,
    *,
    timeout: float = ASYNC_DEFAULTS["timeout"],
    port: int = ASYNC_DEFAULTS["port"],
    saddr: str | None = ASYNC_DEFAULTS["saddr"],
    subclass: type[AsyncApi] = ASYNC_DEFAULTS["subclass"],
    encoding: str = ASYNC_DEFAULTS["encoding"],
    ssl_wrapper: SSLContext | None = ASYNC_DEFAULTS["ssl_wrapper"],
    login_method: Callable[[AsyncApi, str, str], Awaitable[None]] = ASYNC_DEFAULTS["login_method"],
) -> AsyncApi:
    """
    Connect and login to routeros device.
    Upon success return an AsyncApi class.

    :param host: Hostname to connect to. May be ipv4,ipv6,FQDN.
    :param username: Username to login with.
    :param password: Password to login with. Only ASCII characters allowed.
    :param timeout: Socket timeout. Defaults to 10.
    :param port: Destination port to be used. Defaults to 8728.
    :param saddr: Source address to bind to.
    :param subclass: Subclass of AsyncApi class. Defaults to AsyncApi class from library.
    :param encoding: String encoding to use.
    :param ssl_wrapper: ssl.SSLContext instance to wrap socket with.
    :param login_method: Coroutine with login method.
    """
    transport: AsyncSocketTransport = await async_create_transport(
        host=host, port=port, saddr=saddr, timeout=timeout, ssl_wrapper=ssl_wrapper
    )
    protocol: AsyncApiProtocol = AsyncApiProtocol(transport=transport, encoding=encoding, timeout=timeout)
    api: AsyncApi = subclass(protocol=protocol)

    try:
        await login_method(api, username, password)
        return api
    except (ConnectionClosed, FatalError):
        await transport.close()
        raise


def create_transport(
    host: str,
    *,
    port: int,
    saddr: str | None,
    timeout: float,
    ssl_wrapper: Callable[[socket], socket] | None = None,
) -> SocketTransport:
    sock: socket = create_connection(
        (host, port),
        timeout=timeout,
        source_address=(saddr, 0) if saddr is not None else None,
    )
    if ssl_wrapper:
        sock = ssl_wrapper(sock)
    return SocketTransport(sock=sock)


async def async_create_transport(
    host: str,
    *,
    port: int,
    saddr: str | None,
    timeout: float,
    ssl_wrapper: SSLContext | None = None,
) -> AsyncSocketTransport:
    reader, writer = await asyncio.wait_for(
        asyncio.open_connection(
            host=host,
            port=port,
            ssl=ssl_wrapper,
            local_addr=(saddr, 0) if saddr is not None else None,
        ),
        timeout=timeout,
    )
    return AsyncSocketTransport(reader=reader, writer=writer)
