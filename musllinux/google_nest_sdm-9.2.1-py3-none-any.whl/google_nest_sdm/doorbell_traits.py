"""Traits belonging to doorbell devices."""

import logging
from dataclasses import dataclass
from typing import ClassVar

from .event import DoorbellChimeEvent, EventType
from .traits import BaseTrait, TraitType

_LOGGER = logging.getLogger(__name__)


@dataclass
class DoorbellChimeTrait(BaseTrait):
    """For any device that supports a doorbell chime and related press events."""

    NAME: ClassVar[TraitType] = TraitType.DOORBELL_CHIME
    EVENT_NAME: ClassVar[EventType] = DoorbellChimeEvent.NAME
