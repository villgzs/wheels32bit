"""Define utilities."""
