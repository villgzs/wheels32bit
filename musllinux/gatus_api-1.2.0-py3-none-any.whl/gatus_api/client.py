import asyncio
import base64
from typing import Any
import aiohttp

from .models import EndpointStatus, Event, Result


class GatusClientError(Exception):
    """Base exception for Gatus Client."""
    pass


class GatusAuthError(GatusClientError):
    """Exception raised when authentication fails (401/403)."""
    pass


class GatusClient:
    """Asynchronous client for interacting with the Gatus API."""

    def __init__(
        self,
        url: str,
        session: aiohttp.ClientSession,
        username: str | None = None,
        password: str | None = None,
        token: str | None = None,
    ) -> None:
        """Initialize the Gatus API client."""
        self.url = url.rstrip("/")
        self.session = session
        self.username = username
        self.password = password
        self.token = token

    def _get_headers(self) -> dict[str, str]:
        """Return custom headers (e.g. BasicAuth, Bearer token) if provided."""
        headers: dict[str, str] = {}
        if self.username is not None and self.password is not None:
            auth_str = f"{self.username}:{self.password}"
            encoded = base64.b64encode(auth_str.encode("utf-8")).decode("utf-8")
            headers["Authorization"] = f"Basic {encoded}"
        elif self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    async def get_endpoints_statuses(self) -> list[EndpointStatus]:
        """Fetch endpoint statuses from Gatus."""
        api_url = f"{self.url}/api/v1/endpoints/statuses"
        headers = self._get_headers()

        try:
            async with asyncio.timeout(10):
                async with self.session.get(
                    api_url, headers=headers or None
                ) as response:
                    if response.status in (401, 403):
                        raise GatusAuthError(
                            f"Gatus API returned authentication failure status code {response.status}"
                        )
                    if response.status != 200:
                        raise GatusClientError(
                            f"Gatus API returned status code {response.status}"
                        )

                    data = await response.json()
                    if not isinstance(data, list):
                        raise GatusClientError(
                            "Gatus API response was not in the expected array format"
                        )
                    return [
                        EndpointStatus(
                            key=ep["key"],
                            name=ep["name"],
                            group=ep.get("group"),
                            results=[
                                Result(
                                    success=r["success"],
                                    status=r.get("status"),
                                    duration=r.get("duration"),
                                    certificate_expiration=r.get("certificateExpiration"),
                                    domain_expiration=r.get("domainExpiration"),
                                    dns_rcode=r.get("dnsRcode"),
                                    hostname=r.get("hostname"),
                                    ip=r.get("ip"),
                                )
                                for r in ep.get("results", [])
                            ],
                            events=[
                                Event(
                                    type=ev["type"],
                                    timestamp=ev.get("timestamp"),
                                )
                                for ev in ep.get("events", [])
                            ],
                        )
                        for ep in data
                    ]
        except (aiohttp.ClientError, TimeoutError) as err:
            raise GatusClientError(f"Error communicating with Gatus API: {err}") from err
