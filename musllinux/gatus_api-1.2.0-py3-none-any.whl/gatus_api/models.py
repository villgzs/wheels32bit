"""Models for Gatus API."""

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Event:
    """Representation of an endpoint event (e.g., status change)."""

    type: str
    timestamp: str | None = None


@dataclass(frozen=True)
class Result:
    """Representation of an endpoint check result."""

    success: bool
    status: int | None = None
    duration: int | None = None
    certificate_expiration: int | None = None
    domain_expiration: int | None = None
    dns_rcode: str | None = None
    hostname: str | None = None
    ip: str | None = None


@dataclass(frozen=True)
class EndpointStatus:
    """Representation of an endpoint status."""

    key: str
    name: str
    group: str | None
    results: list[Result] = field(default_factory=list)
    events: list[Event] = field(default_factory=list)
