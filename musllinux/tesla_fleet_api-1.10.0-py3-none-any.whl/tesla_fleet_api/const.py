"""Tesla Fleet API constants."""

import logging
from enum import Enum
from typing import Literal, TypeGuard

LOGGER = logging.getLogger(__package__)

Region = Literal["na", "eu", "cn"]

# BLE command-confirmation ladder depth: "optimistic" skips reply waits after a
# confirmed write, "ack" waits for an addressed ack or a matching state
# broadcast, "verify" additionally reads back state on an ack/broadcast timeout.
BluetoothConfirmation = Literal["optimistic", "ack", "verify"]

SERVERS: dict[Region, str] = {
    "na": "https://fleet-api.prd.na.vn.cloud.tesla.com",
    "eu": "https://fleet-api.prd.eu.vn.cloud.tesla.com",
    "cn": "https://fleet-api.prd.cn.vn.cloud.tesla.cn",
}


def is_valid_region(value: str) -> TypeGuard[Region]:
    """Check if a string is a valid region and narrow its type."""
    return value in SERVERS


class IntEnum(int, Enum):
    """Integer Enum."""

    def __str__(self) -> str:
        return str(self.value)


class StrEnum(str, Enum):
    """String Enum."""

    def __str__(self) -> str:
        return self.value


class Method(StrEnum):
    """HTTP Methods."""

    GET = "GET"
    POST = "POST"
    DELETE = "DELETE"
    PATCH = "PATCH"


class Trunk(StrEnum):
    """Trunk options"""

    FRONT = "front"
    REAR = "rear"


class Seat(IntEnum):
    """Seat positions"""

    FRONT_LEFT = 0
    FRONT_RIGHT = 1
    REAR_LEFT = 2
    REAT_LEFT_BACK = 3
    REAR_CENTER = 4
    REAR_RIGHT = 5
    REAR_RIGHT_BACK = 6
    THIRD_LEFT = 7
    THIRD_RIGHT = 8


class AutoSeat(IntEnum):
    """Auto Climate Seat positions"""

    FRONT_LEFT = 1
    FRONT_RIGHT = 2


class VehicleImageType(IntEnum):
    """Rendered vehicle image kinds available from ``vehicle_image_state()``.

    Values match the proto ``VehicleImageStateType`` enum (``APVIZ_*`` names).
    """

    AUTOPILOT_VISUALIZATION_WRAP = 1
    LICENSE_PLATE = 2


class Level(IntEnum):
    """Level options"""

    OFF = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3


class ClimateKeeperMode(IntEnum):
    """Climate Keeper Mode options"""

    OFF = 0
    KEEP_MODE = 1
    DOG_MODE = 2
    CAMP_MODE = 3


class CabinOverheatProtectionTemp(IntEnum):
    """COP Temp options"""

    LOW = 0  # 30C 90F
    MEDIUM = 1  # 35C 95F
    HIGH = 2  # 40C 100F


class VehicleDataEndpoint(StrEnum):
    """Endpoints options"""

    CHARGE_STATE = "charge_state"
    CLIMATE_STATE = "climate_state"
    CLOSURES_STATE = "closures_state"
    DRIVE_STATE = "drive_state"
    GUI_SETTINGS = "gui_settings"
    LOCATION_DATA = "location_data"
    CHARGE_SCHEDULE_DATA = "charge_schedule_data"
    PRECONDITIONING_SCHEDULE_DATA = "preconditioning_schedule_data"
    VEHICLE_CONFIG = "vehicle_config"
    VEHICLE_STATE = "vehicle_state"
    VEHICLE_DATA_COMBO = "vehicle_data_combo"


class SunRoofCommand(StrEnum):
    """Sunroof options"""

    STOP = "stop"
    CLOSE = "close"
    VENT = "vent"


class WindowCommand(StrEnum):
    """Window Control options"""

    VENT = "vent"
    CLOSE = "close"


class DeviceType(StrEnum):
    """Device Type options"""

    ANDROID = "android"
    IOS_DEVELOPMENT = "ios-development"
    IOS_ENTERPRISE = "ios-enterprise"
    IOS_BETA = "ios-beta"
    IOS_PRODUCTION = "ios-production"


class Scope(StrEnum):
    """Fleet API Scope"""

    OPENID = "openid"
    EMAIL = "email"
    PROFILE = "profile"
    METADATA = "metadata"
    OFFLINE_ACCESS = "offline_access"
    USER_DATA = "user_data"
    VEHICLE_DEVICE_DATA = "vehicle_device_data"
    VEHICLE_LOCATION = "vehicle_location"
    VEHICLE_CMDS = "vehicle_cmds"
    VEHICLE_CHARGING_CMDS = "vehicle_charging_cmds"
    ENERGY_DEVICE_DATA = "energy_device_data"
    ENERGY_CMDS = "energy_cmds"


class EnergyOperationMode(StrEnum):
    """Energy Operation Mode options"""

    AUTONOMOUS = "autonomous"
    SELF_CONSUMPTION = "self_consumption"
    BACKUP = "backup"


class EnergyExportMode(StrEnum):
    """Energy Export Mode options"""

    BATTERY_OK = "battery_ok"
    PV_ONLY = "pv_only"
    NEVER = "never"


class TeslaEnergyPeriod(StrEnum):
    """Period for history for energy sites"""

    DAY = "day"
    WEEK = "week"
    MONTH = "month"
    YEAR = "year"
    LIFETIME = "lifetime"


class EnergyIslandMode(IntEnum):
    """Island mode values for setIslandModeRequest.

    Discovered via mitmproxy capture of the Tesla mobile app and
    confirmed on PW2 (firmware 26.10.0) and PW3 (firmware 26.2.1).

    Mode 6 physically opens the grid contactor (off-grid) when sent
    with force=True. Mode 1 physically closes it (reconnect / on-grid).

    Note: mode=2 (previously assumed by the community to be off-grid)
    sets a preference but does NOT physically operate the contactor
    on either PW2 or PW3.
    """

    ON_GRID = 1
    OFF_GRID = 6


class EnergyDeviceIdentifierType(IntEnum):
    """Identifier type for energy device gRPC commands."""

    GATEWAY_DIN = 1
    SITE_UUID = 2
    SOLAR_INVERTER_DIN = 3
    WALL_CONNECTOR_DIN = 4


class AuthorizedClientKeyType(IntEnum):
    """Key type for energy gateway authorized clients.

    Sourced from the gateway's ``AUTHORIZED_KEY_TYPE_*`` protobuf enum;
    both RSA and ECC are live-verified to register and list back with the
    key type intact.
    """

    INVALID = 0
    RSA = 1
    ECC = 2


class AuthorizedClientType(IntEnum):
    """Client type used when registering an authorized client on an energy gateway.

    Sourced from Tesla's ``AuthorizedClientType`` protobuf enum (as
    reverse-engineered in pypowerwall's ``tedapi_combined.proto``).

    There is no WiFi-specific value: WiFi vs LAN refers to the transport,
    not the client type. pypowerwall's v1r flow registers its RSA key as
    ``CUSTOMER_MOBILE_APP``.
    """

    INVALID = 0
    CUSTOMER_MOBILE_APP = 1
    VEHICLE = 2


class AuthorizedClientState(IntEnum):
    """State of an authorized client registered on an energy gateway.

    BREAKING (as of the release introducing this docstring): the previous
    ``PENDING``/``PENDING_VERIFICATION`` names were mislabelled against the
    gateway's actual enum and are renamed here - ``PENDING`` is now
    ``PENDING_VERIFICATION`` and the old ``PENDING_VERIFICATION`` (value 2)
    is now ``PENDING_VERIFICATION_TIMEOUT``. Value 2 is a **terminal**
    failure state (the ~9-minute presence-proof window expired) - a
    register-then-poll pairing flow that treats it as still-in-progress
    hangs forever. ``INVALID``/``REMOVED`` were previously unmodeled.
    """

    INVALID = 0
    PENDING_VERIFICATION = 1
    PENDING_VERIFICATION_TIMEOUT = 2
    VERIFIED = 3
    REMOVED = 4


class AuthorizationRole(IntEnum):
    """Role granted to an authorized client on an energy gateway."""

    INVALID = 0
    CUSTOMER = 1
    VEHICLE = 2


class AuthorizedVerificationType(IntEnum):
    """How an authorized client's presence was verified on an energy gateway."""

    INVALID = 0
    PRESENCE_PROOF = 1
    BLE = 2
    SIGNED = 3
    HERMES_COMMAND = 4


class ClosureState(StrEnum):
    """Closure state options"""

    NONE = "none"
    MOVE = "move"
    STOP = "stop"
    OPEN = "open"
    CLOSE = "close"


class SeatHeaterLevel(StrEnum):
    """Seat heater level options"""

    OFF = "off"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class TemperatureUnit(IntEnum):
    """Displayed temperature unit options"""

    FAHRENHEIT = 0
    CELSIUS = 1


class DistanceUnit(IntEnum):
    """Displayed distance unit options"""

    MILES = 0
    KILOMETERS = 1


class TimeDisplayFormat(IntEnum):
    """Displayed clock format options"""

    HOUR_12 = 0
    HOUR_24 = 1


class TirePressureUnit(IntEnum):
    """Displayed tire pressure unit options"""

    PSI = 0
    BAR = 1


class EnergyDisplayFormat(IntEnum):
    """Displayed energy/range unit options"""

    PERCENTAGE = 0
    DISTANCE = 1


class PhoneFontSize(IntEnum):
    """Paired-phone display font size options"""

    STANDARD = 0
    LARGE = 1


class BluetoothVehicleData(StrEnum):
    CHARGE_STATE = "GetChargeState"
    CLIMATE_STATE = "GetClimateState"
    DRIVE_STATE = "GetDriveState"
    LOCATION_STATE = "GetLocationState"
    CLOSURES_STATE = "GetClosuresState"
    CHARGE_SCHEDULE_STATE = "GetChargeScheduleState"
    PRECONDITIONING_SCHEDULE_STATE = "GetPreconditioningScheduleState"
    TIRE_PRESSURE_STATE = "GetTirePressureState"
    MEDIA_STATE = "GetMediaState"
    MEDIA_DETAIL_STATE = "GetMediaDetailState"
    SOFTWARE_UPDATE_STATE = "GetSoftwareUpdateState"
    PARENTAL_CONTROLS_STATE = "GetParentalControlsState"
    GUI_SETTINGS = "GetGuiSettings"
    PARKED_ACCESSORY_STATE = "GetParkedAccessoryState"
    LEGACY_VEHICLE_STATE = "GetVehicleState"
    ALERT_STATE = "GetAlertState"
    LIGHT_SHOW_STATE = "GetLightShowState"
    SUSPENSION_STATE = "GetSuspensionState"
    CHILD_PRESENCE_DETECTION_STATE = "GetChildPresenceDetectionState"
