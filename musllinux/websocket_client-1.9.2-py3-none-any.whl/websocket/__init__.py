"""
__init__.py
websocket - WebSocket client library for Python

Copyright 2026 engn33r

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from ._abnf import *  # noqa: F401,F403
from ._app import (  # noqa: F401
    WebSocketApp as WebSocketApp,
    set_reconnect as set_reconnect,
)
from ._core import *  # noqa: F401,F403
from ._exceptions import *  # noqa: F401,F403
from ._logging import *  # noqa: F401,F403
from ._socket import *  # noqa: F401,F403

__version__ = "1.9.2"
