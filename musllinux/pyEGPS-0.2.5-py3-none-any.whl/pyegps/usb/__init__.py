"""Implementations of USB Devices."""
