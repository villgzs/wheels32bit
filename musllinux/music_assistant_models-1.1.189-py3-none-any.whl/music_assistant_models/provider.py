"""Models for providers and plugins in the MA ecosystem."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from mashumaro.mixins.orjson import DataClassORJSONMixin

from .enums import ProviderFeature, ProviderIconVariant, ProviderStage, ProviderType
from .translations import resolve_translation


@dataclass
class ProviderManifest(DataClassORJSONMixin):
    """ProviderManifest, details of a provider."""

    type: ProviderType
    domain: str
    name: str
    description: str
    codeowners: list[str]

    # optional params

    # stage: the stage of the provider, used to determine if it is stable or experimental
    stage: ProviderStage = ProviderStage.STABLE
    # requirements: list of (pip style) python packages required for this provider
    requirements: list[str] = field(default_factory=list)
    # documentation: link/url to documentation.
    documentation: str | None = None
    # multi_instance: whether multiple instances of the same provider are allowed/possible
    multi_instance: bool = False
    # builtin: whether this provider is a system/builtin provider, loaded by default
    builtin: bool = False
    # allow_disable: whether this provider can be disabled (used with builtin)
    allow_disable: bool = True
    # depends_on: depends on another provider to function
    depends_on: str | None = None
    # icon: name of the material design icon (https://pictogrammers.com/library/mdi)
    icon: str | None = None
    # icon_images: which icon variants this provider supplies as image files
    # (svg or transparent png in the provider folder).
    icon_images: list[ProviderIconVariant] = field(default_factory=list)
    # mdns_discovery: list of mdns types to discover
    mdns_discovery: list[str] | None = None
    # upnp_discovery: list of SSDP search targets to discover
    upnp_discovery: list[str] | None = None
    # has_setup_flow: if True, this provider offers an interactive setup flow
    # that can also be re-run on demand (reconfigure), regardless of auth state
    has_setup_flow: bool = False

    # credits: list of credits/attributions
    # e.g. for libraries used, icons, etc.
    # accepts markdown formatting.
    credits: list[str] = field(default_factory=list)

    @classmethod
    async def parse(cls, manifest_file: str) -> ProviderManifest:
        """Parse ProviderManifest from file."""
        file_contents = await asyncio.to_thread(Path(manifest_file).read_text)
        return cls.from_json(file_contents)

    def __post_serialize__(self, d: dict[Any, Any]) -> dict[Any, Any]:
        """Localize name/description when a translation resolver is set (no-op otherwise)."""
        # core controllers use the core.<domain> namespace, providers use provider.<domain>
        namespace = "core" if self.type == ProviderType.CORE else "provider"
        if (value := resolve_translation(f"{namespace}.{self.domain}.manifest.name")) is not None:
            d["name"] = value
        if (
            value := resolve_translation(f"{namespace}.{self.domain}.manifest.description")
        ) is not None:
            d["description"] = value
        return d


@dataclass
class ProviderInstance(DataClassORJSONMixin):
    """Provider instance details when a provider is serialized over the api."""

    type: ProviderType
    domain: str
    name: str
    instance_id: str
    supported_features: set[ProviderFeature]
    available: bool
    is_streaming_provider: bool | None = None  # music providers only
    # lookup_key: kept for backwards compatibility; mirrors the server wire value (== instance_id)
    lookup_key: str | None = None
