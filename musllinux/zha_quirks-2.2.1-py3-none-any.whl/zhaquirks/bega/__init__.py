"""Quirks for BEGA devices."""
