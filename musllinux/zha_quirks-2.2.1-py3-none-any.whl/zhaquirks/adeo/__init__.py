"""Module for ADEO devices."""
