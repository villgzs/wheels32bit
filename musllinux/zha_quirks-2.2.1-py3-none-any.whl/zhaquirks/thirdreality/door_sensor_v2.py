"""Third Reality door sensor devices."""

from typing import Final

import zigpy.types as t
from zigpy.zcl.foundation import BaseAttributeDefs, ZCLAttributeDef

from zhaquirks.builder import NumberDeviceClass, QuirkBuilder, UnitOfTime
from zhaquirks.clusters import CustomCluster


class ThirdRealityDoorCluster(CustomCluster):
    """Third Reality's door sensor private cluster."""

    cluster_id = 0xFF01

    class AttributeDefs(BaseAttributeDefs):
        """Define the attributes of a private cluster."""

        open_delay_time: Final = ZCLAttributeDef(
            id=0x0000,
            type=t.uint16_t,
            manufacturer_code=0x1233,
        )


(
    QuirkBuilder("Third Reality, Inc", "3RDS17BZ")
    .replaces(ThirdRealityDoorCluster)
    .number(
        attribute_name=ThirdRealityDoorCluster.AttributeDefs.open_delay_time.name,
        cluster_id=ThirdRealityDoorCluster.cluster_id,
        min_value=0,
        max_value=3600,
        unit=UnitOfTime.SECONDS,
        device_class=NumberDeviceClass.DURATION,
        translation_key="open_delay_time",
        fallback_name="Open delay time",
    )
    .add_to_registry()
)
