"""Async client for the Ridder HortOS Automation API."""

from __future__ import annotations

from .client import HortosClient
from .const import (
    DEFAULT_BASE_URL,
    DEFAULT_TIMEOUT,
    MAX_HISTORY_WINDOW,
    RATE_LIMIT_REQUESTS,
    RATE_LIMIT_WINDOW,
)
from .enums import (
    WIND_DIRECTION_CODE_NORTH,
    WIND_DIRECTION_SECTORS,
    WIND_DIRECTION_STEP_DEGREES,
    decode_cardinal_wind_direction,
)
from .exceptions import (
    HortosAuthenticationError,
    HortosConnectionError,
    HortosError,
    HortosResponseError,
)
from .models import (
    Device,
    DeviceHealth,
    OnlineStatus,
    Organisation,
    Readout,
    ReadoutDefinition,
    ReadoutValue,
    ReadoutValueType,
    Source,
    TokenPair,
)
from .naming import (
    disambiguate_source_names,
    readout_display_name,
    readout_subject,
    split_camel,
)

__all__ = [
    "DEFAULT_BASE_URL",
    "DEFAULT_TIMEOUT",
    "MAX_HISTORY_WINDOW",
    "RATE_LIMIT_REQUESTS",
    "RATE_LIMIT_WINDOW",
    "WIND_DIRECTION_CODE_NORTH",
    "WIND_DIRECTION_SECTORS",
    "WIND_DIRECTION_STEP_DEGREES",
    "Device",
    "DeviceHealth",
    "HortosAuthenticationError",
    "HortosClient",
    "HortosConnectionError",
    "HortosError",
    "HortosResponseError",
    "OnlineStatus",
    "Organisation",
    "Readout",
    "ReadoutDefinition",
    "ReadoutValue",
    "ReadoutValueType",
    "Source",
    "TokenPair",
    "decode_cardinal_wind_direction",
    "disambiguate_source_names",
    "readout_display_name",
    "readout_subject",
    "split_camel",
]
