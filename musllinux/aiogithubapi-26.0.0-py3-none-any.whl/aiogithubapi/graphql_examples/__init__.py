"""Example GraphQL queries"""
