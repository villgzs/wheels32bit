"""Initialise aiogithubapi models."""
