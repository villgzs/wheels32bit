"""Core CLI runtime primitives."""
