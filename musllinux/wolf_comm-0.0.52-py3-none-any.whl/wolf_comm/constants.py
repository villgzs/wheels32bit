"""
File with all constants
"""

BASE_URL = "https://www.wolf-smartset.com"

BASE_URL_PORTAL = BASE_URL + "/portal"

AUTHENTICATION_URL = "/idsrv"
AUTHENTICATION_BASE_URL = BASE_URL + AUTHENTICATION_URL
AUTHENTICATION_CLIENT = "smartset.web"

# ASP.NET Core anti-forgery form field on the IdentityServer login page
REQUEST_VERIFICATION_TOKEN = '__RequestVerificationToken'

SESSION_ID = 'SessionId'

GUI_ID_CHANGED = 'GuiIdChanged'

BUNDLE_ID = 'BundleId'

ISREADONLY = 'IsReadOnly'

BUNDLE = 'IsSubBundle'

VALUE_ID_LIST = 'ValueIdList'

ID = 'Id'

SYSTEM_ID = 'SystemId'

# only present for shared/foreign systems; required in the GetSystemStateList
# payload for them, null/absent for systems the user owns
SYSTEM_SHARE_ID = 'SystemShareId'

TAB_VIEWS = 'TabViews'

MENU_ITEMS = 'MenuItems'

SUB_MENU_ENTRIES = 'SubMenuEntries'

GATEWAY_ID = "GatewayId"

LAST_ACCESS = "LastAccess"

TIMESTAMP = "Timestamp"

ERROR_CODE = "ErrorCode"

ERROR_TYPE = "ErrorType"

ERROR_READ_PARAMETER = 'internal msg: ReadParameterValues error'

ERROR_MESSAGE = 'Message'

NAME = 'Name'

PERCENTAGE = '%'

HOUR = 'Std'

KILOWATT = 'kW'

KILOWATTHOURS = 'kWh'

# Energy parameters whose raw value is in Wh; the unit string lists the
# display scalings the portal cycles through (Wh -> kWh -> MWh).
WATTHOURS_KILOWATTHOURS = 'Wh;kWh'

WATTHOURS_KILOWATTHOURS_MEGAWATTHOURS = 'Wh;kWh;MWh'

BAR = 'bar'

RPM = 'U/min'

FLOW = 'l/min'

FREQUENCY = 'Hz'

CELSIUS_TEMPERATURE = '°C'

VALUES = 'Values'

STATE = 'State'

LIST_ITEMS = 'ListItems'

DISPLAY_TEXT = 'DisplayText'

VALUE = 'Value'

PARAMETER_ID = 'ParameterId'

PARAMETER_DESCRIPTORS = 'ParameterDescriptors'

UNIT = 'Unit'

TAB_NAME = 'TabName'

VALUE_ID = 'ValueId'

GROUP = 'Group'

SYSTEM_LIST = 'SystemList'

GATEWAY_STATE = 'GatewayState'

IS_ONLINE = 'IsOnline'

WRITE_PARAMETER_VALUES = 'WriteParameterValues'
