"""XBee ControllerApplication implementation."""
