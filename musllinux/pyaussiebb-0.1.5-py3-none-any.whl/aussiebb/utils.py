""" shared utility functions """
