"""Init file for ZoneMinder."""
