from .pyialarm import IAlarm
