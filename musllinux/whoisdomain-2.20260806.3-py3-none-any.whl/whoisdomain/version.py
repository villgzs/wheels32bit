# This module only makes the version available for dynamic versioning
VERSION = "2.20260806.3"
