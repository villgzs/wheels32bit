"""Asynchronous Python client for WLED."""

import asyncio
import sys
from typing import Annotated

import typer
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from zeroconf import ServiceStateChange, Zeroconf
from zeroconf.asyncio import AsyncServiceBrowser, AsyncServiceInfo, AsyncZeroconf

from wled import WLED, WLEDReleases
from wled.exceptions import WLEDConnectionError, WLEDUnsupportedVersionError

from .async_typer import AsyncTyper

cli = AsyncTyper(help="WLED CLI", no_args_is_help=True, add_completion=False)
console = Console()


@cli.error_handler(WLEDConnectionError)
def connection_error_handler(_: WLEDConnectionError) -> None:
    """Handle connection errors."""
    message = """
    Could not connect to the specified WLED device. Please make sure that
    the device is powered on, connected to the network and that you have
    specified the correct IP address or hostname.

    If you are not sure what the IP address or hostname of your WLED device
    is, you can use the scan command to find it:

    wled scan
    """
    panel = Panel(
        message,
        expand=False,
        title="Connection error",
        border_style="red bold",
    )
    console.print(panel)
    sys.exit(1)


@cli.error_handler(WLEDUnsupportedVersionError)
def unsupported_version_error_handler(
    _: WLEDUnsupportedVersionError,
) -> None:
    """Handle unsupported version errors."""
    message = """
    The specified WLED device is running an unsupported version.

    Currently only 0.14.0 and higher is supported
    """
    panel = Panel(
        message,
        expand=False,
        title="Unsupported version",
        border_style="red bold",
    )
    console.print(panel)
    sys.exit(1)


@cli.command("on")
async def command_on(
    host: Annotated[
        str,
        typer.Option(
            help="WLED device IP address or hostname",
            prompt="Host address",
            show_default=False,
        ),
    ],
) -> None:
    """Turn on a WLED device."""
    async with WLED(host) as led:
        await led.master(on=True)
    console.print("[green]WLED device turned on!")


@cli.command("off")
async def command_off(
    host: Annotated[
        str,
        typer.Option(
            help="WLED device IP address or hostname",
            prompt="Host address",
            show_default=False,
        ),
    ],
) -> None:
    """Turn off a WLED device."""
    async with WLED(host) as led:
        await led.master(on=False)
    console.print("[green]WLED device turned off!")


@cli.command("brightness")
async def command_brightness(
    host: Annotated[
        str,
        typer.Option(
            help="WLED device IP address or hostname",
            prompt="Host address",
            show_default=False,
        ),
    ],
    brightness: Annotated[
        int,
        typer.Option(
            help="Brightness level (0-255)",
            prompt="Brightness",
            show_default=False,
            min=0,
            max=255,
        ),
    ],
) -> None:
    """Set the brightness of a WLED device."""
    async with WLED(host) as led:
        await led.master(brightness=brightness)
    console.print(f"[green]Brightness set to {brightness}!")


@cli.command("info")
async def command_info(
    host: Annotated[
        str,
        typer.Option(
            help="WLED device IP address or hostname",
            prompt="Host address",
            show_default=False,
        ),
    ],
) -> None:
    """Show the information about the WLED device."""
    with console.status(
        "[cyan]Fetching WLED device information...", spinner="toggle12"
    ):
        async with WLED(host) as led:
            device = await led.update()

    info_table = Table(title="\nWLED device information", show_header=False)
    info_table.add_column("Property", style="cyan bold")
    info_table.add_column("Value", style="green")

    info_table.add_row("Name", device.info.name)
    info_table.add_row("Brand", device.info.brand)
    info_table.add_row("Product", device.info.product)

    info_table.add_section()
    info_table.add_row("IP address", device.info.ip)
    info_table.add_row("MAC address", device.info.mac_address)
    if device.info.wifi:
        info_table.add_row("Wi-Fi BSSID", device.info.wifi.bssid)
        info_table.add_row("Wi-Fi channel", str(device.info.wifi.channel))
        info_table.add_row("Wi-Fi RSSI", f"{device.info.wifi.rssi} dBm")
        info_table.add_row("Wi-Fi signal strength", f"{device.info.wifi.signal}%")

    info_table.add_section()
    info_table.add_row("Version", device.info.version)
    info_table.add_row("Build", str(device.info.build))
    info_table.add_row("Architecture", device.info.architecture)
    info_table.add_row("Arduino version", device.info.arduino_core_version)

    info_table.add_section()
    info_table.add_row("Uptime", f"{int(device.info.uptime.total_seconds())} seconds")
    info_table.add_row("Free heap", f"{device.info.free_heap} bytes")
    info_table.add_row("Total storage", f"{device.info.filesystem.total} bytes")
    info_table.add_row("Used storage", f"{device.info.filesystem.used} bytes")
    info_table.add_row("% Used storage", f"{device.info.filesystem.used_percentage}%")

    info_table.add_section()
    info_table.add_row("Effect count", f"{device.info.effect_count} effects")
    info_table.add_row("Palette count", f"{device.info.palette_count} palettes")
    info_table.add_row(
        "Custom palette count",
        f"{device.info.custom_palette_count} custom palettes",
    )

    info_table.add_section()
    info_table.add_row("Sync UDP port", str(device.info.udp_port))
    info_table.add_row(
        "WebSocket",
        "Disabled"
        if device.info.websocket is None
        else f"{device.info.websocket} client(s)",
    )

    info_table.add_section()
    info_table.add_row("Live", "Yes" if device.info.live else "No")
    info_table.add_row("Live IP", device.info.live_ip)
    info_table.add_row("Live mode", device.info.live_mode)

    info_table.add_section()
    info_table.add_row("LED count", f"{device.info.leds.count} LEDs")
    info_table.add_row("LED power", f"{device.info.leds.power} mA")
    info_table.add_row("LED max power", f"{device.info.leds.max_power} mA")

    console.print(info_table)


@cli.command("effects")
async def command_effects(
    host: Annotated[
        str,
        typer.Option(
            help="WLED device IP address or hostname",
            prompt="Host address",
            show_default=False,
        ),
    ],
) -> None:
    """Show the effects on the device."""
    with console.status(
        "[cyan]Fetching WLED device information...", spinner="toggle12"
    ):
        async with WLED(host) as led:
            device = await led.update()

    table = Table(title="\nEffects on this WLED device", show_header=False)
    table.add_column("Effects", style="cyan bold")
    for effect in device.effects.values():
        table.add_row(effect.name)

    console.print(table)


@cli.command("palettes")
async def command_palettes(
    host: Annotated[
        str,
        typer.Option(
            help="WLED device IP address or hostname",
            prompt="Host address",
            show_default=False,
        ),
    ],
) -> None:
    """Show the palettes on the device."""
    with console.status(
        "[cyan]Fetching WLED device information...", spinner="toggle12"
    ):
        async with WLED(host) as led:
            device = await led.update()

    table = Table(title="\nPalettes on this WLED device", show_header=False)
    table.add_column("Palette", style="cyan bold")
    for palettes in device.palettes.values():
        table.add_row(palettes.name)

    console.print(table)


@cli.command("playlists")
async def command_playlists(
    host: Annotated[
        str,
        typer.Option(
            help="WLED device IP address or hostname",
            prompt="Host address",
            show_default=False,
        ),
    ],
) -> None:
    """Show the playlists on the device."""
    with console.status(
        "[cyan]Fetching WLED device information...", spinner="toggle12"
    ):
        async with WLED(host) as led:
            device = await led.update()

    if not device.playlists:
        console.print("🚫[red] This device has no playlists")
        return

    table = Table(title="\nPlaylists stored in the WLED device", show_header=False)
    table.add_column("Playlist", style="cyan bold")
    for playlist in device.playlists.values():
        table.add_row(playlist.name)

    console.print(table)


@cli.command("presets")
async def command_presets(
    host: Annotated[
        str,
        typer.Option(
            help="WLED device IP address or hostname",
            prompt="Host address",
            show_default=False,
        ),
    ],
) -> None:
    """Show the presets on the device."""
    with console.status(
        "[cyan]Fetching WLED device information...", spinner="toggle12"
    ):
        async with WLED(host) as led:
            device = await led.update()

    if not device.presets:
        console.print("🚫[red] This device has no presets")
        return

    table = Table(title="\nPresets stored in the WLED device")
    table.add_column("Preset", style="cyan bold")
    table.add_column("Quick label", style="cyan bold")
    table.add_column("Active", style="green")
    for preset in device.presets.values():
        table.add_row(preset.name, preset.quick_label, "Yes" if preset.on else "No")

    console.print(table)


@cli.command("preset")
async def command_preset(
    host: Annotated[
        str,
        typer.Option(
            help="WLED device IP address or hostname",
            prompt="Host address",
            show_default=False,
        ),
    ],
    preset: Annotated[
        str,
        typer.Option(
            help="Preset name or ID to activate",
            prompt="Preset",
            show_default=False,
        ),
    ],
) -> None:
    """Activate a preset on the WLED device."""
    async with WLED(host) as led:
        await led.update()
        await led.preset(preset if not preset.isdigit() else int(preset))
    console.print(f"[green]Preset '{preset}' activated!")


@cli.command("playlist")
async def command_playlist(
    host: Annotated[
        str,
        typer.Option(
            help="WLED device IP address or hostname",
            prompt="Host address",
            show_default=False,
        ),
    ],
    playlist: Annotated[
        str,
        typer.Option(
            help="Playlist name or ID to activate",
            prompt="Playlist",
            show_default=False,
        ),
    ],
) -> None:
    """Activate a playlist on the WLED device."""
    async with WLED(host) as led:
        await led.update()
        await led.playlist(playlist if not playlist.isdigit() else int(playlist))
    console.print(f"[green]Playlist '{playlist}' activated!")


@cli.command("releases")
async def command_releases() -> None:
    """Show the latest release information of WLED."""
    with console.status(
        "[cyan]Fetching latest release information...", spinner="toggle12"
    ):
        async with WLEDReleases() as releases:
            latest = await releases.releases()

    table = Table(
        title="\n\nFound WLED Releases", header_style="cyan bold", show_lines=True
    )
    table.add_column("Release channel")
    table.add_column("Latest version")
    table.add_column("Release notes")

    table.add_row(
        "Stable",
        latest.stable,
        f"https://github.com/wled/WLED/releases/v{latest.stable}",
    )
    table.add_row(
        "Beta",
        latest.beta,
        f"https://github.com/wled/WLED/releases/v{latest.beta}",
    )
    table.add_row(
        "Nightly",
        latest.nightly,
        "https://github.com/wled/WLED/releases/tag/nightly",
    )

    console.print(table)


@cli.command("reset")
async def command_reset(
    host: Annotated[
        str,
        typer.Option(
            help="WLED device IP address or hostname",
            prompt="Host address",
            show_default=False,
        ),
    ],
) -> None:
    """Reboot a WLED device."""
    with console.status("[cyan]Rebooting WLED device...", spinner="toggle12"):
        async with WLED(host) as led:
            await led.reset()

    console.print("[green]WLED device has been rebooted!")


@cli.command("state")
async def command_state(
    host: Annotated[
        str,
        typer.Option(
            help="WLED device IP address or hostname",
            prompt="Host address",
            show_default=False,
        ),
    ],
) -> None:
    """Show the current state of the WLED device."""
    with console.status("[cyan]Fetching WLED device state...", spinner="toggle12"):
        async with WLED(host) as led:
            device = await led.update()

    state = device.state

    state_table = Table(title="\nWLED device state", show_header=False)
    state_table.add_column("Property", style="cyan bold")
    state_table.add_column("Value", style="green")

    state_table.add_row("Power", "On" if state.on else "Off")
    state_table.add_row("Brightness", str(state.brightness))
    state_table.add_row("Transition", str(state.transition))

    if state.preset_id is not None and device.presets:
        preset = device.presets.get(state.preset_id)
        state_table.add_row(
            "Preset", f"{preset.name} (#{state.preset_id})" if preset else "Unknown"
        )

    if state.playlist_id is not None and device.playlists:
        playlist = device.playlists.get(state.playlist_id)
        state_table.add_row(
            "Playlist",
            f"{playlist.name} (#{state.playlist_id})" if playlist else "Unknown",
        )

    state_table.add_row("Nightlight", "On" if state.nightlight.on else "Off")
    state_table.add_row(
        "Live override", state.live_data_override.name.replace("_", " ").title()
    )

    console.print(state_table)

    seg_table = Table(title="\nSegments", show_lines=True)
    seg_table.add_column("ID", style="cyan bold")
    seg_table.add_column("Name")
    seg_table.add_column("Power")
    seg_table.add_column("Brightness")
    seg_table.add_column("Effect")
    seg_table.add_column("Palette")
    seg_table.add_column("Range")

    for seg in state.segments.values():
        effect = (
            device.effects.get(seg.effect_id)
            if isinstance(seg.effect_id, int)
            else None
        )
        palette = (
            device.palettes.get(seg.palette_id)
            if isinstance(seg.palette_id, int)
            else None
        )
        seg_table.add_row(
            str(seg.segment_id),
            seg.name or "",
            "On" if seg.on else "Off",
            str(seg.brightness),
            effect.name if effect else str(seg.effect_id),
            palette.name if palette else str(seg.palette_id),
            f"{seg.start}-{seg.stop}",
        )

    console.print(seg_table)


@cli.command("upgrade")
async def command_upgrade(
    host: Annotated[
        str,
        typer.Option(
            help="WLED device IP address or hostname",
            prompt="Host address",
            show_default=False,
        ),
    ],
    version: Annotated[
        str,
        typer.Option(
            help="WLED version to upgrade to",
            prompt="Version",
            show_default=False,
        ),
    ],
) -> None:
    """Upgrade a WLED device to a specific version."""
    async with WLED(host) as led:
        device = await led.update()
        console.print(f"[cyan]Current version: [bold]{device.info.version}[/bold]")
        console.print(f"[cyan]Upgrading to: [bold]{version}[/bold]")

        with console.status("[cyan]Upgrading WLED device...", spinner="toggle12"):
            await led.upgrade(version=version)

    console.print("[green]Upgrade complete! The device will reboot.")


@cli.command("scan")
async def command_scan() -> None:
    """Scan for WLED devices on the network."""
    zeroconf = AsyncZeroconf()
    background_tasks = set()

    table = Table(
        title="\n\nFound WLED devices", header_style="cyan bold", show_lines=True
    )
    table.add_column("Addresses")
    table.add_column("MAC Address")

    def async_on_service_state_change(
        zeroconf: Zeroconf,
        service_type: str,
        name: str,
        state_change: ServiceStateChange,
    ) -> None:
        """Handle service state changes."""
        if state_change is not ServiceStateChange.Added:
            return

        future = asyncio.ensure_future(
            async_display_service_info(zeroconf, service_type, name)
        )
        background_tasks.add(future)
        future.add_done_callback(background_tasks.discard)

    async def async_display_service_info(
        zeroconf: Zeroconf, service_type: str, name: str
    ) -> None:
        """Retrieve and display service info."""
        info = AsyncServiceInfo(service_type, name)
        await info.async_request(zeroconf, 3000)
        if info is None:
            return

        console.print(f"[cyan bold]Found service {info.server}: is a WLED device 🎉")

        mac = info.properties.get(b"mac")
        table.add_row(
            f"{str(info.server).rstrip('.')}\n"
            + ", ".join(info.parsed_scoped_addresses()),
            mac.decode() if mac else "unknown",
        )

    console.print("[green]Scanning for WLED devices...")
    console.print("[red]Press Ctrl-C to exit\n")

    with Live(table, console=console, refresh_per_second=4):
        browser = AsyncServiceBrowser(
            zeroconf.zeroconf,
            "_wled._tcp.local.",
            handlers=[async_on_service_state_change],
        )

        try:
            forever = asyncio.Event()
            await forever.wait()
        except KeyboardInterrupt:
            pass
        finally:
            console.print("\n[green]Control-C pressed, stopping scan")
            await browser.async_cancel()
            await zeroconf.async_close()


if __name__ == "__main__":
    cli()
