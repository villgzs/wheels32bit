from typing import Any, List, Optional

from .base import BaseModel
from .device_model import DeviceModel


class Device(BaseModel):
    """Model representing a PAJ GPS device."""

    id: Optional[int] = None
    name: Optional[str] = None
    imei: Optional[str] = None
    model_nr: Optional[int] = None
    devicepos: Optional[int] = None
    deviceshow: Optional[int] = None
    intern: Optional[int] = None
    protokoll: Optional[str] = None
    devicezeit: Optional[str] = None
    modellid: Optional[int] = None
    telefonnummer: Optional[str] = None
    kategorie: Optional[int] = None
    speicherdauer: Optional[int] = None
    intervalllaenge: Optional[int] = None
    status: Optional[int] = None
    package: Optional[str] = None
    createdate: Optional[str] = None
    updatedate: Optional[str] = None
    spuraktiv: Optional[int] = None
    alarmintervall: Optional[int] = None
    spurmodus: Optional[int] = None
    spurfarbe: Optional[str] = None
    spurpunkte: Optional[int] = None
    spurminuten: Optional[int] = None
    spurdatum: Optional[str] = None
    spurdatumbis: Optional[str] = None
    spursymbolbewegung: Optional[str] = None
    spursymbolpause: Optional[str] = None
    alarmeinstellungenglobal: Optional[int] = None
    alarmbewegung: Optional[int] = None
    alarmbewegungintervall: Optional[int] = None
    alarmgeschwindigkeit: Optional[int] = None
    alarmgeschwindigkeitab: Optional[int] = None
    alarmgeschwindigkeitintervall: Optional[int] = None
    alarmgeozaunbefahren: Optional[int] = None
    alarmgeozaunbefahrenintervall: Optional[int] = None
    alarmgeozaunverlassen: Optional[int] = None
    alarmgeozaunverlassenintervall: Optional[int] = None
    alarmakkuwarnung: Optional[int] = None
    alarmakkuwarnungab: Optional[int] = None
    alarmakkuwarnungintervall: Optional[int] = None
    alarmzuendalarm: Optional[int] = None
    alarm_turn_off: Optional[int] = None
    alarm_volt: Optional[int] = None
    alarm_volt_value: Optional[int] = None
    guard_id: Optional[int] = None
    alarmstromunterbrechung: Optional[int] = None
    tagesemail: Optional[int] = None
    alarmbewegunglastmail: Optional[str] = None
    alarmgeschwindigkeitlastmail: Optional[str] = None
    alarmgeozaunbefahrenlastmail: Optional[str] = None
    alarmgeozaunverlassenlastmail: Optional[str] = None
    alarmakkuwarnunglastmail: Optional[str] = None
    alarmakkucounter: Optional[int] = None
    alarmstromunterbrechunglastmail: Optional[str] = None
    alarmzuendalarmlastmail: Optional[str] = None
    alarmzuendalarmlastmailon: Optional[str] = None
    alarmzuendalarmlastmailoff: Optional[str] = None
    iconname: Optional[str] = None
    iconusecustom: Optional[int] = None
    iconcustomimage: Optional[str] = None
    radius_meter: Optional[int] = None
    radius_lat: Optional[float] = None
    radius_lng: Optional[float] = None
    radius_laststatus: Optional[int] = None
    geschwindigkeit_laststatus: Optional[int] = None
    zuend_laststatus: Optional[int] = None
    acc_lastdateunix: Optional[int] = None
    alarmsos: Optional[int] = None
    alarmsoslastmail: Optional[str] = None
    last_dateunix: Optional[int] = None
    last_datum: Optional[str] = None
    last_uhrzeit: Optional[str] = None
    last_lat_symbol: Optional[float] = None
    last_lng_symbol: Optional[float] = None
    last_speed: Optional[int] = None
    last_battery: Optional[int] = None
    show_kmanzeige: Optional[int] = None
    show_gruppenanzeigeanzeige: Optional[int] = None
    last_serviceport: Optional[int] = None
    stats_speed_active: Optional[int] = None
    timezone: Optional[str] = None
    create_dateunix: Optional[int] = None
    create_dateunix_str: Optional[str] = None
    auto_upd_date: Optional[str] = None
    ac_status: Optional[int] = None
    average_consum: Optional[float] = None
    selected_date_range: Optional[int] = None
    car_id: Optional[int] = None
    private_mode: Optional[int] = None
    carDevice_id: Optional[int] = None
    alarm_geofence: Optional[int] = None
    setup_done: Optional[int] = None
    privacy_mode: Optional[int] = None
    share_link: Optional[str] = None
    loadroute: Optional[int] = None
    note: Optional[str] = None
    note_color: Optional[str] = None
    threedModel_name: Optional[str] = None
    threedModel_color: Optional[str] = None
    deleted_at: Optional[str] = None
    category_id: Optional[int] = None
    alarm_enabled: Optional[int] = None
    live_tracking_start_time: Optional[str] = None
    live_tracking_duration: Optional[int] = None
    logbook_access: Optional[int] = None
    route_profile: Optional[str] = None
    route_accuracy: Optional[int] = None
    activity_daily_goal: Optional[int] = None
    extended_alarm_sos: Optional[int] = None
    alarm_fall_enabled: Optional[int] = None
    is_exchanged: Optional[int] = None
    shutdown_protection_status: Optional[int] = None
    subAccounts: Optional[List[Any]] = None
    customImgUrl: Optional[str] = None
    device_models: Optional[List[DeviceModel]] = None
    appmode: Optional[str] = None
    device_restriction: Optional[Any] = None

    def __init__(self, **kwargs: Any) -> None:
        raw_models = kwargs.get("device_models")
        kwargs["device_models"] = self._parse_device_models(raw_models)
        super().__init__(**kwargs)

    @staticmethod
    def _parse_device_models(raw: Any) -> Optional[List[DeviceModel]]:
        """Deserialize raw device_models value into a list of DeviceModel instances.

        The API may return a list of dicts, an empty list, None, or the string "{}".
        All non-list cases are treated as no model data.
        """
        if not isinstance(raw, list):
            return None
        return [DeviceModel(**item) for item in raw if isinstance(item, dict)]

    @property
    def has_battery(self) -> bool:
        """Return True if the device has a built-in standalone battery.

        Based on the device model's standalone_battery field: only a value of 1
        means the device has a battery. Any other value, or absence of model data,
        means no battery.
        """
        if not self.device_models:
            return False
        return self.device_models[0].standalone_battery == 1
