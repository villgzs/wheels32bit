"""Asynchronous Python client for Tesla Wall Connector"""

from aiohttp import ClientSession

from .api import API
from .lifetime import Lifetime
from .version import Version
from .vitals import Vitals
from .wifi_status import WifiStatus


class WallConnector:
    """Main class for reading data from a Tesla Wall Connector"""

    def __init__(
        self,
        host: str,
        timeout: float = 5,
        session: ClientSession | None = None,
        split_phase: bool = False,
    ):
        self._session = ClientSession() if session is None else session
        self.api = API(host, self._session, timeout)
        self.split_phase = split_phase

    async def async_get_vitals(self) -> Vitals:
        """Get 'vitals' data"""
        return Vitals(
            await self.api.async_request("vitals"),
            split_phase=self.split_phase,
        )

    async def async_get_lifetime(self) -> Lifetime:
        """Get 'lifetime' data"""
        return Lifetime(await self.api.async_request("lifetime"))

    async def async_get_version(self) -> Version:
        """Get version information"""
        return Version(await self.api.async_request("version"))

    async def async_get_wifi_status(self) -> WifiStatus:
        """Get wifi status information"""
        return WifiStatus(await self.api.async_request("wifi_status"))

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_exc_info) -> None:
        if self._session:
            await self._session.close()
