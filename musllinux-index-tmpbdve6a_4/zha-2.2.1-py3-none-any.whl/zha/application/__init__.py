"""Application module for Zigbee Home Automation."""

from enum import StrEnum


class Platform(StrEnum):
    """Available entity platforms."""

    ALARM_CONTROL_PANEL = "alarm_control_panel"
    BINARY_SENSOR = "binary_sensor"
    BUTTON = "button"
    CLIMATE = "climate"
    COVER = "cover"
    DEVICE_TRACKER = "device_tracker"
    EVENT = "event"
    FAN = "fan"
    LIGHT = "light"
    LOCK = "lock"
    NUMBER = "number"
    SELECT = "select"
    SENSOR = "sensor"
    SIREN = "siren"
    SWITCH = "switch"
    VALVE = "valve"
    VIRTUAL = "virtual"
    UPDATE = "update"


class EntityType(StrEnum):
    """Entity type."""

    CONFIG = "config"
    DIAGNOSTIC = "diagnostic"
    STANDARD = "standard"


class EntityPlatform(StrEnum):
    """Entity platform exposed by quirks v2 metadata."""

    BINARY_SENSOR = "binary_sensor"
    BUTTON = "button"
    NUMBER = "number"
    SENSOR = "sensor"
    SELECT = "select"
    SWITCH = "switch"
