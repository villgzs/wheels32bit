"""Fans on Zigbee Home Automation networks."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
import functools
import math
from typing import TYPE_CHECKING, Any, cast

from zigpy.zcl import (
    AttributeReadEvent,
    AttributeReportedEvent,
    AttributeUpdatedEvent,
    AttributeWrittenEvent,
    ReportingConfig,
)
from zigpy.zcl.clusters import hvac

from zha.application import Platform
from zha.application.helpers import safe_read, write_attributes_safe
from zha.application.platforms import (
    AttrConfig,
    BaseEntity,
    BaseEntityState,
    ClusterConfig,
    ClusterMatch,
    GroupEntity,
    PlatformEntity,
    PlatformFeatureGroup,
    register_entity,
    register_group_entity,
)
from zha.application.platforms.const import IKEA_AIR_PURIFIER_CLUSTER
from zha.application.platforms.fan.const import (
    DEFAULT_ON_PERCENTAGE,
    LEGACY_SPEED_LIST,
    OFF_SPEED_VALUES,
    PRESET_MODE_AUTO,
    PRESET_MODE_SMART,
    PRESET_MODES_TO_NAME,
    SPEED_OFF,
    SPEED_RANGE,
    FanEntityFeature,
)
from zha.application.platforms.fan.helpers import (
    NotValidPresetModeError,
    int_states_in_range,
    ordered_list_item_to_percentage,
    percentage_to_ordered_list_item,
    percentage_to_ranged_value,
    ranged_value_to_percentage,
)
from zha.zigbee.group import Group

if TYPE_CHECKING:
    from zha.zigbee.device import Device
    from zha.zigbee.endpoint import Endpoint


@dataclass(frozen=True, kw_only=True)
class FanState(BaseEntityState):
    """State for fan entities."""

    preset_mode: str | None
    percentage: int | None
    is_on: bool
    speed: str | None
    preset_modes: list[str]
    supported_features: FanEntityFeature
    speed_count: int
    speed_list: list[str]
    speed_range: tuple[int, int]
    default_on_percentage: int


class BaseFan(BaseEntity, ABC):
    """Base representation of a ZHA fan."""

    PLATFORM = Platform.FAN

    _attr_supported_features: FanEntityFeature = (
        FanEntityFeature.SET_SPEED
        | FanEntityFeature.TURN_OFF
        | FanEntityFeature.TURN_ON
    )
    _attr_translation_key: str = "fan"
    _attr_primary_weight = 10

    @property
    @abstractmethod
    def preset_mode(self) -> str | None:
        """Return the current preset mode."""

    @property
    @abstractmethod
    def percentage(self) -> int | None:
        """Return the current speed percentage."""

    @functools.cached_property
    def preset_modes(self) -> list[str]:
        """Return the available preset modes."""
        return list(self.preset_modes_to_name.values())

    @functools.cached_property
    def preset_modes_to_name(self) -> dict[int, str]:
        """Return a dict from preset mode to name."""
        return PRESET_MODES_TO_NAME

    @functools.cached_property
    def preset_name_to_mode(self) -> dict[str, int]:
        """Return a dict from preset name to mode."""
        return {v: k for k, v in self.preset_modes_to_name.items()}

    @functools.cached_property
    def default_on_percentage(self) -> int:
        """Return the default on percentage."""
        return DEFAULT_ON_PERCENTAGE

    @functools.cached_property
    def speed_range(self) -> tuple[int, int]:
        """Return the range of speeds the fan supports. Off is not included."""
        return SPEED_RANGE

    @functools.cached_property
    def speed_count(self) -> int:
        """Return the number of speeds the fan supports."""
        return int_states_in_range(self.speed_range)

    @functools.cached_property
    def supported_features(self) -> FanEntityFeature:
        """Flag supported features."""
        return self._attr_supported_features

    @property
    def is_on(self) -> bool:
        """Return true if the entity is on."""
        return self.speed not in [SPEED_OFF, None]  # pylint: disable=no-member

    @functools.cached_property
    def percentage_step(self) -> float:
        """Return the step size for percentage."""
        return 100 / self.speed_count

    @functools.cached_property
    def speed_list(self) -> list[str]:
        """Get the list of available speeds."""
        speeds = [SPEED_OFF, *LEGACY_SPEED_LIST]
        if preset_modes := self.preset_modes:
            speeds.extend(preset_modes)
        return speeds

    @property
    def speed(self) -> str | None:
        """Return the current speed."""
        if preset_mode := self.preset_mode:
            return preset_mode
        if (percentage := self.percentage) is None:
            return None
        return self.percentage_to_speed(percentage)

    @property
    def state(self) -> FanState:
        """Return the state of the fan."""
        return FanState(
            **super().state.__dict__,
            preset_mode=self.preset_mode,
            percentage=self.percentage,
            is_on=self.is_on,
            speed=self.speed,
            preset_modes=self.preset_modes,
            supported_features=self.supported_features,
            speed_count=self.speed_count,
            speed_list=self.speed_list,
            speed_range=self.speed_range,
            default_on_percentage=self.default_on_percentage,
        )

    async def async_turn_on(
        self,
        speed: str | None = None,
        percentage: int | None = None,
        preset_mode: str | None = None,
    ) -> None:
        """Turn the entity on."""
        if preset_mode is not None:
            await self.async_set_preset_mode(preset_mode)
        elif speed is not None:
            await self.async_set_percentage(self.speed_to_percentage(speed))
        elif percentage is not None:
            await self.async_set_percentage(percentage)
        else:
            percentage = self.default_on_percentage
            await self.async_set_percentage(percentage)

    async def async_turn_off(self) -> None:
        """Turn the entity off."""
        await self.async_set_percentage(0)

    async def async_set_percentage(self, percentage: int) -> None:
        """Set the speed percentage of the fan."""
        fan_mode = math.ceil(percentage_to_ranged_value(self.speed_range, percentage))
        await self._async_set_fan_mode(fan_mode)

    async def async_set_preset_mode(self, preset_mode: str) -> None:
        """Set the preset mode for the fan."""
        try:
            mode = self.preset_name_to_mode[preset_mode]
        except KeyError as ex:
            raise NotValidPresetModeError(
                f"{preset_mode} is not a valid preset mode"
            ) from ex
        await self._async_set_fan_mode(mode)

    @abstractmethod
    async def _async_set_fan_mode(self, fan_mode: int) -> None:
        """Set the fan mode for the fan."""

    def handle_attribute_updated(
        self,
        event: AttributeReadEvent
        | AttributeReportedEvent
        | AttributeUpdatedEvent
        | AttributeWrittenEvent,
    ) -> None:
        """Handle state update from cluster."""
        self.maybe_emit_state_changed_event()

    def speed_to_percentage(self, speed: str) -> int:
        """Map a legacy speed to a percentage."""
        if speed in OFF_SPEED_VALUES:
            return 0
        if speed not in LEGACY_SPEED_LIST:
            raise ValueError(f"The speed {speed} is not a valid speed.")
        return ordered_list_item_to_percentage(LEGACY_SPEED_LIST, speed)

    def percentage_to_speed(self, percentage: int) -> str:
        """Map a percentage to a legacy speed."""
        if percentage == 0:
            return SPEED_OFF
        return percentage_to_ordered_list_item(LEGACY_SPEED_LIST, percentage)


@register_entity(hvac.Fan.cluster_id)
class Fan(BaseFan, PlatformEntity):
    """Representation of a ZHA fan."""

    _cluster_match = ClusterMatch(
        server_clusters=frozenset({hvac.Fan.cluster_id}),
        # We prefer Thermostat entities if possible
        feature_priority=(PlatformFeatureGroup.THERMOSTAT_FAN, -1),
    )

    _server_cluster_config = {
        hvac.Fan.cluster_id: ClusterConfig(
            bind=True,
            attributes={
                hvac.Fan.AttributeDefs.fan_mode: AttrConfig(
                    read_on_startup=True,
                    reporting=ReportingConfig(
                        min_interval=5, max_interval=900, reportable_change=1
                    ),
                ),
                hvac.Fan.AttributeDefs.fan_mode_sequence: AttrConfig(
                    read_on_startup=False,
                ),
            },
        ),
    }

    def __init__(
        self,
        endpoint: Endpoint,
        device: Device,
        **kwargs,
    ) -> None:
        """Initialize the fan."""
        super().__init__(endpoint=endpoint, device=device, **kwargs)
        self.recompute_capabilities()

    def on_add(self) -> None:
        """Run when entity is added."""
        super().on_add()
        for event_type in (
            AttributeReadEvent,
            AttributeReportedEvent,
            AttributeUpdatedEvent,
            AttributeWrittenEvent,
        ):
            self._on_remove_callbacks.append(
                self._cluster.on_event(
                    event_type.event_type, self.handle_attribute_updated
                )
            )

    @property
    def _fan_mode(self) -> int | None:
        """Return current fan mode."""
        return self._cluster.get(hvac.Fan.AttributeDefs.fan_mode.name)

    @property
    def percentage(self) -> int | None:
        """Return the current speed percentage."""
        fan_mode = self._fan_mode
        if fan_mode is None or fan_mode > self.speed_range[1]:
            return None
        if fan_mode == 0:
            return 0
        return ranged_value_to_percentage(self.speed_range, fan_mode)

    @property
    def preset_mode(self) -> str | None:
        """Return the current preset mode."""
        return self.preset_modes_to_name.get(self._fan_mode)

    async def _async_set_fan_mode(self, fan_mode: int) -> None:
        """Set the fan mode for the fan."""
        await write_attributes_safe(
            self._cluster, {hvac.Fan.AttributeDefs.fan_mode.name: fan_mode}
        )
        self.maybe_emit_state_changed_event()

    async def async_update(self) -> None:
        """Retrieve latest state."""
        self.debug("polling current state")
        await safe_read(
            self._cluster,
            [hvac.Fan.AttributeDefs.fan_mode.name],
            allow_cache=False,
            only_cache=False,
        )
        self.maybe_emit_state_changed_event()


@register_group_entity
class FanGroup(BaseFan, GroupEntity):
    """Representation of a fan group."""

    def __init__(self, group: Group):
        """Initialize a fan group."""
        self._cluster = group.endpoint[hvac.Fan.cluster_id]
        super().__init__(group)
        self._percentage: int | None = None
        self._preset_mode: str | None = None
        self.update()

    @property
    def percentage(self) -> int | None:
        """Return the current speed percentage."""
        return self._percentage

    @property
    def preset_mode(self) -> str | None:
        """Return the current preset mode."""
        return self._preset_mode

    async def _async_set_fan_mode(self, fan_mode: int) -> None:
        """Set the fan mode for the group."""
        await write_attributes_safe(self._cluster, {"fan_mode": fan_mode})
        self.maybe_emit_state_changed_event()

    def update(self, _: Any = None) -> None:
        """Query all members and determine the fan group state."""
        self.debug("Updating fan group entity state")
        platform_entities = self._group.get_platform_entities(self.PLATFORM)
        all_states = [cast(FanState, entity.state) for entity in platform_entities]
        self.debug(
            "All platform entity states for group entity members: %s", all_states
        )

        percentage_states = [state for state in all_states if state.percentage]
        preset_mode_states = [state for state in all_states if state.preset_mode]

        if percentage_states:
            self._percentage = percentage_states[0].percentage
            self._preset_mode = None
        elif preset_mode_states:
            self._preset_mode = preset_mode_states[0].preset_mode
            self._percentage = None
        else:
            self._percentage = None
            self._preset_mode = None

        self.maybe_emit_state_changed_event()


@register_entity(IKEA_AIR_PURIFIER_CLUSTER)
class IkeaFan(BaseFan, PlatformEntity):
    """Representation of an Ikea fan."""

    _attr_supported_features: FanEntityFeature = (
        FanEntityFeature.SET_SPEED
        | FanEntityFeature.PRESET_MODE
        | FanEntityFeature.TURN_OFF
        | FanEntityFeature.TURN_ON
    )

    _cluster_match = ClusterMatch(
        server_clusters=frozenset({IKEA_AIR_PURIFIER_CLUSTER}),
        models=frozenset({"STARKVIND Air purifier", "STARKVIND Air purifier table"}),
    )

    # Aggregated reporting/bind config for the whole STARKVIND manufacturer
    # cluster; sibling ChildLock/DisableLed switches don't need their own.
    _server_cluster_config = {
        IKEA_AIR_PURIFIER_CLUSTER: ClusterConfig(
            bind=True,
            attributes={
                "filter_run_time": AttrConfig(
                    read_on_startup=False,
                    reporting=ReportingConfig(
                        min_interval=30, max_interval=900, reportable_change=1
                    ),
                ),
                "replace_filter": AttrConfig(
                    read_on_startup=False,
                    reporting=ReportingConfig(
                        min_interval=0, max_interval=900, reportable_change=1
                    ),
                ),
                "filter_life_time": AttrConfig(
                    read_on_startup=False,
                    reporting=ReportingConfig(
                        min_interval=30, max_interval=900, reportable_change=1
                    ),
                ),
                "disable_led": AttrConfig(
                    read_on_startup=False,
                    reporting=ReportingConfig(
                        min_interval=0, max_interval=900, reportable_change=1
                    ),
                ),
                "air_quality_25pm": AttrConfig(
                    read_on_startup=False,
                    reporting=ReportingConfig(
                        min_interval=0, max_interval=900, reportable_change=1
                    ),
                ),
                "child_lock": AttrConfig(
                    read_on_startup=False,
                    reporting=ReportingConfig(
                        min_interval=0, max_interval=900, reportable_change=1
                    ),
                ),
                "fan_mode": AttrConfig(
                    read_on_startup=False,
                    reporting=ReportingConfig(
                        min_interval=0, max_interval=900, reportable_change=1
                    ),
                ),
                "fan_speed": AttrConfig(
                    read_on_startup=False,
                    reporting=ReportingConfig(
                        min_interval=0, max_interval=900, reportable_change=1
                    ),
                ),
                "device_run_time": AttrConfig(
                    read_on_startup=False,
                    reporting=ReportingConfig(
                        min_interval=30, max_interval=900, reportable_change=1
                    ),
                ),
            },
        ),
    }

    def on_add(self) -> None:
        """Run when entity is added."""
        super().on_add()
        for event_type in (
            AttributeReadEvent,
            AttributeReportedEvent,
            AttributeUpdatedEvent,
            AttributeWrittenEvent,
        ):
            self._on_remove_callbacks.append(
                self._cluster.on_event(
                    event_type.event_type, self.handle_attribute_updated
                )
            )

    @property
    def _fan_mode(self) -> int | None:
        """Return current fan mode."""
        return self._cluster.get("fan_mode")

    @property
    def _fan_speed(self) -> int | None:
        """Return current fan speed."""
        return self._cluster.get("fan_speed")

    @property
    def preset_mode(self) -> str | None:
        """Return the current preset mode."""
        return self.preset_modes_to_name.get(self._fan_mode)

    @functools.cached_property
    def preset_modes_to_name(self) -> dict[int, str]:
        """Return a dict from preset mode to name."""
        return {1: PRESET_MODE_AUTO}

    @functools.cached_property
    def speed_range(self) -> tuple[int, int]:
        """Return the range of speeds the fan supports. Off is not included."""

        # 1 is not a speed, but auto mode and is filtered out in async_set_percentage
        return 1, 10

    @property
    def percentage(self) -> int | None:
        """Return the current speed percentage."""
        fan_speed = self._fan_speed
        if fan_speed is None:
            return None
        if fan_speed == 0:
            return 0
        return ranged_value_to_percentage(
            # Starkvind has an additional fan_speed attribute that we can use to
            # get the speed even if fan_mode is set to auto.
            self.speed_range,
            fan_speed,
        )

    async def async_turn_on(
        self,
        speed: str | None = None,
        percentage: int | None = None,
        preset_mode: str | None = None,
    ) -> None:
        """Turn the entity on."""
        # Starkvind turns on in auto mode by default.
        if speed is None and percentage is None and preset_mode is None:
            await self.async_set_preset_mode("auto")
        else:
            await super().async_turn_on(speed, percentage, preset_mode)

    async def _async_set_fan_mode(self, fan_mode: int) -> None:
        """Set the fan mode for the fan."""
        await write_attributes_safe(self._cluster, {"fan_mode": fan_mode})
        self.maybe_emit_state_changed_event()

    async def async_set_percentage(self, percentage: int) -> None:
        """Set the speed percentage of the fan."""
        fan_mode = math.ceil(percentage_to_ranged_value(self.speed_range, percentage))
        # 1 is a mode, not a speed, so we skip to 2 instead.
        if fan_mode == 1:
            fan_mode = 2
        await self._async_set_fan_mode(fan_mode)

    async def async_update(self) -> None:
        """Retrieve latest state."""
        self.debug("polling current state")
        await safe_read(
            self._cluster,
            ["fan_mode", "fan_speed"],
            allow_cache=False,
            only_cache=False,
        )
        self.maybe_emit_state_changed_event()


@register_entity(hvac.Fan.cluster_id)
class KofFan(Fan):
    """Representation of a fan made by King Of Fans."""

    _attr_supported_features = (
        FanEntityFeature.SET_SPEED
        | FanEntityFeature.PRESET_MODE
        | FanEntityFeature.TURN_OFF
        | FanEntityFeature.TURN_ON
    )

    _cluster_match = ClusterMatch(
        server_clusters=frozenset({hvac.Fan.cluster_id}),
        models=frozenset({"HBUniversalCFRemote", "HDC52EastwindFan"}),
        feature_priority=(PlatformFeatureGroup.THERMOSTAT_FAN, 1),
    )

    @functools.cached_property
    def speed_range(self) -> tuple[int, int]:
        """Return the range of speeds the fan supports. Off is not included."""
        return (1, 4)

    @functools.cached_property
    def preset_modes_to_name(self) -> dict[int, str]:
        """Return a dict from preset mode to name."""
        return {6: PRESET_MODE_SMART}
