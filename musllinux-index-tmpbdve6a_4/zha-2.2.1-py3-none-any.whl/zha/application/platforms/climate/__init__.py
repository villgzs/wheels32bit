"""Climate on Zigbee Home Automation."""  # pylint: disable=too-many-lines

from __future__ import annotations

from abc import ABC, abstractmethod
from asyncio import Task
from dataclasses import dataclass
import datetime as dt
import functools
from typing import TYPE_CHECKING

from zigpy.profiles import zha
from zigpy.zcl import (
    AttributeReadEvent,
    AttributeReportedEvent,
    AttributeUpdatedEvent,
    AttributeWrittenEvent,
    ReportingConfig,
)
from zigpy.zcl.clusters.hvac import (
    Fan as FanCluster,
    FanMode,
    RunningState,
    SystemMode,
    Thermostat as ThermostatCluster,
)

from zha.application import Platform
from zha.application.helpers import write_attributes_safe
from zha.application.platforms import (
    AttrConfig,
    BaseEntityState,
    ClusterConfig,
    ClusterMatch,
    PlatformEntity,
    PlatformFeatureGroup,
    register_entity,
)
from zha.application.platforms.climate.const import (
    ATTR_OCCP_COOL_SETPT,
    ATTR_OCCP_HEAT_SETPT,
    FAN_AUTO,
    FAN_ON,
    HVAC_MODE_2_SYSTEM,
    PRECISION_TENTHS,
    SEQ_OF_OPERATION,
    SYSTEM_MODE_2_HVAC,
    ZCL_TEMP,
    ClimateEntityFeature,
    HVACAction,
    HVACMode,
    Preset,
)
from zha.decorators import periodic
from zha.units import UnitOfTemperature

if TYPE_CHECKING:
    from zha.zigbee.device import Device
    from zha.zigbee.endpoint import Endpoint


@dataclass(frozen=True, kw_only=True)
class ClimateState(BaseEntityState):
    """State for climate entities."""

    current_temperature: float | None
    outdoor_temperature: float | None
    target_temperature: float | None
    target_temperature_high: float | None
    target_temperature_low: float | None
    hvac_action: HVACAction | None
    hvac_mode: HVACMode | None
    preset_mode: str | None
    fan_mode: str | None
    max_temp: float
    min_temp: float
    supported_features: ClimateEntityFeature
    fan_modes: list[str] | None
    preset_modes: list[str] | None
    hvac_modes: list[HVACMode]


@dataclass(frozen=True, kw_only=True)
class ThermostatState(ClimateState):
    """State for thermostat entities with extra attributes."""

    sys_mode: str | None = None
    occupancy: int | None = None
    occupied_cooling_setpoint: int | None = None
    occupied_heating_setpoint: int | None = None
    pi_heating_demand: int | None = None
    pi_cooling_demand: int | None = None
    unoccupied_cooling_setpoint: int | None = None
    unoccupied_heating_setpoint: int | None = None


class BaseThermostat(PlatformEntity, ABC):
    """Abstract base class for climate entities."""

    PLATFORM = Platform.CLIMATE

    @property
    def state(self) -> ClimateState:
        """Get the state of the climate entity."""
        return ClimateState(
            **super().state.__dict__,
            current_temperature=self.current_temperature,
            outdoor_temperature=self.outdoor_temperature,
            target_temperature=self.target_temperature,
            target_temperature_high=self.target_temperature_high,
            target_temperature_low=self.target_temperature_low,
            hvac_action=self.hvac_action,
            hvac_mode=self.hvac_mode,
            preset_mode=self.preset_mode,
            fan_mode=self.fan_mode,
            max_temp=self.max_temp,
            min_temp=self.min_temp,
            supported_features=self.supported_features,
            fan_modes=self.fan_modes,
            preset_modes=self.preset_modes,
            hvac_modes=self.hvac_modes,
        )

    @property
    @abstractmethod
    def current_temperature(self) -> float | None:
        """Return the current temperature."""

    @property
    @abstractmethod
    def outdoor_temperature(self) -> float | None:
        """Return the outdoor temperature."""

    @property
    @abstractmethod
    def target_temperature(self) -> float | None:
        """Return the temperature we try to reach."""

    @property
    @abstractmethod
    def target_temperature_high(self) -> float | None:
        """Return the upper bound temperature we try to reach."""

    @property
    @abstractmethod
    def target_temperature_low(self) -> float | None:
        """Return the lower bound temperature we try to reach."""

    @property
    @abstractmethod
    def hvac_action(self) -> HVACAction | None:
        """Return the current HVAC action."""

    @property
    @abstractmethod
    def hvac_mode(self) -> HVACMode | None:
        """Return HVAC operation mode."""

    @property
    @abstractmethod
    def hvac_modes(self) -> list[HVACMode]:
        """Return the list of available HVAC operation modes."""

    @property
    @abstractmethod
    def preset_mode(self) -> str | None:
        """Return current preset mode."""

    @property
    @abstractmethod
    def preset_modes(self) -> list[str] | None:
        """Return supported preset modes."""

    @property
    @abstractmethod
    def fan_mode(self) -> str | None:
        """Return current FAN mode."""

    @property
    @abstractmethod
    def fan_modes(self) -> list[str] | None:
        """Return supported FAN modes."""

    @property
    @abstractmethod
    def max_temp(self) -> float:
        """Return the maximum temperature."""

    @property
    @abstractmethod
    def min_temp(self) -> float:
        """Return the minimum temperature."""

    @property
    @abstractmethod
    def supported_features(self) -> ClimateEntityFeature:
        """Return the list of supported features."""

    @abstractmethod
    async def async_set_fan_mode(self, fan_mode: str) -> None:
        """Set fan mode."""

    @abstractmethod
    async def async_set_hvac_mode(self, hvac_mode: HVACMode) -> None:
        """Set new target operation mode."""

    @abstractmethod
    async def async_set_preset_mode(self, preset_mode: str) -> None:
        """Set new preset mode."""

    @abstractmethod
    async def async_set_temperature(
        self,
        target_temp_low: float | None = None,
        target_temp_high: float | None = None,
        temperature: float | None = None,
        hvac_mode: HVACMode | None = None,
    ) -> None:
        """Set new target temperature."""


@register_entity(ThermostatCluster.cluster_id)
class Thermostat(BaseThermostat):
    """Representation of a ZHA Thermostat device."""

    DEFAULT_MAX_TEMP = 35
    DEFAULT_MIN_TEMP = 7

    _attr_primary_weight = 10
    _attr_precision = PRECISION_TENTHS
    _attr_temperature_unit = UnitOfTemperature.CELSIUS
    _attr_translation_key: str = "thermostat"
    _enable_turn_on_off_backwards_compatibility = False

    _cluster_match = ClusterMatch(
        server_clusters=frozenset({ThermostatCluster.cluster_id}),
        optional_server_clusters=frozenset({FanCluster.cluster_id}),
        # We prefer Thermostat entities over Fan entities if possible
        feature_priority=(PlatformFeatureGroup.THERMOSTAT_FAN, 1),
    )

    _server_cluster_config = {
        ThermostatCluster.cluster_id: ClusterConfig(
            bind=True,
            attributes={
                ThermostatCluster.AttributeDefs.local_temperature: AttrConfig(
                    read_on_startup=True,
                    reporting=ReportingConfig(
                        min_interval=30, max_interval=900, reportable_change=25
                    ),
                ),
                ThermostatCluster.AttributeDefs.occupied_cooling_setpoint: AttrConfig(
                    read_on_startup=True,
                    reporting=ReportingConfig(
                        min_interval=30, max_interval=900, reportable_change=25
                    ),
                ),
                ThermostatCluster.AttributeDefs.occupied_heating_setpoint: AttrConfig(
                    read_on_startup=True,
                    reporting=ReportingConfig(
                        min_interval=30, max_interval=900, reportable_change=25
                    ),
                ),
                ThermostatCluster.AttributeDefs.unoccupied_cooling_setpoint: AttrConfig(
                    read_on_startup=True,
                    reporting=ReportingConfig(
                        min_interval=30, max_interval=900, reportable_change=25
                    ),
                ),
                ThermostatCluster.AttributeDefs.unoccupied_heating_setpoint: AttrConfig(
                    read_on_startup=True,
                    reporting=ReportingConfig(
                        min_interval=30, max_interval=900, reportable_change=25
                    ),
                ),
                ThermostatCluster.AttributeDefs.running_mode: AttrConfig(
                    read_on_startup=True,
                    reporting=ReportingConfig(
                        min_interval=30, max_interval=900, reportable_change=1
                    ),
                ),
                ThermostatCluster.AttributeDefs.running_state: AttrConfig(
                    read_on_startup=True,
                    reporting=ReportingConfig(
                        min_interval=30, max_interval=900, reportable_change=1
                    ),
                ),
                ThermostatCluster.AttributeDefs.system_mode: AttrConfig(
                    read_on_startup=True,
                    reporting=ReportingConfig(
                        min_interval=30, max_interval=900, reportable_change=1
                    ),
                ),
                ThermostatCluster.AttributeDefs.occupancy: AttrConfig(
                    read_on_startup=True,
                    reporting=ReportingConfig(
                        min_interval=30, max_interval=900, reportable_change=1
                    ),
                ),
                ThermostatCluster.AttributeDefs.pi_cooling_demand: AttrConfig(
                    read_on_startup=True,
                    reporting=ReportingConfig(
                        min_interval=30, max_interval=900, reportable_change=5
                    ),
                ),
                ThermostatCluster.AttributeDefs.pi_heating_demand: AttrConfig(
                    read_on_startup=True,
                    reporting=ReportingConfig(
                        min_interval=30, max_interval=900, reportable_change=5
                    ),
                ),
                ThermostatCluster.AttributeDefs.abs_min_heat_setpoint_limit: AttrConfig(
                    read_on_startup=False,
                ),
                ThermostatCluster.AttributeDefs.abs_max_heat_setpoint_limit: AttrConfig(
                    read_on_startup=False,
                ),
                ThermostatCluster.AttributeDefs.abs_min_cool_setpoint_limit: AttrConfig(
                    read_on_startup=False,
                ),
                ThermostatCluster.AttributeDefs.abs_max_cool_setpoint_limit: AttrConfig(
                    read_on_startup=False,
                ),
                ThermostatCluster.AttributeDefs.ctrl_sequence_of_oper: AttrConfig(
                    read_on_startup=True,
                ),
                ThermostatCluster.AttributeDefs.max_cool_setpoint_limit: AttrConfig(
                    read_on_startup=False,
                ),
                ThermostatCluster.AttributeDefs.max_heat_setpoint_limit: AttrConfig(
                    read_on_startup=False,
                ),
                ThermostatCluster.AttributeDefs.min_cool_setpoint_limit: AttrConfig(
                    read_on_startup=False,
                ),
                ThermostatCluster.AttributeDefs.min_heat_setpoint_limit: AttrConfig(
                    read_on_startup=False,
                ),
                ThermostatCluster.AttributeDefs.local_temperature_calibration: AttrConfig(
                    read_on_startup=False,
                ),
                ThermostatCluster.AttributeDefs.setpoint_change_source: AttrConfig(
                    read_on_startup=False,
                ),
                ThermostatCluster.AttributeDefs.setpoint_change_source_timestamp: AttrConfig(
                    read_on_startup=False,
                ),
            },
        ),
        FanCluster.cluster_id: ClusterConfig(
            bind=True,
            attributes={
                FanCluster.AttributeDefs.fan_mode: AttrConfig(
                    read_on_startup=True,
                    reporting=ReportingConfig(
                        min_interval=5, max_interval=900, reportable_change=1
                    ),
                ),
                FanCluster.AttributeDefs.fan_mode_sequence: AttrConfig(
                    read_on_startup=False,
                ),
            },
        ),
    }

    def __init__(
        self,
        endpoint: Endpoint,
        device: Device,
        **kwargs,
    ):
        """Initialize ZHA Thermostat instance."""
        legacy_discovery_unique_id = (
            f"{endpoint.device.ieee}-{endpoint.id}"
            if endpoint.zigpy_endpoint.device_type == zha.DeviceType.THERMOSTAT
            else f"{endpoint.device.ieee}-{endpoint.id}-{int(ThermostatCluster.cluster_id)}"
        )
        super().__init__(
            endpoint=endpoint,
            device=device,
            **kwargs,
            legacy_discovery_unique_id=legacy_discovery_unique_id,
        )
        self._preset: Preset | str = Preset.NONE
        self._presets: list[Preset | str] = []

        self._cluster = endpoint.zigpy_endpoint.in_clusters[
            ThermostatCluster.cluster_id
        ]
        self._fan_cluster = endpoint.zigpy_endpoint.in_clusters.get(
            FanCluster.cluster_id
        )

        self._supported_features = ClimateEntityFeature(0)
        self.recompute_capabilities()

    @property
    def _local_temperature(self) -> int | None:
        return self._cluster.get(ThermostatCluster.AttributeDefs.local_temperature.name)

    @property
    def _outdoor_temperature(self) -> int | None:
        return self._cluster.get(
            ThermostatCluster.AttributeDefs.outdoor_temperature.name
        )

    @property
    def _occupancy(self) -> int | None:
        return self._cluster.get(ThermostatCluster.AttributeDefs.occupancy.name)

    @property
    def _occupied_cooling_setpoint(self) -> int | None:
        return self._cluster.get(
            ThermostatCluster.AttributeDefs.occupied_cooling_setpoint.name
        )

    @property
    def _occupied_heating_setpoint(self) -> int | None:
        return self._cluster.get(
            ThermostatCluster.AttributeDefs.occupied_heating_setpoint.name
        )

    @property
    def _unoccupied_cooling_setpoint(self) -> int | None:
        return self._cluster.get(
            ThermostatCluster.AttributeDefs.unoccupied_cooling_setpoint.name
        )

    @property
    def _unoccupied_heating_setpoint(self) -> int | None:
        return self._cluster.get(
            ThermostatCluster.AttributeDefs.unoccupied_heating_setpoint.name
        )

    @property
    def _pi_cooling_demand(self) -> int | None:
        return self._cluster.get(ThermostatCluster.AttributeDefs.pi_cooling_demand.name)

    @property
    def _pi_heating_demand(self) -> int | None:
        return self._cluster.get(ThermostatCluster.AttributeDefs.pi_heating_demand.name)

    @property
    def _running_mode(self) -> int | None:
        return self._cluster.get(ThermostatCluster.AttributeDefs.running_mode.name)

    @property
    def _running_state(self) -> int | None:
        return self._cluster.get(ThermostatCluster.AttributeDefs.running_state.name)

    @property
    def _system_mode(self) -> int | None:
        return self._cluster.get(ThermostatCluster.AttributeDefs.system_mode.name)

    @property
    def _ctrl_sequence_of_oper(self) -> int:
        return self._cluster.get(
            ThermostatCluster.AttributeDefs.ctrl_sequence_of_oper.name, 0xFF
        )

    @property
    def _abs_max_cool_setpoint_limit(self) -> int:
        return self._cluster.get(
            ThermostatCluster.AttributeDefs.abs_max_cool_setpoint_limit.name, 3200
        )

    @property
    def _abs_min_cool_setpoint_limit(self) -> int:
        return self._cluster.get(
            ThermostatCluster.AttributeDefs.abs_min_cool_setpoint_limit.name, 1600
        )

    @property
    def _abs_max_heat_setpoint_limit(self) -> int:
        return self._cluster.get(
            ThermostatCluster.AttributeDefs.abs_max_heat_setpoint_limit.name, 3000
        )

    @property
    def _abs_min_heat_setpoint_limit(self) -> int:
        return self._cluster.get(
            ThermostatCluster.AttributeDefs.abs_min_heat_setpoint_limit.name, 700
        )

    @property
    def _max_cool_setpoint_limit(self) -> int:
        sp_limit = self._cluster.get(
            ThermostatCluster.AttributeDefs.max_cool_setpoint_limit.name
        )
        if sp_limit is None:
            return self._abs_max_cool_setpoint_limit
        return sp_limit

    @property
    def _min_cool_setpoint_limit(self) -> int:
        sp_limit = self._cluster.get(
            ThermostatCluster.AttributeDefs.min_cool_setpoint_limit.name
        )
        if sp_limit is None:
            return self._abs_min_cool_setpoint_limit
        return sp_limit

    @property
    def _max_heat_setpoint_limit(self) -> int:
        sp_limit = self._cluster.get(
            ThermostatCluster.AttributeDefs.max_heat_setpoint_limit.name
        )
        if sp_limit is None:
            return self._abs_max_heat_setpoint_limit
        return sp_limit

    @property
    def _min_heat_setpoint_limit(self) -> int:
        sp_limit = self._cluster.get(
            ThermostatCluster.AttributeDefs.min_heat_setpoint_limit.name
        )
        if sp_limit is None:
            return self._abs_min_heat_setpoint_limit
        return sp_limit

    async def _async_get_occupancy(self) -> bool | None:
        """Get unreportable occupancy attribute."""
        res, fail = await self._cluster.read_attributes(
            [ThermostatCluster.AttributeDefs.occupancy.name]
        )
        self.debug("read 'occupancy' attr, success: %s, fail: %s", res, fail)
        if ThermostatCluster.AttributeDefs.occupancy.name not in res:
            return None
        return bool(self._occupancy)

    def recompute_capabilities(self) -> None:
        """Recompute capabilities and feature flags."""
        super().recompute_capabilities()
        self._supported_features = (
            ClimateEntityFeature.TARGET_TEMPERATURE
            | ClimateEntityFeature.TURN_OFF
            | ClimateEntityFeature.TURN_ON
        )

        if HVACMode.HEAT_COOL in self.hvac_modes:
            self._supported_features |= ClimateEntityFeature.TARGET_TEMPERATURE_RANGE

        if self._fan_cluster is not None:
            self._supported_features |= ClimateEntityFeature.FAN_MODE

    def on_add(self) -> None:
        """Run when entity is added."""
        super().on_add()
        for event_type in (
            AttributeReadEvent,
            AttributeReportedEvent,
            AttributeUpdatedEvent,
            AttributeWrittenEvent,
        ):
            self._on_remove_callbacks.append(
                self._cluster.on_event(
                    event_type.event_type, self.handle_attribute_updated
                )
            )

    @property
    def state(self) -> ThermostatState:
        """Get the state of the thermostat."""
        return ThermostatState(
            **super().state.__dict__,
            sys_mode=self.system_mode_string,
            occupancy=self._occupancy,
            occupied_cooling_setpoint=self._occupied_cooling_setpoint,
            occupied_heating_setpoint=self._occupied_heating_setpoint,
            pi_heating_demand=self._pi_heating_demand,
            pi_cooling_demand=self._pi_cooling_demand,
            unoccupied_cooling_setpoint=self._unoccupied_cooling_setpoint,
            unoccupied_heating_setpoint=self._unoccupied_heating_setpoint,
        )

    @property
    def system_mode_string(self) -> str | None:
        """Return a formatted system mode string."""
        if self.hvac_mode is None:
            return None
        system_mode = SYSTEM_MODE_2_HVAC.get(self._system_mode, "unknown")
        return f"[{self._system_mode}]/{system_mode}"

    @property
    def current_temperature(self):
        """Return the current temperature."""
        if self._local_temperature is None:
            return None
        return self._local_temperature / ZCL_TEMP

    @property
    def outdoor_temperature(self):
        """Return the outdoor temperature."""
        if self._outdoor_temperature is None:
            return None
        return self._outdoor_temperature / ZCL_TEMP

    @property
    def fan_mode(self) -> str | None:
        """Return current FAN mode."""
        running_state = self._running_state
        if running_state is None:
            return FAN_AUTO

        if running_state & (
            RunningState.Fan_State_On
            | RunningState.Fan_2nd_Stage_On
            | RunningState.Fan_3rd_Stage_On
        ):
            return FAN_ON
        return FAN_AUTO

    @functools.cached_property
    def fan_modes(self) -> list[str] | None:
        """Return supported FAN modes."""
        if self._fan_cluster is None:
            return None
        return [FAN_AUTO, FAN_ON]

    @property
    def hvac_action(self) -> HVACAction | None:
        """Return the current HVAC action."""
        if self._pi_heating_demand is None and self._pi_cooling_demand is None:
            return self._rm_rs_action
        return self._pi_demand_action

    @property
    def _rm_rs_action(self) -> HVACAction | None:
        """Return the current HVAC action based on running mode and running state."""

        if (running_state := self._running_state) is None:
            return None
        if running_state & (
            RunningState.Heat_State_On | RunningState.Heat_2nd_Stage_On
        ):
            return HVACAction.HEATING
        if running_state & (
            RunningState.Cool_State_On | RunningState.Cool_2nd_Stage_On
        ):
            return HVACAction.COOLING
        if running_state & (
            RunningState.Fan_State_On
            | RunningState.Fan_2nd_Stage_On
            | RunningState.Fan_3rd_Stage_On
        ):
            return HVACAction.FAN
        if running_state & RunningState.Idle:
            return HVACAction.IDLE
        if self.hvac_mode != HVACMode.OFF:
            return HVACAction.IDLE
        return HVACAction.OFF

    @property
    def _pi_demand_action(self) -> HVACAction | None:
        """Return the current HVAC action based on pi_demands."""

        heating_demand = self._pi_heating_demand
        if heating_demand is not None and heating_demand > 0:
            return HVACAction.HEATING
        cooling_demand = self._pi_cooling_demand
        if cooling_demand is not None and cooling_demand > 0:
            return HVACAction.COOLING

        if self.hvac_mode != HVACMode.OFF:
            return HVACAction.IDLE
        return HVACAction.OFF

    @property
    def hvac_mode(self) -> HVACMode | None:
        """Return HVAC operation mode."""
        return SYSTEM_MODE_2_HVAC.get(self._system_mode)

    @property
    def hvac_modes(self) -> list[HVACMode]:
        """Return the list of available HVAC operation modes."""
        return SEQ_OF_OPERATION.get(self._ctrl_sequence_of_oper, [HVACMode.OFF])

    @property
    def preset_mode(self) -> str:
        """Return current preset mode."""
        return self._preset

    @property
    def preset_modes(self) -> list[str] | None:
        """Return supported preset modes."""
        return self._presets

    @property
    def supported_features(self) -> ClimateEntityFeature:
        """Return the list of supported features."""
        return self._supported_features

    @property
    def target_temperature(self):
        """Return the temperature we try to reach."""
        temp = None
        if self.hvac_mode == HVACMode.COOL:
            if self.preset_mode == Preset.AWAY:
                temp = self._unoccupied_cooling_setpoint
            else:
                temp = self._occupied_cooling_setpoint
        elif self.hvac_mode == HVACMode.HEAT:
            if self.preset_mode == Preset.AWAY:
                temp = self._unoccupied_heating_setpoint
            else:
                temp = self._occupied_heating_setpoint
        if temp is None:
            return temp
        return round(temp / ZCL_TEMP, 1)

    @property
    def target_temperature_high(self):
        """Return the upper bound temperature we try to reach."""
        if self.hvac_mode != HVACMode.HEAT_COOL:
            return None
        if self.preset_mode == Preset.AWAY:
            temp = self._unoccupied_cooling_setpoint
        else:
            temp = self._occupied_cooling_setpoint

        if temp is None:
            return temp

        return round(temp / ZCL_TEMP, 1)

    @property
    def target_temperature_low(self):
        """Return the lower bound temperature we try to reach."""
        if self.hvac_mode != HVACMode.HEAT_COOL:
            return None
        if self.preset_mode == Preset.AWAY:
            temp = self._unoccupied_heating_setpoint
        else:
            temp = self._occupied_heating_setpoint

        if temp is None:
            return temp
        return round(temp / ZCL_TEMP, 1)

    @property
    def max_temp(self) -> float:
        """Return the maximum temperature."""
        temps = []
        if HVACMode.HEAT in self.hvac_modes:
            temps.append(self._max_heat_setpoint_limit)
        if HVACMode.COOL in self.hvac_modes:
            temps.append(self._max_cool_setpoint_limit)

        if not temps:
            return self.DEFAULT_MAX_TEMP
        return round(max(temps) / ZCL_TEMP, 1)

    @property
    def min_temp(self) -> float:
        """Return the minimum temperature."""
        temps = []
        if HVACMode.HEAT in self.hvac_modes:
            temps.append(self._min_heat_setpoint_limit)
        if HVACMode.COOL in self.hvac_modes:
            temps.append(self._min_cool_setpoint_limit)

        if not temps:
            return self.DEFAULT_MIN_TEMP
        return round(min(temps) / ZCL_TEMP, 1)

    def handle_attribute_updated(
        self,
        event: AttributeReadEvent
        | AttributeReportedEvent
        | AttributeUpdatedEvent
        | AttributeWrittenEvent,
    ) -> None:
        """Handle attribute update from device."""
        self.device.gateway.async_create_task(self._handle_attribute_updated(event))

    async def _handle_attribute_updated(
        self,
        event: AttributeReadEvent
        | AttributeReportedEvent
        | AttributeUpdatedEvent
        | AttributeWrittenEvent,
    ) -> None:
        """Handle attribute update from device."""
        if (
            event.attribute_name in (ATTR_OCCP_COOL_SETPT, ATTR_OCCP_HEAT_SETPT)
            and self.preset_mode == Preset.AWAY
            and await self._async_get_occupancy() is True
        ):
            # occupancy attribute is an unreportable attribute, but if we get
            # an attribute update for an "occupied" setpoint, there's a chance
            # occupancy has changed
            self._preset = Preset.NONE

        self.debug("Attribute '%s' = %s update", event.attribute_name, event.value)
        self.maybe_emit_state_changed_event()

    async def async_set_fan_mode(self, fan_mode: str) -> None:
        """Set fan mode."""
        if self._fan_cluster is None:
            self.warning("Fan cluster is not available")
            return

        if not self.fan_modes or fan_mode not in self.fan_modes:
            self.warning("Unsupported '%s' fan mode", fan_mode)
            return

        mode = FanMode.On if fan_mode == FAN_ON else FanMode.Auto

        await write_attributes_safe(
            self._fan_cluster, {FanCluster.AttributeDefs.fan_mode.name: mode}
        )

    async def async_set_hvac_mode(self, hvac_mode: HVACMode) -> None:
        """Set new target operation mode."""
        if hvac_mode not in self.hvac_modes:
            self.warning(
                "can't set '%s' mode. Supported modes are: %s",
                hvac_mode,
                self.hvac_modes,
            )
            return

        await write_attributes_safe(
            self._cluster,
            {
                ThermostatCluster.AttributeDefs.system_mode.name: HVAC_MODE_2_SYSTEM[
                    hvac_mode
                ]
            },
        )
        self.maybe_emit_state_changed_event()

    async def async_set_preset_mode(self, preset_mode: str) -> None:
        """Set new preset mode."""
        if not self.preset_modes or preset_mode not in self.preset_modes:
            self.debug("Preset mode '%s' is not supported", preset_mode)
            return

        if self.preset_mode not in (
            preset_mode,
            Preset.NONE,
        ):
            await self.async_preset_handler(self.preset_mode, enable=False)

        if preset_mode != Preset.NONE:
            await self.async_preset_handler(preset_mode, enable=True)

        self._preset = preset_mode
        self.maybe_emit_state_changed_event()

    async def _async_set_heating_setpoint(
        self, temperature: int, is_away: bool
    ) -> None:
        attr = (
            ThermostatCluster.AttributeDefs.unoccupied_heating_setpoint.name
            if is_away
            else ThermostatCluster.AttributeDefs.occupied_heating_setpoint.name
        )
        await write_attributes_safe(self._cluster, {attr: temperature})

    async def _async_set_cooling_setpoint(
        self, temperature: int, is_away: bool
    ) -> None:
        attr = (
            ThermostatCluster.AttributeDefs.unoccupied_cooling_setpoint.name
            if is_away
            else ThermostatCluster.AttributeDefs.occupied_cooling_setpoint.name
        )
        await write_attributes_safe(self._cluster, {attr: temperature})

    async def async_set_temperature(
        self,
        target_temp_low: float | None = None,
        target_temp_high: float | None = None,
        temperature: float | None = None,
        hvac_mode: HVACMode | None = None,
    ) -> None:
        """Set new target temperature."""
        if hvac_mode is not None:
            await self.async_set_hvac_mode(hvac_mode)

        is_away = self.preset_mode == Preset.AWAY

        if self.hvac_mode == HVACMode.HEAT_COOL:
            if target_temp_low is not None:
                await self._async_set_heating_setpoint(
                    temperature=int(target_temp_low * ZCL_TEMP),
                    is_away=is_away,
                )
            if target_temp_high is not None:
                await self._async_set_cooling_setpoint(
                    temperature=int(target_temp_high * ZCL_TEMP),
                    is_away=is_away,
                )
        elif temperature is not None:
            if self.hvac_mode == HVACMode.COOL:
                await self._async_set_cooling_setpoint(
                    temperature=int(temperature * ZCL_TEMP),
                    is_away=is_away,
                )
            elif self.hvac_mode == HVACMode.HEAT:
                await self._async_set_heating_setpoint(
                    temperature=int(temperature * ZCL_TEMP),
                    is_away=is_away,
                )
            else:
                self.debug("Not setting temperature for '%s' mode", self.hvac_mode)
                return
        else:
            self.debug("incorrect temperature setting for '%s' mode", self.hvac_mode)
            return

        self.maybe_emit_state_changed_event()

    async def async_preset_handler(self, preset: str, enable: bool = False) -> None:
        """Set the preset mode via handler."""

        handler = getattr(self, f"async_preset_handler_{preset}")
        await handler(enable)


SINOPE_MANUFACTURER_CLUSTER = 0xFF01


@register_entity(ThermostatCluster.cluster_id)
class SinopeTechnologiesThermostat(Thermostat):
    """Sinope Technologies Thermostat."""

    manufacturer = 0x119C
    __polling_interval: int

    _cluster_match = ClusterMatch(
        server_clusters=frozenset(
            {ThermostatCluster.cluster_id, SINOPE_MANUFACTURER_CLUSTER}
        ),
        manufacturers=frozenset({"Sinope Technologies"}),
    )

    def __init__(
        self,
        endpoint: Endpoint,
        device: Device,
        **kwargs,
    ):
        """Initialize ZHA Thermostat instance."""
        super().__init__(endpoint=endpoint, device=device, **kwargs)
        self._presets = [Preset.AWAY, Preset.NONE]
        self._sinope_cluster = endpoint.zigpy_endpoint.in_clusters[
            SINOPE_MANUFACTURER_CLUSTER
        ]
        self._time_update_task: Task | None = None

    def recompute_capabilities(self) -> None:
        """Recompute capabilities and feature flags."""
        super().recompute_capabilities()
        self._supported_features |= ClimateEntityFeature.PRESET_MODE

    def on_add(self) -> None:
        """Run when entity is added."""
        super().on_add()
        self.start_polling()

    def start_polling(self) -> None:
        """Start polling."""
        self._time_update_task = self.device.gateway.async_create_background_task(
            self._update_time(),
            name=f"sinope_time_updater_{self.unique_id}",
            eager_start=True,
            untracked=True,
        )
        self._tracked_tasks.append(self._time_update_task)
        self.debug(
            "started time updating interval of %s",
            getattr(self, "__polling_interval"),
        )

    def enable(self) -> None:
        """Enable the entity."""
        super().enable()
        self.start_polling()

    def disable(self) -> None:
        """Disable the entity."""
        super().disable()
        if self._time_update_task:
            self._tracked_tasks.remove(self._time_update_task)
            self._time_update_task.cancel()
            self._time_update_task = None

    @periodic((2700, 4500))
    async def _update_time(self) -> None:
        await self._async_update_time()

    @property
    def _rm_rs_action(self) -> HVACAction:
        """Return the current HVAC action based on running mode and running state."""

        running_mode = self._running_mode
        if running_mode == SystemMode.Heat:
            return HVACAction.HEATING
        if running_mode == SystemMode.Cool:
            return HVACAction.COOLING

        running_state = self._running_state
        if running_state and running_state & (
            RunningState.Fan_State_On
            | RunningState.Fan_2nd_Stage_On
            | RunningState.Fan_3rd_Stage_On
        ):
            return HVACAction.FAN
        if self.hvac_mode != HVACMode.OFF and running_mode == SystemMode.Off:
            return HVACAction.IDLE
        return HVACAction.OFF

    async def _async_update_time(self) -> None:
        """Update thermostat's time display."""

        now = dt.datetime.now(self._device.gateway.config.local_timezone)
        secs_2k = (
            now.replace(tzinfo=None) - dt.datetime(2000, 1, 1, 0, 0, 0, 0)
        ).total_seconds()

        self.debug("Updating time: %s", secs_2k)
        await write_attributes_safe(
            self._sinope_cluster,
            {"secs_since_2k": secs_2k},
            manufacturer=self.manufacturer,
        )

    async def async_preset_handler_away(self, is_away: bool = False) -> None:
        """Set occupancy."""
        mfg_code = self._device.manufacturer_code
        await write_attributes_safe(
            self._cluster,
            {"set_occupancy": 0 if is_away else 1},
            manufacturer=mfg_code,
        )


@register_entity(ThermostatCluster.cluster_id)
class ZenWithinThermostat(Thermostat):
    """Zen Within Thermostat implementation."""

    _cluster_match = ClusterMatch(
        server_clusters=frozenset({ThermostatCluster.cluster_id}),
        optional_server_clusters=frozenset({FanCluster.cluster_id}),
        manufacturers=frozenset({"Zen Within", "LUX"}),
        feature_priority=(PlatformFeatureGroup.THERMOSTAT_FAN, 2),
    )


@register_entity(ThermostatCluster.cluster_id)
class ZehnderThermostat(Thermostat):
    """Zehnder thermostat to adapt AUTO mode behavior."""

    _cluster_match = ClusterMatch(
        server_clusters=frozenset({ThermostatCluster.cluster_id}),
        manufacturers=frozenset(
            {"ZEHNDER GROUP VAUX ANDIGNY      ", "ZEHNDER GROUP VAUX ANDIGNY"}
        ),
        feature_priority=(PlatformFeatureGroup.THERMOSTAT_FAN, 2),
    )

    ZEHNDER_HVAC_MODE_2_SYSTEM = {
        HVACMode.OFF: SystemMode.Off,
        HVACMode.HEAT: SystemMode.Auto,
    }

    ZEHNDER_SYSTEM_MODE_2_HVAC = {
        SystemMode.Off: HVACMode.OFF,
        SystemMode.Auto: HVACMode.HEAT,
    }

    hvac_modes = [HVACMode.OFF, HVACMode.HEAT]

    async def async_set_hvac_mode(self, hvac_mode: HVACMode) -> None:
        """Set new target operation mode."""
        if hvac_mode not in self.hvac_modes:
            self.warning(
                "can't set '%s' mode. Supported modes are: %s",
                hvac_mode,
                self.hvac_modes,
            )
            return

        await write_attributes_safe(
            self._cluster,
            {
                ThermostatCluster.AttributeDefs.system_mode.name: ZehnderThermostat.ZEHNDER_HVAC_MODE_2_SYSTEM[
                    hvac_mode
                ]
            },
        )
        self.maybe_emit_state_changed_event()

    @property
    def current_temperature(self):
        """Force no current temperature."""
        return None

    @property
    def system_mode_string(self) -> str | None:
        """Return a formatted system mode string."""
        if self.hvac_mode is None:
            return None
        system_mode = ZehnderThermostat.ZEHNDER_SYSTEM_MODE_2_HVAC.get(
            self._system_mode, "unknown"
        )
        return f"[{self._system_mode}]/{system_mode}"

    @property
    def hvac_mode(self) -> HVACMode | None:
        """Return HVAC operation mode."""
        return ZehnderThermostat.ZEHNDER_SYSTEM_MODE_2_HVAC.get(self._system_mode)


@register_entity(ThermostatCluster.cluster_id)
class CentralitePearl(Thermostat):
    """Centralite Pearl Thermostat implementation."""

    _cluster_match = ClusterMatch(
        server_clusters=frozenset({ThermostatCluster.cluster_id}),
        optional_server_clusters=frozenset({FanCluster.cluster_id}),
        manufacturers=frozenset({"Centralite"}),
        models=frozenset({"3157100", "3157100-E"}),
        feature_priority=(PlatformFeatureGroup.THERMOSTAT_FAN, 2),
    )


MOES_MANUFACTURERS = frozenset(
    {
        "_TZE200_ckud7u2l",
        "_TZE200_ywdxldoj",
        "_TZE200_cwnjrr72",
        "_TZE200_2atgpdho",
        "_TZE200_pvvbommb",
        "_TZE200_4eeyebrt",
        "_TZE200_cpmgn2cf",
        "_TZE200_9sfg7gm0",
        "_TZE200_8whxpsiw",
        "_TYST11_ckud7u2l",
        "_TYST11_ywdxldoj",
        "_TYST11_cwnjrr72",
        "_TYST11_2atgpdho",
    }
)


@register_entity(ThermostatCluster.cluster_id)
class MoesThermostat(Thermostat):
    """Moes Thermostat implementation."""

    _cluster_match = ClusterMatch(
        server_clusters=frozenset({ThermostatCluster.cluster_id}),
        manufacturers=MOES_MANUFACTURERS,
        feature_priority=(PlatformFeatureGroup.THERMOSTAT_FAN, 2),
    )

    def recompute_capabilities(self) -> None:
        """Recompute capabilities and feature flags."""
        super().recompute_capabilities()
        self._presets = [
            Preset.NONE,
            Preset.AWAY,
            Preset.SCHEDULE,
            Preset.COMFORT,
            Preset.ECO,
            Preset.BOOST,
            Preset.COMPLEX,
        ]
        self._supported_features |= ClimateEntityFeature.PRESET_MODE

    @functools.cached_property
    def hvac_modes(self) -> list[HVACMode]:
        """Return only the heat mode, because the device can't be turned off."""
        return [HVACMode.HEAT]

    def handle_attribute_updated(
        self,
        event: AttributeReadEvent
        | AttributeReportedEvent
        | AttributeUpdatedEvent
        | AttributeWrittenEvent,
    ) -> None:
        """Handle attribute update from device."""
        if event.attribute_name == "operation_preset":
            if event.value == 0:
                self._preset = Preset.AWAY
            if event.value == 1:
                self._preset = Preset.SCHEDULE
            if event.value == 2:
                self._preset = Preset.NONE
            if event.value == 3:
                self._preset = Preset.COMFORT
            if event.value == 4:
                self._preset = Preset.ECO
            if event.value == 5:
                self._preset = Preset.BOOST
            if event.value == 6:
                self._preset = Preset.COMPLEX
        super().handle_attribute_updated(event)

    async def async_preset_handler(self, preset: str, enable: bool = False) -> None:
        """Set the preset mode."""
        mfg_code = self._device.manufacturer_code
        if not enable:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 2}, manufacturer=mfg_code
            )
        if preset == Preset.AWAY:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 0}, manufacturer=mfg_code
            )
        if preset == Preset.SCHEDULE:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 1}, manufacturer=mfg_code
            )
        if preset == Preset.COMFORT:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 3}, manufacturer=mfg_code
            )
        if preset == Preset.ECO:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 4}, manufacturer=mfg_code
            )
        if preset == Preset.BOOST:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 5}, manufacturer=mfg_code
            )
        if preset == Preset.COMPLEX:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 6}, manufacturer=mfg_code
            )


@register_entity(ThermostatCluster.cluster_id)
class BecaThermostat(Thermostat):
    """Beca Thermostat implementation."""

    _cluster_match = ClusterMatch(
        server_clusters=frozenset({ThermostatCluster.cluster_id}),
        manufacturers=frozenset({"_TZE200_b6wax7g0"}),
        feature_priority=(PlatformFeatureGroup.THERMOSTAT_FAN, 2),
    )

    def recompute_capabilities(self) -> None:
        """Recompute capabilities and feature flags."""
        super().recompute_capabilities()
        self._presets = [
            Preset.NONE,
            Preset.AWAY,
            Preset.SCHEDULE,
            Preset.ECO,
            Preset.BOOST,
            Preset.TEMP_MANUAL,
        ]
        self._supported_features |= ClimateEntityFeature.PRESET_MODE

    @functools.cached_property
    def hvac_modes(self) -> list[HVACMode]:
        """Return only the heat mode, because the device can't be turned off."""
        return [HVACMode.HEAT]

    def handle_attribute_updated(
        self,
        event: AttributeReadEvent
        | AttributeReportedEvent
        | AttributeUpdatedEvent
        | AttributeWrittenEvent,
    ) -> None:
        """Handle attribute update from device."""
        if event.attribute_name == "operation_preset":
            if event.value == 0:
                self._preset = Preset.AWAY
            if event.value == 1:
                self._preset = Preset.SCHEDULE
            if event.value == 2:
                self._preset = Preset.NONE
            if event.value == 4:
                self._preset = Preset.ECO
            if event.value == 5:
                self._preset = Preset.BOOST
            if event.value == 7:
                self._preset = Preset.TEMP_MANUAL
        super().handle_attribute_updated(event)

    async def async_preset_handler(self, preset: str, enable: bool = False) -> None:
        """Set the preset mode."""
        mfg_code = self._device.manufacturer_code
        if not enable:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 2}, manufacturer=mfg_code
            )
        if preset == Preset.AWAY:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 0}, manufacturer=mfg_code
            )
        if preset == Preset.SCHEDULE:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 1}, manufacturer=mfg_code
            )
        if preset == Preset.ECO:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 4}, manufacturer=mfg_code
            )
        if preset == Preset.BOOST:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 5}, manufacturer=mfg_code
            )
        if preset == Preset.TEMP_MANUAL:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 7}, manufacturer=mfg_code
            )


@register_entity(ThermostatCluster.cluster_id)
class StelproFanHeater(Thermostat):
    """Stelpro Fan Heater implementation."""

    _cluster_match = ClusterMatch(
        server_clusters=frozenset({ThermostatCluster.cluster_id}),
        manufacturers=frozenset({"Stelpro"}),
        models=frozenset({"SORB"}),
        feature_priority=(PlatformFeatureGroup.THERMOSTAT_FAN, 2),
    )

    @functools.cached_property
    def hvac_modes(self) -> list[HVACMode]:
        """Return only the heat mode, because the device can't be turned off."""
        return [HVACMode.HEAT]


ZONNSMART_MANUFACTURERS = frozenset(
    {
        "_TZE200_7yoranx2",
        "_TZE200_e9ba97vf",  # TV01-ZG
        "_TZE200_hue3yfsn",  # TV02-ZG
        "_TZE200_husqqvux",  # TSL-TRV-TV01ZG
        "_TZE200_kds0pmmv",  # MOES TRV TV02
        "_TZE200_kly8gjlz",  # TV05-ZG
        "_TZE200_lnbfnyxd",
        "_TZE200_mudxchsu",
    }
)


@register_entity(ThermostatCluster.cluster_id)
class ZONNSMARTThermostat(Thermostat):
    """ZONNSMART Thermostat implementation.

    Notice that this device uses two holiday presets (2: HolidayMode,
    3: HolidayModeTemp), but only one of them can be set.
    """

    PRESET_HOLIDAY = "holiday"
    PRESET_FROST = "frost protect"

    _cluster_match = ClusterMatch(
        server_clusters=frozenset({ThermostatCluster.cluster_id}),
        manufacturers=ZONNSMART_MANUFACTURERS,
        feature_priority=(PlatformFeatureGroup.THERMOSTAT_FAN, 2),
    )

    def recompute_capabilities(self) -> None:
        """Recompute capabilities."""
        super().recompute_capabilities()
        self._presets = [
            Preset.NONE,
            self.PRESET_HOLIDAY,
            Preset.SCHEDULE,
            self.PRESET_FROST,
        ]
        self._supported_features |= ClimateEntityFeature.PRESET_MODE

    def handle_attribute_updated(
        self,
        event: AttributeReadEvent
        | AttributeReportedEvent
        | AttributeUpdatedEvent
        | AttributeWrittenEvent,
    ) -> None:
        """Handle attribute update from device."""
        if event.attribute_name == "operation_preset":
            if event.value == 0:
                self._preset = Preset.SCHEDULE
            if event.value == 1:
                self._preset = Preset.NONE
            if event.value in (2, 3):
                self._preset = self.PRESET_HOLIDAY
            if event.value == 4:
                self._preset = self.PRESET_FROST
        super().handle_attribute_updated(event)

    async def async_preset_handler(self, preset: str, enable: bool = False) -> None:
        """Set the preset mode."""
        mfg_code = self._device.manufacturer_code
        if not enable:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 1}, manufacturer=mfg_code
            )
        if preset == Preset.SCHEDULE:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 0}, manufacturer=mfg_code
            )
        if preset == self.PRESET_HOLIDAY:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 3}, manufacturer=mfg_code
            )
        if preset == self.PRESET_FROST:
            return await write_attributes_safe(
                self._cluster, {"operation_preset": 4}, manufacturer=mfg_code
            )
