"""Callback registry and API update orchestration for Device."""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING

from ..utils import current_datetime, is_awaitable

if TYPE_CHECKING:  # pragma: no cover
    from ._core import Device


class DeviceCallbacksMixin:
    """Mixin providing device callback registration and API update plumbing."""

    _callbacks: list[Callable]
    _internal_callbacks: list[Callable]

    def add_device_callback(self: Device, callback: Callable) -> None:  # type: ignore[misc]
        """Add a callback function to be called when device state changes.

        The callback will be invoked whenever the device data is updated.
        Callbacks can be either synchronous or asynchronous functions.

        Args:
            callback: A callable function. Can be sync or async.

        Raises:
            TypeError: If the provided object is not callable.
        """
        if not callable(callback):
            raise TypeError("Object must be callable.")
        if callback not in self._callbacks:
            self._callbacks.append(callback)

    def remove_device_callback(self: Device, callback: Callable) -> None:  # type: ignore[misc]
        """Remove a previously registered device callback.

        Args:
            callback: The callback function to remove.

        Raises:
            TypeError: If the provided object is not callable or not found.
        """
        if not callable(callback):
            raise TypeError("Object must be callable.")
        if callback in self._callbacks:
            self._callbacks.remove(callback)

    async def _execute_callbacks(self: Device) -> None:  # type: ignore[misc]
        """Execute all callbacks."""
        for cb in self._internal_callbacks:
            if is_awaitable(cb):
                await cb(device=self)
            else:
                cb(device=self)

        for cb in self._callbacks:
            if is_awaitable(cb):
                await cb()
            else:
                cb()

    async def _send_api_update(  # type: ignore[misc]
        self: Device,
        api_call: Callable,
        *args,
        **kwargs,
    ) -> None:
        """Sends an update to the API and refreshes local state."""
        now = kwargs.pop("now", current_datetime(self._api._tz))
        response = await api_call(*args, **kwargs)
        self._parse_parental_control_setting(response["json"], now)
        self._calculate_times(now)
        await self._execute_callbacks()
