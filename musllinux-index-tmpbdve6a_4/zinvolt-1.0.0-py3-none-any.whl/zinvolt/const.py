"""Constants for Zinvolt."""
