from enum import StrEnum

from pydantic import BaseModel, Field, NonNegativeInt


class StartScanData(BaseModel):
    new_installation: bool = Field(False, alias="newInstallation")
    no_addressing: bool = Field(False, alias="noAddressing")
    use_lines: list[NonNegativeInt] = Field([], alias="useLines")


class ScanLineState(StrEnum):
    IDLE = "idle"
    CANCELLED = "cancelled"
    SCANNING = "scanning"
    ADDRESSING = "addressing"
    DONE = "done"
    SKIPPED = "skipped"
    ERROR = "error"


class ScanLineData(BaseModel):
    line: int
    scan_state: ScanLineState = Field(ScanLineState.IDLE, alias="scanState")
    found: int = 0
    found_sensors: int = Field(0, alias="foundSensors")
    addressed: int = 0
    scanned: int = 0
    progress: float = 0.0

    @property
    def busy(self) -> bool:
        """Return if a scan on the line is in progress."""
        return self.scan_state in (ScanLineState.ADDRESSING, ScanLineState.SCANNING)


class ScanState(StrEnum):
    NOT_STARTED = "not started"
    CANCELLED = "cancelled"
    DONE = "done"
    ADDRESSING = "addressing"
    IN_PROGRESS = "in progress"
    BUS_ERROR = "bus error"


class ScanData(BaseModel):
    id: str = ""
    progress: float | None = None
    found: int | None = None
    found_sensors: int | None = Field(None, alias="foundSensors")
    status: ScanState = ScanState.NOT_STARTED
    lines: list[ScanLineData] = []

    @property
    def busy(self) -> bool:
        """Return if the scan is in progress."""
        return self.status in (ScanState.ADDRESSING, ScanState.IN_PROGRESS)
