import importlib
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    # This block is NEVER executed at runtime.
    from .auth import Auth
    from .dali import DALIBroadcast, DALIGroup, DALIScan
    from .devices import Device, Devices
    from .info import Info
    from .sensors import Sensor, Sensors
    from .zones import Zone, Zones

__all__ = [
    "Auth",
    "DALIBroadcast",
    "DALIGroup",
    "DALIScan",
    "Device",
    "Devices",
    "Info",
    "Sensor",
    "Sensors",
    "Zone",
    "Zones",
]

_MODULE_MAP = {
    "Auth": ".auth",
    "DALIBroadcast": ".dali",
    "DALIGroup": ".dali",
    "DALIScan": ".dali",
    "Device": ".devices",
    "Devices": ".devices",
    "Info": ".info",
    "Sensor": ".sensors",
    "Sensors": ".sensors",
    "Zone": ".zones",
    "Zones": ".zones",
}


def __getattr__(name: str) -> Any:
    """
    Dynamically imports the requested attribute only when accessed.
    This can make certain imports faster.
    """
    if name in _MODULE_MAP:
        # Import the module relative to this package (__name__)
        module_path = _MODULE_MAP[name]
        module = importlib.import_module(module_path, __package__)

        # Get the class/object from that module
        attr = getattr(module, name)

        globals()[name] = attr # Cache the module in the global namespace
        return attr

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
