from typing import ClassVar

from lunatone_rest_api_client import Auth
from lunatone_rest_api_client.models import InfoData


class Info:
    """Class that represents a info object in the API."""

    path: ClassVar[str] = "info"

    def __init__(self, auth: Auth) -> None:
        """Initialize an info object."""
        self.auth = auth
        self._data: InfoData | None = None

    @property
    def data(self) -> InfoData | None:
        """Return the raw info data."""
        return self._data

    async def async_update(self) -> None:
        """Update the info data."""
        response = await self.auth.get(self.path)
        self._data = InfoData.model_validate(await response.json())
