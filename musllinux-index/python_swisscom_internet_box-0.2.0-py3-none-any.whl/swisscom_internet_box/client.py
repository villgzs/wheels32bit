"""Authenticated client for the Swisscom Internet-Box web-services endpoint."""

from __future__ import annotations

import re
from typing import Any

import aiohttp

from .exceptions import SwisscomAuthError, SwisscomConnectionError, SwisscomError
from .models import AccessPoint, BoxInfo, Device, NMCInfo, WANStatus, WiFiStatus

CONTENT_TYPE = "application/x-sah-ws-4-call+json"
REQUEST_TIMEOUT = aiohttp.ClientTimeout(total=10)

# The box namespaces its cookies by a per-device id, e.g. ``d7b5333f/sessid=…``.
_SESSID_COOKIE_RE = re.compile(r"\s*([^=;/\s]+)/sessid=([^;]+)")


class SwisscomClient:
    """Authenticated client for the Internet-Box web-services endpoint."""

    def __init__(
        self,
        session: aiohttp.ClientSession,
        host: str,
        username: str,
        password: str,
    ) -> None:
        """Initialize the client."""
        self._session = session
        self._url = f"http://{host}/ws"
        self._username = username
        self._password = password
        self._context_id: str | None = None
        # Learned from the login Set-Cookie; needed for the anti-CSRF cookie
        # that the box requires on write (state-changing) requests.
        self._device_id: str | None = None
        self._sessid: str | None = None

    async def _post(
        self, payload: dict[str, Any], headers: dict[str, str]
    ) -> dict[str, Any]:
        """POST a request and return the parsed JSON body."""
        try:
            async with self._session.post(
                self._url,
                json=payload,
                headers={"Content-Type": CONTENT_TYPE, **headers},
                timeout=REQUEST_TIMEOUT,
            ) as response:
                if response.status == 401:
                    raise SwisscomAuthError("Unauthorized")
                response.raise_for_status()
                return await response.json(content_type=None)
        except (TimeoutError, aiohttp.ClientError) as err:
            raise SwisscomConnectionError(str(err)) from err

    def _auth_headers(self) -> dict[str, str]:
        """Headers for an authenticated request.

        Besides the context ID (sent as both ``Authorization`` and
        ``X-Context``), the box enforces a double-submit anti-CSRF check on
        write requests: the context ID must also be echoed back as a
        ``<deviceID>/context`` cookie. Read requests work without it, but it
        is harmless to always send, so we do.
        """
        assert self._context_id is not None
        headers = {
            "Authorization": f"X-Sah {self._context_id}",
            "X-Context": self._context_id,
            "X-Requested-With": "XMLHttpRequest",
        }
        if self._device_id:
            cookies = [
                f"{self._device_id}/context={self._context_id}",
                f"swc/deviceID={self._device_id}",
            ]
            if self._sessid:
                cookies.append(f"{self._device_id}/sessid={self._sessid}")
            headers["Cookie"] = "; ".join(cookies)
        return headers

    async def _post_authenticated(self, payload: dict[str, Any]) -> dict[str, Any]:
        """POST a request with the current context ID, re-authenticating once on expiry."""
        if self._context_id is None:
            await self.login()

        for attempt in range(2):
            try:
                return await self._post(payload, self._auth_headers())
            except SwisscomAuthError:
                if attempt == 0:
                    await self.login()
                    continue
                raise
        return {}

    @staticmethod
    def _check_response(data: dict[str, Any]) -> None:
        """Raise if a write request reported a request-level error.

        The ``/ws`` endpoint answers with HTTP 200 even when a command is
        rejected, surfacing the failure in an ``errors`` array instead.
        """
        errors = data.get("errors")
        if errors:
            raise SwisscomError(str(errors))

    async def login(self) -> None:
        """Authenticate and store the context ID and anti-CSRF cookie data."""
        payload = {
            "service": "sah.Device.Information",
            "method": "createContext",
            "parameters": {
                "applicationName": "webui",
                "username": self._username,
                "password": self._password,
            },
        }
        try:
            async with self._session.post(
                self._url,
                json=payload,
                headers={"Content-Type": CONTENT_TYPE, "Authorization": "X-Sah-Login"},
                timeout=REQUEST_TIMEOUT,
            ) as response:
                if response.status == 401:
                    raise SwisscomAuthError("Unauthorized")
                response.raise_for_status()
                data = await response.json(content_type=None)
                set_cookies = response.headers.getall("Set-Cookie", [])
        except (TimeoutError, aiohttp.ClientError) as err:
            raise SwisscomConnectionError(str(err)) from err

        try:
            self._context_id = data["data"]["contextID"]
        except (KeyError, TypeError) as err:
            raise SwisscomAuthError("Unexpected authentication response") from err

        # The box returns its per-device cookie prefix and session id via
        # Set-Cookie (e.g. ``d7b5333f/sessid=…``); both feed the CSRF cookie.
        self._device_id = None
        self._sessid = None
        for cookie in set_cookies:
            match = _SESSID_COOKIE_RE.match(cookie)
            if match:
                self._device_id, self._sessid = match.group(1), match.group(2)
                break

    async def get_box_info(self) -> BoxInfo:
        """Return static information about the Internet-Box (unauthenticated)."""
        data = await self._post(
            {"service": "DeviceInfo", "method": "get", "parameters": {}}, {}
        )
        return BoxInfo.from_dict(data.get("status", {}))

    async def get_wan_status(self) -> WANStatus:
        """Return current WAN connection state (unauthenticated)."""
        data = await self._post(
            {"service": "NMC", "method": "getWANStatus", "parameters": {}}, {}
        )
        return WANStatus.from_dict(data.get("data", {}))

    async def get_nmc_info(self) -> NMCInfo:
        """Return top-level NMC configuration (WAN mode, interface, provisioning)."""
        data = await self._post(
            {"service": "NMC", "method": "get", "parameters": {}}, {}
        )
        return NMCInfo.from_dict(data.get("status", {}))

    async def get_wifi_status(self) -> WiFiStatus:
        """Return WiFi radio status."""
        data = await self._post(
            {"service": "NMC.Wifi", "method": "get", "parameters": {}}, {}
        )
        return WiFiStatus.from_dict(data.get("data", {}))

    async def get_access_points(self) -> list[AccessPoint]:
        """Return all WiFi access points (VAPs), including the guest network.

        Use ``ap.is_guest`` to distinguish guest from regular APs.
        """
        data = await self._post_authenticated(
            {
                "service": "Devices",
                "method": "get",
                "parameters": {"expression": "lan and vap"},
            }
        )
        return [AccessPoint.from_dict(d) for d in data.get("status", [])]

    async def get_devices(self, expression: str = "lan and not self") -> list[Device]:
        """Return LAN devices matching the given expression.

        Common expressions:
          ``"lan and not self"``  – all LAN clients (default)
          ``"wifi"``              – wireless clients only
          ``"eth"``               – wired clients only
          ``"lan"``               – all LAN clients including the box itself
        """
        data = await self._post_authenticated(
            {
                "service": "Devices",
                "method": "get",
                "parameters": {"expression": expression},
            }
        )
        return [Device.from_dict(d) for d in data.get("status", [])]

    async def set_wifi(self, enabled: bool) -> None:
        """Enable or disable the WiFi radios (authenticated).

        Toggles the global WiFi switch, equivalent to the on/off control in
        the web UI. Disabling turns off every SSID, including the guest
        network.
        """
        data = await self._post_authenticated(
            {
                "service": "NMC.Wifi",
                "method": "set",
                "parameters": {"Enable": enabled, "Status": enabled},
            }
        )
        self._check_response(data)

    async def set_guest_wifi(self, enabled: bool) -> None:
        """Enable or disable the guest WiFi network (authenticated)."""
        data = await self._post_authenticated(
            {
                "service": "NMC.Guest",
                "method": "set",
                "parameters": {"Enable": enabled},
            }
        )
        self._check_response(data)

    async def reboot(self, reason: str = "GUI_Reboot") -> None:
        """Reboot the Internet-Box (authenticated)."""
        data = await self._post_authenticated(
            {
                "service": "NMC",
                "method": "reboot",
                "parameters": {"reason": reason},
            }
        )
        self._check_response(data)
