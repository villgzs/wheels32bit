"""Unofficial UniFi Protect Python API and Command Line Interface."""

from __future__ import annotations

from .api import ProtectApiClient, calculate_retry_delay, parse_retry_after
from .devices import DeviceChange, ProtectDeviceChange
from .events import (
    EventChange,
    EventIdentity,
    ProtectEvent,
    ProtectEventChannel,
    UlpUserIdentity,
    UnknownIdentity,
)
from .exceptions import (
    ArmedModeError,
    BadRequest,
    GlobalAlarmManagerError,
    Invalid,
    NotAuthorized,
    NvrError,
    PublicOnlyModeError,
)
from .utils import (
    get_nested_attr,
    get_nested_attr_as_bool,
    get_top_level_attr_as_bool,
    make_enabled_getter,
    make_required_getter,
    make_value_getter,
)

__all__ = [
    "ArmedModeError",
    "BadRequest",
    "DeviceChange",
    "EventChange",
    "EventIdentity",
    "GlobalAlarmManagerError",
    "Invalid",
    "NotAuthorized",
    "NvrError",
    "ProtectApiClient",
    "ProtectDeviceChange",
    "ProtectEvent",
    "ProtectEventChannel",
    "PublicOnlyModeError",
    "UlpUserIdentity",
    "UnknownIdentity",
    "calculate_retry_delay",
    "get_nested_attr",
    "get_nested_attr_as_bool",
    "get_top_level_attr_as_bool",
    "make_enabled_getter",
    "make_required_getter",
    "make_value_getter",
    "parse_retry_after",
]
