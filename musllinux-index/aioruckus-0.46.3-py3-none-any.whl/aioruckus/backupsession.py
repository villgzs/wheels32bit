"""Ruckus AbcSession which connects to Ruckus Unleashed or ZoneDirector backups"""
from __future__ import annotations
import configparser
import io
import struct
import tarfile

from collections.abc import Mapping
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from os import SEEK_CUR
from typing import Any, TYPE_CHECKING, override

from .abcsession import AbcSession, ConfigItem

if TYPE_CHECKING:
    from .ruckusbackupapi import RuckusBackupApi


class BackupSession(AbcSession):
    """Connect to Ruckus Unleashed or ZoneDirector Backup"""

    def __init__(
        self,
        backup_path: str
    ) -> None:
        super().__init__()
        self.backup_file = __open_backup(backup_path)
        self.backup_tarfile = tarfile.open(fileobj=self.backup_file)
        self.backup_filenames = self.backup_tarfile.getnames()

    def __enter__(self) -> BackupSession:
        return self

    def __exit__(self, *exc: Any) -> None:
        if self.backup_tarfile:
            self.backup_tarfile.close()
        if self.backup_file:
            self.backup_file.close()

    
    @property
    @override
    def api(self) -> RuckusBackupApi:
        """Return a RuckusBackupApi instance."""
        if self._api is None:
            # pylint: disable=import-outside-toplevel
            from .ruckusbackupapi import RuckusBackupApi
            self._api = RuckusBackupApi(self)
        return self._api

    @override
    async def get_conf_str(self, item: ConfigItem, timeout: int | None = None) -> str:
        xml = self.__get_backup_file(f"etc/airespider/{item.value}.xml")
        return "<ajax-response><response>" + xml + "</response></ajax-response>"

    def get_metadata(self) -> Mapping[str, str]:
        """Return the backup metadata"""
        xml = "[metadata]\n" + self.__get_backup_file("metadata")
        config = configparser.ConfigParser()
        config.read_string(xml)
        return config["metadata"]

    def __get_backup_file(self, member: str) -> str:
        """Extract a file from the backup and return its contents"""
        if member in self.backup_filenames:
            extracted_file = self.backup_tarfile.extractfile(member)
            if extracted_file is not None:
                return extracted_file.read().decode("utf-8")
        # raise KeyError for consistency with AjaxSession behaviour
        raise KeyError(f"Member '{member}' not found in backup archive.")

def __open_backup(backup_path: str) -> io.BytesIO:
    """Return the decrypted backup bytes"""
    with open(backup_path, "rb") as backup_file:
        magic = backup_file.read(4)
        if magic == b'RKSF':
            return __open_commscope_backup(backup_file)
        else:
            backup_file.seek(0)
            return __open_tac_backup(backup_file)

def __open_tac_backup(backup_file: io.BufferedReader) -> io.BytesIO:
    """Return the decrypted TAC backup file"""
    (xor_int, xor_flip) = struct.unpack('QQ', b')\x1aB\x05\xbd,\xd6\xf25\xad\xb8\xe0?T\xc58')
    struct_int8 = struct.Struct('Q')
    output_file = io.BytesIO()
    previous_input_int = 0
    input_data = backup_file.read()
    for input_int in struct.unpack_from(str(len(input_data) // 8) + 'Q', input_data):
        output_bytes = struct_int8.pack(previous_input_int ^ xor_int ^ input_int)
        xor_int ^= xor_flip
        previous_input_int = input_int
        output_file.write(output_bytes)
    output_file.seek(0)
    return output_file

def __open_commscope_backup(backup_file: io.BufferedReader) -> io.BytesIO:
    """Return the decrypted CommScope Content Manager backup file"""
    backup_file.seek(4, SEEK_CUR)
    encrypted_key = backup_file.read(__get_block_length(backup_file))
    key = __decrypt_key(encrypted_key)

    __skip_block(backup_file)  # digest
    __skip_block(backup_file)  # signature

    decrypted_length = __get_block_length(backup_file)
    encrypted_bytes = backup_file.read()
    cipher = Cipher(algorithms.AES(key), modes.ECB())
    decryptor = cipher.decryptor()
    decrypted_bytes = decryptor.update(encrypted_bytes) + decryptor.finalize()

    output_file = io.BytesIO()
    output_file.write(decrypted_bytes[:decrypted_length])
    output_file.seek(0)
    return output_file

def __skip_block(backup_file: io.BufferedReader) -> None:
    backup_file.seek(1, SEEK_CUR)
    block_length = int.from_bytes(backup_file.read(4), byteorder='big', signed=False)
    backup_file.seek(block_length, SEEK_CUR)

def __get_block_length(backup_file: io.BufferedReader) -> int:
    backup_file.seek(1, SEEK_CUR)
    return int.from_bytes(backup_file.read(4), byteorder='big', signed=False)

def __decrypt_key(cipher_bytes: bytes) -> bytes:
    padded_key = pow(int.from_bytes(cipher_bytes, 'big'), 65537, 23559046888044776627569879690471525499427612616504460325607886880157810091042540109382540840072568820382270758180649018860535002041926018790203547085546162549326945200443019963900872654422143820799219291504478283808912964667353808795633808052022964371726410677357834881346022671448243831605466569511830964339444687659616502868745663064525218488470606514409811838671765944249166136071060850237167429125523755638111097424494275181385870987411479009552515816450089719197508371290305110717762578033949377936003949760003095430389967102852124783026450284389704957901428442687247403657819155956894836033683283023293306459081).to_bytes(256, 'big')
    return padded_key[padded_key.index(b'\x00', 2) + 1:]
