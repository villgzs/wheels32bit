import asyncio
from dataclasses import dataclass

import aiohttp

from weheat import DeviceState
from weheat.configuration import Configuration
from weheat.api_client import ApiClient
from weheat.api.heat_pump_api import HeatPumpApi


class HeatPumpDiscovery:
    @dataclass
    class HeatPumpInfo:
        uuid: str
        device_name: str
        model: str
        sn : str
        has_dhw: bool = False
        has_ch_boiler: bool = False

    @staticmethod
    async def async_discover_active(api_url: str, access_token: str, client_session:aiohttp.ClientSession|None = None) -> list[HeatPumpInfo]:
        discovered_pumps = []

        config = Configuration(host=api_url, access_token=access_token, client_session=client_session)

        async with ApiClient(configuration=config) as client:

            response = await  HeatPumpApi(client).api_v1_heat_pumps_get_with_http_info(1, 1000, state=DeviceState.NUMBER_3)

            if response.status_code == 200:
                for pump in response.data.data:
                    # Model of the heat pump
                    # - BlackBirdP80: BlackBird P80 heat pump (0)
                    # - BlackBirdP60: BlackBird P60 heat pump (1)
                    # - SparrowP60Brown: Sparrow P60 heat pump, colour brown (default) (2)
                    # - SparrowP60Green: Sparrow P60 heat pump, colour green (3)
                    # - SparrowP60Grey: Sparrow P60 heat pump, colour grey (4)
                    # - FlintP40: Flint P40 heat pump (5)
                    model_string = "Blackbird P80 heat pump"
                    if pump.model == 1:
                        model_string = "Blackbird P60 heat pump"
                    elif 2 <= pump.model <= 4:
                        model_string = "Sparrow P60 heat pump"
                    elif pump.model == 5:
                        model_string = "Flint P40 heat pump"

                    dhw = pump.dhw_type is not None and pump.dhw_type == 1
                    ch_boiler = pump.boiler_type is not None and pump.boiler_type > 1

                    discovered_pumps.append(
                        HeatPumpDiscovery.HeatPumpInfo(
                            uuid=pump.id,
                            device_name=pump.name,
                            model=model_string,
                            sn=pump.serial_number,
                            has_dhw=dhw,
                            has_ch_boiler=ch_boiler,
                        )
                    )
        return discovered_pumps