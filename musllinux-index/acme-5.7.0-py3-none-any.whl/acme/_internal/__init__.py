"""acme's internal implementation"""
