"""Async client for Helty Flow VMC units."""

from __future__ import annotations

import asyncio
import logging

from .const import (
    CMD_LED_OFF,
    CMD_LED_ON,
    CMD_NAME,
    CMD_RESET_FILTER,
    CMD_SENSORS,
    CMD_STATUS,
    DEFAULT_PORT,
    DEFAULT_RETRIES,
    DEFAULT_RETRY_DELAY,
    DEFAULT_TIMEOUT,
    LED_ON_VALUE,
    LIGHT_CMD_TEMPLATE,
    LIGHT_LEVEL_SCALE,
    LIGHT_MAX_LEVEL,
    PREFIX_NAME,
    PREFIX_SENSORS,
    PREFIX_STATUS,
    RESPONSE_OK,
    SENSOR_INDEX_CO2,
    SENSOR_SCALE,
    SIGNED_16_MODULUS,
    SIGNED_16_THRESHOLD,
    STATUS_INDEX_FILTER_HOURS,
    STATUS_INDEX_LIGHT,
    FanMode,
)
from .exceptions import (
    HeltyCommandError,
    HeltyConnectionError,
    HeltyResponseError,
)
from .models import HeltyData

_LOGGER = logging.getLogger(__name__)

_READ_LIMIT = 4096


class HeltyClient:
    """Talks to a single Helty Flow unit over its TCP interface.

    The unit serves one command per TCP connection and then closes it, so each
    call opens a fresh connection. An internal lock serialises commands because
    the unit does not reliably handle concurrent connections.
    """

    def __init__(
        self,
        host: str,
        port: int = DEFAULT_PORT,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        retries: int = DEFAULT_RETRIES,
        retry_delay: float = DEFAULT_RETRY_DELAY,
    ) -> None:
        self._host = host
        self._port = port
        self._timeout = timeout
        self._retries = retries
        self._retry_delay = retry_delay
        self._lock = asyncio.Lock()

    @property
    def host(self) -> str:
        return self._host

    @property
    def port(self) -> int:
        return self._port

    async def _execute_once(self, command: bytes) -> str:
        """Open a connection, send one command and return the stripped reply."""
        async with asyncio.timeout(self._timeout):
            reader, writer = await asyncio.open_connection(self._host, self._port)
            try:
                writer.write(command)
                await writer.drain()
                payload = await reader.read(_READ_LIMIT)
            finally:
                writer.close()
                await writer.wait_closed()
        return payload.decode("ascii", errors="replace").strip()

    async def _execute(self, command: bytes) -> str:
        """Send one command, retrying transient failures and empty replies.

        The unit serves a single command per connection and intermittently
        accepts a connection but returns an empty payload (especially right
        after an idle period or on rapid reconnection), so an empty reply is
        treated as a retryable, transient condition.
        """
        last_error: Exception | None = None
        async with self._lock:
            for attempt in range(self._retries + 1):
                if attempt:
                    await asyncio.sleep(self._retry_delay)
                try:
                    reply = await self._execute_once(command)
                except (TimeoutError, OSError) as err:
                    last_error = err
                    _LOGGER.debug(
                        "Helty %s:%s command %r failed (attempt %d/%d): %s",
                        self._host, self._port, command, attempt + 1, self._retries + 1, err,
                    )
                    continue
                if reply:
                    return reply
                last_error = HeltyConnectionError("empty reply")
                _LOGGER.debug(
                    "Helty %s:%s returned empty reply to %r (attempt %d/%d)",
                    self._host, self._port, command, attempt + 1, self._retries + 1,
                )
        raise HeltyConnectionError(
            f"Failed to communicate with Helty at {self._host}:{self._port}: {last_error}"
        )

    @staticmethod
    def _parse_fields(reply: str, prefix: str) -> tuple[int, ...]:
        """Validate the reply prefix and parse the trailing CSV integer fields."""
        parts = reply.split(",")
        if not parts or parts[0] != prefix:
            raise HeltyResponseError(f"Expected {prefix!r} reply, got {reply!r}")
        try:
            return tuple(int(value) for value in parts[1:])
        except ValueError as err:
            raise HeltyResponseError(f"Non-integer field in {reply!r}") from err

    @staticmethod
    def _to_temperature(raw: int) -> float:
        """Scale a raw tenths-of-degree value, treating it as signed 16-bit."""
        if raw >= SIGNED_16_THRESHOLD:
            raw -= SIGNED_16_MODULUS
        return raw / SENSOR_SCALE

    async def async_get_name(self) -> str:
        """Return the user-assigned device name (also used as a stable id)."""
        reply = await self._execute(CMD_NAME)
        if not reply.startswith(PREFIX_NAME):
            raise HeltyResponseError(f"Expected {PREFIX_NAME!r} reply, got {reply!r}")
        return reply[len(PREFIX_NAME) :].strip()

    async def async_get_data(self) -> HeltyData:
        """Fetch name, sensors and status in a single coordinated read."""
        name = await self.async_get_name()
        sensors = self._parse_fields(await self._execute(CMD_SENSORS), PREFIX_SENSORS)
        status = self._parse_fields(await self._execute(CMD_STATUS), PREFIX_STATUS)

        if len(sensors) < 3:
            raise HeltyResponseError(f"Too few sensor fields: {sensors!r}")
        if len(status) < 2:
            raise HeltyResponseError(f"Too few status fields: {status!r}")

        try:
            fan_mode = FanMode(status[0])
        except ValueError as err:
            raise HeltyResponseError(f"Unknown fan mode {status[0]}") from err

        co2 = sensors[SENSOR_INDEX_CO2] if len(sensors) > SENSOR_INDEX_CO2 else None
        filter_hours = (
            status[STATUS_INDEX_FILTER_HOURS]
            if len(status) > STATUS_INDEX_FILTER_HOURS
            else None
        )
        light_level = (
            status[STATUS_INDEX_LIGHT] // LIGHT_LEVEL_SCALE
            if len(status) > STATUS_INDEX_LIGHT
            else None
        )

        return HeltyData(
            name=name,
            fan_mode=fan_mode,
            leds_on=status[1] == LED_ON_VALUE,
            indoor_temperature=self._to_temperature(sensors[0]),
            outdoor_temperature=self._to_temperature(sensors[1]),
            indoor_humidity=sensors[2] / SENSOR_SCALE,
            co2=co2,
            filter_hours=filter_hours,
            light_level=light_level,
            raw_sensors=sensors,
            raw_status=status,
        )

    async def _write(self, command: bytes) -> None:
        reply = await self._execute(command)
        if reply != RESPONSE_OK:
            raise HeltyCommandError(f"Command {command!r} not acknowledged, got {reply!r}")

    async def async_set_fan_mode(self, mode: FanMode) -> None:
        """Select a fan speed or preset program."""
        await self._write(mode.command)

    async def async_set_led(self, on: bool) -> None:
        """Turn the front LED panel on or off."""
        await self._write(CMD_LED_ON if on else CMD_LED_OFF)

    async def async_reset_filter(self) -> None:
        """Reset the filter-life counter."""
        await self._write(CMD_RESET_FILTER)

    async def async_set_light(self, level: int) -> None:
        """Set the front-light brightness level (0-100); 0 turns it off."""
        level = max(0, min(LIGHT_MAX_LEVEL, level))
        await self._write(LIGHT_CMD_TEMPLATE.format(level=level).encode("ascii"))
