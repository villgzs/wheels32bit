"""Protocol constants for the Helty Flow VMC TCP interface.

The protocol is reverse-engineered (no official specification). Commands are
plain ASCII byte strings sent over a TCP socket; the unit replies with an ASCII
payload and then closes the connection. One command is served per connection.
"""

from __future__ import annotations

from enum import IntEnum

#: Default TCP port exposed by the Helty smart Wi-Fi interface.
DEFAULT_PORT = 5001

#: Default per-command timeout, in seconds.
DEFAULT_TIMEOUT = 10.0

#: Default number of retries on a transient failure or empty reply.
DEFAULT_RETRIES = 3

#: Default delay between retries, in seconds.
DEFAULT_RETRY_DELAY = 0.5

# --- Read commands ---------------------------------------------------------
#: Query the device name. Reply: ``VMNM <name>``.
CMD_NAME = b"VMNM?"
#: Query live sensor values. Reply: ``VMGI,<f1>,<f2>,...`` (15 fields).
CMD_SENSORS = b"VMGI?"
#: Query operating status/config. Reply: ``VMGO,<f1>,<f2>,...`` (15 fields).
CMD_STATUS = b"VMGH?"

# --- Reply prefixes --------------------------------------------------------
PREFIX_NAME = "VMNM"
PREFIX_SENSORS = "VMGI"
PREFIX_STATUS = "VMGO"

# --- Write commands --------------------------------------------------------
#: Turn the front LED panel on / off.
CMD_LED_ON = b"VMWH0100010"
CMD_LED_OFF = b"VMWH0100000"
#: Reset the filter-life counter.
CMD_RESET_FILTER = b"VMWH0417744"

#: Front-light level write command template: ``VMWH06<lll>000`` where ``<lll>``
#: is the level 0-100. Level 0 turns the light off.
LIGHT_CMD_TEMPLATE = "VMWH06{level:03d}000"
#: Maximum light level.
LIGHT_MAX_LEVEL = 100

#: Reply returned by the unit on a successful write command.
RESPONSE_OK = "OK"

#: Sensor scaling: raw integers are tenths of a unit (e.g. ``281`` -> ``28.1``).
SENSOR_SCALE = 10

# Field positions within the parsed (prefix-stripped) reply tuples. The tuples
# drop the leading ``VMGI``/``VMGO`` token, so index 0 is field 1 of the reply.
#: CO2 (ppm) in the VMGI reply. Verified on a FlowPlus (reads 0 without a sensor).
SENSOR_INDEX_CO2 = 3
#: Remaining filter hours in the VMGO reply.
STATUS_INDEX_FILTER_HOURS = 4
#: Front-light level in the VMGO reply, stored as level * 100. Verified on a FlowPlus.
STATUS_INDEX_LIGHT = 6
#: Divisor to turn the raw light field into a 0-100 level.
LIGHT_LEVEL_SCALE = 100

#: Raw values at or above this are interpreted as signed 16-bit (negative temps).
SIGNED_16_THRESHOLD = 32768
SIGNED_16_MODULUS = 65536


class FanMode(IntEnum):
    """Operating mode reported by status field 1 and set via ``VMWH000000<n>``."""

    OFF = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    MAX = 4
    BOOST = 5  # AirGuard "HyperVentilation"
    NIGHT = 6
    FREE_COOLING = 7

    @property
    def command(self) -> bytes:
        """The ``VMWH`` write command that selects this mode."""
        return f"VMWH000000{self.value}".encode("ascii")


#: Modes that represent a discrete fan speed (as opposed to a preset program).
SPEED_MODES: tuple[FanMode, ...] = (
    FanMode.OFF,
    FanMode.LOW,
    FanMode.MEDIUM,
    FanMode.HIGH,
    FanMode.MAX,
)

#: Modes that represent a preset program.
PRESET_MODES: tuple[FanMode, ...] = (
    FanMode.BOOST,
    FanMode.NIGHT,
    FanMode.FREE_COOLING,
)

#: Raw value of status field 2 (LED) meaning "on".
LED_ON_VALUE = 10
