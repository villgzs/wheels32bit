"""Exceptions raised by :mod:`pyhelty`."""

from __future__ import annotations


class HeltyError(Exception):
    """Base class for all pyhelty errors."""


class HeltyConnectionError(HeltyError):
    """Raised when the unit cannot be reached or times out."""


class HeltyResponseError(HeltyError):
    """Raised when the unit returns a malformed or unexpected response."""


class HeltyCommandError(HeltyError):
    """Raised when a write command is not acknowledged with ``OK``."""
