"""Data models for :mod:`pyhelty`."""

from __future__ import annotations

from dataclasses import dataclass

from .const import FanMode


@dataclass(frozen=True, slots=True)
class HeltyData:
    """A snapshot of the unit's sensors and operating status.

    ``raw_sensors`` and ``raw_status`` hold the full integer field lists from
    the ``VMGI``/``VMGO`` replies so that callers can decode additional,
    not-yet-identified fields without a library change.
    """

    name: str
    fan_mode: FanMode
    leds_on: bool
    indoor_temperature: float | None
    outdoor_temperature: float | None
    indoor_humidity: float | None
    raw_sensors: tuple[int, ...]
    raw_status: tuple[int, ...]
    #: CO2 in ppm. ``0`` (or ``None``) on models without a CO2 sensor.
    co2: int | None = None
    #: Remaining filter life in hours, if the model reports it.
    filter_hours: int | None = None
    #: Front-light brightness level, 0-100, if the model has a dimmable light.
    light_level: int | None = None

    @property
    def is_preset(self) -> bool:
        """True when the current mode is a preset program rather than a speed."""
        from .const import PRESET_MODES

        return self.fan_mode in PRESET_MODES
