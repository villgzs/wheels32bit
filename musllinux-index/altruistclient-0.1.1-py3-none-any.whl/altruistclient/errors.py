class AltruistError(Exception):
    pass