"""ModbusLink Asynchronous Client Implementation.

Provides user-friendly asynchronous Modbus client API.
"""

import logging
from types import TracebackType
from typing import Literal, Self, TypeVar

from tmodbus.pdu import (
    BaseClientPDU,
    FileRecord,
    FileRecordRequest,
    MaskWriteRegisterPDU,
    ReadCoilsPDU,
    ReadDeviceIdentificationPDU,
    ReadDiscreteInputsPDU,
    ReadExceptionStatusPDU,
    ReadFileRecordPDU,
    ReadHoldingRegistersPDU,
    ReadInputRegistersPDU,
    ReadWriteMultipleRegistersPDU,
    WriteFileRecordPDU,
    WriteMultipleCoilsPDU,
    WriteMultipleRegistersPDU,
    WriteSingleCoilPDU,
    WriteSingleRegisterPDU,
)
from tmodbus.pdu.fifo import ReadFifoQueuePDU
from tmodbus.pdu.holding_registers_struct import HoldingRegisterReadMixin, HoldingRegisterWriteMixin
from tmodbus.pdu.serial_line import (
    CommEventCounterResponse,
    CommEventLogResponse,
    DiagnosticsBusCharacterOverrunCountPDU,
    DiagnosticsBusCommunicationErrorCountPDU,
    DiagnosticsBusExceptionErrorCountPDU,
    DiagnosticsBusMessageCountPDU,
    DiagnosticsChangeAsciiInputDelimiterPDU,
    DiagnosticsClearCountersAndRegisterPDU,
    DiagnosticsClearOverrunCounterAndFlagPDU,
    DiagnosticsDiagnosticRegisterPDU,
    DiagnosticsForceListenOnlyModePDU,
    DiagnosticsQueryDataPDU,
    DiagnosticsRestartCommunicationsOptionPDU,
    DiagnosticsServerBusyCountPDU,
    DiagnosticsServerMessageCountPDU,
    DiagnosticsServerNakCountPDU,
    DiagnosticsServerNoResponseCountPDU,
    GetCommEventCounterPDU,
    GetCommEventLogPDU,
    ReportServerIdPDU,
    ServerIdResponse,
)
from tmodbus.transport.async_base import AsyncBaseTransport

logger = logging.getLogger(__name__)

RT = TypeVar("RT")


class AsyncModbusClient(HoldingRegisterReadMixin, HoldingRegisterWriteMixin):
    """Asynchronous Modbus Client.

    Provides an user-friendly asynchronous Modbus interface to a single Modbus device.
    All methods use Python native data types (int, float, str, list, etc.),

    If you want to query another device on the same connection, use the `for_unit_id` method.

    This class is agnostic to the transport layer: just pass the desired transport instance.

    Example:
        .. code-block:: python

            import asyncio
            from tmodbus import AsyncModbusClient, AsyncTcpTransport

            async def main():
                transport = AsyncTcpTransport('localhost', 502)
                client = AsyncModbusClient(transport, unit_id=1)
                async with client:
                    print("Contents of register 0:", await client.read_holding_registers(0, 1))

            asyncio.run(main())


    """

    def __init__(
        self,
        transport: AsyncBaseTransport,
        *,
        unit_id: int,
        word_order: Literal["big", "little"] = "big",
        byte_order: Literal["big", "little"] = "big",
    ) -> None:
        """Initialize Async Modbus Client.

        The combination of word_order and byte_order determines the final byte ordering:

        Byte Order Combinations (for a 32-bit value 0x0A0B0C0D):
            - word_order="big",   byte_order="big":    ABCD → 0x0A 0x0B 0x0C 0x0D (standard Modbus)
            - word_order="big",   byte_order="little": BADC → 0x0B 0x0A 0x0D 0x0C (byte-swapped)
            - word_order="little", byte_order="big":   CDAB → 0x0C 0x0D 0x0A 0x0B (word-swapped)
            - word_order="little", byte_order="little": DCBA → 0x0D 0x0C 0x0B 0x0A (full little-endian)

        Args:
            transport: Async transport layer instance (AsyncTcpTransport, etc.)
            unit_id: Unit ID of the Modbus device
            word_order: Word order for multi-register values ('big' or 'little').
                - 'big': Most significant register first (standard Modbus)
                - 'little': Least significant register first
            byte_order: Byte order within each register ('big' or 'little').
                - 'big': Most significant byte first within each register (standard Modbus)
                - 'little': Least significant byte first within each register

        """
        HoldingRegisterReadMixin.__init__(self, word_order=word_order, byte_order=byte_order)
        HoldingRegisterWriteMixin.__init__(self, word_order=word_order, byte_order=byte_order)
        self.transport = transport

        if not (0 <= unit_id <= 255):
            msg = "Unit ID must be in range 0-255"
            raise ValueError(msg)

        self.unit_id = unit_id

    async def connect(self) -> None:
        """Connect to the server."""
        await self.transport.open()

    @property
    def connected(self) -> bool:
        """Report if the client is connected to the server."""
        return self.transport.is_open()

    async def disconnect(self) -> None:
        """Close the server connection."""
        await self.transport.close()

    async def execute(self, pdu: BaseClientPDU[RT]) -> RT:
        """Execute PDU Request.

        Args:
            pdu: Modbus PDU instance
        Returns:
            Response PDU bytes

        Raises:
            InvalidResponseError: If response is invalid or does not match request

        """
        return await self.transport.send_and_receive(self.unit_id, pdu)

    async def read_coils(
        self,
        start_address: int,
        quantity: int,
    ) -> list[bool]:
        """Read Coil Status (Function Code 0x01).

        Args:
            start_address:  Starting address
            quantity:  Quantity to read (1-2000)

        Returns:
            List of coil status, True for ON, False for OFF

        Raises:
            InvalidResponseError: If response is invalid or does not match request

        Example:
            .. code-block:: python

                coils = await client.read_coils(0, 8)
                # Returns [True, False, True, False, False, False, True, False]

        """
        return await self.execute(ReadCoilsPDU(start_address, quantity))

    async def read_discrete_inputs(
        self,
        start_address: int,
        quantity: int,
    ) -> list[bool]:
        """Read Discrete Inputs (Function Code 0x02).

        Args:
            start_address:  Starting address
            quantity:  Quantity to read (1-2000)

        Returns:
            List of coil status, True for ON, False for OFF

        Example:
            .. code-block:: python

                inputs = await client.read_discrete_inputs(0, 8)
                # Returns [True, False, True, False, False, False, True, False]

        """
        return await self.execute(ReadDiscreteInputsPDU(start_address, quantity))

    async def read_holding_registers(
        self,
        start_address: int,
        quantity: int,
    ) -> list[int]:
        """Read Holding Registers (Function Code 0x03).

        Args:
            start_address: Starting address
            quantity: Quantity to read (1-125)


        Returns:
            List of register values, each value is a 16-bit unsigned integer (0-65535)

        Example:
            .. code-block:: python

                registers = await client.read_holding_registers(0, 4)  # Read holding registers 0, 1, 2, 3
                # Returns [1234, 5678, 9012, 3456]

        """
        return await self.execute(ReadHoldingRegistersPDU(start_address, quantity))

    async def read_input_registers(
        self,
        start_address: int,
        quantity: int,
    ) -> list[int]:
        """Read Input Registers (Function Code 0x04).

        Args:
            start_address: Starting address
            quantity: Quantity to read (1-125)


        Returns:
            List of register values, each value is a 16-bit unsigned integer (0-65535)

        Example:
            .. code-block:: python

                registers = await client.read_input_registers(0, 4) # Read input registers 0, 1, 2, 3
                # Returns [1234, 5678, 9012, 3456]

        """
        return await self.execute(ReadInputRegistersPDU(start_address, quantity))

    async def write_single_coil(
        self,
        address: int,
        value: bool,  # noqa: FBT001
    ) -> bool:
        """Write Single Coil (Function Code 0x05).

        Args:
            address: Coil address
            value: Coil value (True for ON, False for OFF)


        Returns:
            The coil state echoed by the device (True for ON, False for OFF)

        Example:
            .. code-block:: python

                await client.write_single_coil(0, True)  # Write ON to coil 0

        """
        return await self.execute(WriteSingleCoilPDU(address, value))

    async def write_single_register(
        self,
        address: int,
        value: int,
    ) -> int:
        """Write Single Register (Function Code 0x06).

        Args:
            address: Register address
            value: Register value (0-65535)

        Returns:
            the value that was written

        Example:
            .. code-block:: python

                await client.write_single_register(0, 1234)  # Write 1234 to register 0

        """
        return await self.execute(WriteSingleRegisterPDU(address, value))

    async def read_exception_status(self) -> int:
        """Read Exception Status (Function Code 0x07).

        Returns:
            The exception status as an integer (0-255).

        Example:
            .. code-block:: python

                status = await client.read_exception_status()
                print("Exception Status:", status)

        """
        return await self.execute(ReadExceptionStatusPDU())

    async def write_multiple_coils(
        self,
        start_address: int,
        values: list[bool],
    ) -> int:
        """Write Multiple Coils (Function Code 0x0F).

        Args:
            start_address: Starting address
            values: List of coil values, True for ON, False for OFF


        Returns:
            The number of coils that have been written to.

        Example:
            .. code-block:: python

                await client.write_multiple_coils(0, [True, False, True, False])

        """
        return await self.execute(WriteMultipleCoilsPDU(start_address, values))

    async def write_multiple_registers(
        self,
        start_address: int,
        values: list[int],
    ) -> int:
        """Write Multiple Registers (Function Code 0x10).

        Args:
            start_address: Starting address
            values: List of register values, each value 0-65535


        Returns:
            The number of registers that have been written to.

        Example:
            .. code-block:: python

                await client.write_multiple_registers(0, [1234, 5678, 9012])

        """
        return await self.execute(WriteMultipleRegistersPDU(start_address, values))

    async def read_server_id(self) -> "ServerIdResponse":
        """Read Server ID (Function Code 0x11).

        Returns:
            An instance of ServerIdResponse containing the server ID and run indicator status.

        Example:
            .. code-block:: python

                response = await client.read_server_id()
                print("Server ID:", response.server_id)
                print("Run Indicator Status:", response.run_indicator_status)

        """
        return await self.execute(ReportServerIdPDU())

    async def diag_read_query_data(self, data: bytes = b"\x00\x00") -> bytes:
        """Diagnostics sub-function 0x0000: Return Query Data.

        Args:
            data: Data bytes to loop back (must be an even number of bytes).

        Returns:
            The looped back data bytes.

        """
        return await self.execute(DiagnosticsQueryDataPDU(data=data))

    async def diag_restart_communications_option(
        self,
        clear_event_log: bool = False,  # noqa: FBT001, FBT002
    ) -> bool:
        """Diagnostics sub-function 0x0001: Restart Communications Option.

        Args:
            clear_event_log: Whether to clear the communications event log.

        Returns:
            Boolean status indicating if event log was cleared.

        """
        return await self.execute(DiagnosticsRestartCommunicationsOptionPDU(clear_event_log=clear_event_log))

    async def diag_read_diagnostic_register(self) -> int:
        """Diagnostics sub-function 0x0002: Return Diagnostic Register.

        Returns:
            16-bit diagnostic register value.

        """
        return await self.execute(DiagnosticsDiagnosticRegisterPDU())

    async def diag_change_ascii_input_delimiter(self, delimiter: int = 0x0A) -> int:
        """Diagnostics sub-function 0x0003: Change ASCII Input Delimiter.

        Args:
            delimiter: ASCII delimiter character code (0-255).

        Returns:
            The delimiter character code.

        """
        return await self.execute(DiagnosticsChangeAsciiInputDelimiterPDU(delimiter=delimiter))

    async def diag_force_listen_only_mode(self) -> None:
        """Diagnostics sub-function 0x0004: Force Listen Only Mode."""
        return await self.execute(DiagnosticsForceListenOnlyModePDU())

    async def diag_clear_counters_and_register(self) -> None:
        """Diagnostics sub-function 0x000A: Clear Counters and Diagnostic Register."""
        return await self.execute(DiagnosticsClearCountersAndRegisterPDU())

    async def diag_read_bus_message_count(self) -> int:
        """Diagnostics sub-function 0x000B: Return Bus Message Count.

        Returns:
            Total message count.

        """
        return await self.execute(DiagnosticsBusMessageCountPDU())

    async def diag_read_bus_communication_error_count(self) -> int:
        """Diagnostics sub-function 0x000C: Return Bus Communication Error Count.

        Returns:
            CRC error count.

        """
        return await self.execute(DiagnosticsBusCommunicationErrorCountPDU())

    async def diag_read_bus_exception_error_count(self) -> int:
        """Diagnostics sub-function 0x000D: Return Bus Exception Error Count.

        Returns:
            Exception error count.

        """
        return await self.execute(DiagnosticsBusExceptionErrorCountPDU())

    async def diag_read_server_message_count(self) -> int:
        """Diagnostics sub-function 0x000E: Return Server Message Count.

        Returns:
            Server message count.

        """
        return await self.execute(DiagnosticsServerMessageCountPDU())

    async def diag_read_server_no_response_count(self) -> int:
        """Diagnostics sub-function 0x000F: Return Server No Response Count.

        Returns:
            Server no response count.

        """
        return await self.execute(DiagnosticsServerNoResponseCountPDU())

    async def diag_read_server_nak_count(self) -> int:
        """Diagnostics sub-function 0x0010: Return Server NAK Count.

        Returns:
            Server NAK count.

        """
        return await self.execute(DiagnosticsServerNakCountPDU())

    async def diag_read_server_busy_count(self) -> int:
        """Diagnostics sub-function 0x0011: Return Server Busy Count.

        Returns:
            Server busy count.

        """
        return await self.execute(DiagnosticsServerBusyCountPDU())

    async def diag_read_bus_character_overrun_count(self) -> int:
        """Diagnostics sub-function 0x0012: Return Bus Character Overrun Count.

        Returns:
            Character overrun count.

        """
        return await self.execute(DiagnosticsBusCharacterOverrunCountPDU())

    async def diag_clear_overrun_counter_and_flag(self) -> None:
        """Diagnostics sub-function 0x0014: Clear Overrun Counter and Flag."""
        return await self.execute(DiagnosticsClearOverrunCounterAndFlagPDU())

    async def get_comm_event_counter(self) -> CommEventCounterResponse:
        """Get Comm Event Counter (Function Code 0x0B).

        Returns:
            An instance of CommEventCounterResponse containing status and event_count.

        Example:
            .. code-block:: python

                response = await client.get_comm_event_counter()
                print("Event Count:", response.event_count)

        """
        return await self.execute(GetCommEventCounterPDU())

    async def get_comm_event_log(self) -> CommEventLogResponse:
        """Get Comm Event Log (Function Code 0x0C).

        Returns:
            An instance of CommEventLogResponse containing status, event_count, message_count, and events bytes.

        Example:
            .. code-block:: python

                response = await client.get_comm_event_log()
                print("Message Count:", response.message_count)
                print("Events:", response.events)

        """
        return await self.execute(GetCommEventLogPDU())

    async def read_file_records(
        self,
        requests: list[FileRecordRequest],
    ) -> list[bytes]:
        """Read File Record (Function Code 0x14).

        Args:
            requests: List of file record requests to read.

        Returns:
            List of raw record payloads in the same order as the input requests.

        Example:
            .. code-block:: python

                from tmodbus.pdu import FileRecordRequest
                payloads = await client.read_file_records([
                    FileRecordRequest(file_number=4, record_number=0, record_length=2),
                ])

        """
        return await self.execute(ReadFileRecordPDU(requests=requests))

    async def read_file_record(self, file_number: int, record_number: int, record_length: int) -> bytes:
        """Read a single File Record (Function Code 0x14).

        Args:
            file_number: File number to read from
            record_number: Record number to read from
            record_length: Length of the record to read (in 16-bit words)

        Example:
            .. code-block:: python

                from tmodbus.pdu import FileRecordRequest
                payloads = await client.read_file_record(4, 0, 2)

        """
        payloads = await self.read_file_records(
            [
                FileRecordRequest(
                    file_number=file_number,
                    record_number=record_number,
                    record_length=record_length,
                )
            ]
        )
        return payloads[0]

    async def write_file_records(
        self,
        file_records: list[FileRecord],
    ) -> list[FileRecord]:
        r"""Write File Record (Function Code 0x15).

        Args:
            file_records: List of file records to write.

        Returns:
            Echoed file records from the server.

        Example:
            .. code-block:: python

                from tmodbus.pdu import FileRecord
                written = await client.write_file_records([
                    FileRecord(file_number=4, record_number=0, data=b"\x12\x34"),
                ])

        """
        return await self.execute(WriteFileRecordPDU(file_records=file_records))

    async def write_file_record(
        self,
        file_number: int,
        record_number: int,
        data: bytes,
    ) -> FileRecord:
        r"""Write a single File Record (Function Code 0x15).

        Args:
            file_number: File number to write to
            record_number: Record number to write to
            data: Raw bytes to write (length must be even, as each register is 2 bytes)

        Returns:
            Echoed file record from the server.

        Example:
            .. code-block:: python

                from tmodbus.pdu import FileRecord
                written = await client.write_file_record(4, 0, b"\x12\x34")

        """
        records = await self.write_file_records(
            [
                FileRecord(
                    file_number=file_number,
                    record_number=record_number,
                    data=data,
                )
            ]
        )
        return records[0]

    async def mask_write_register(
        self,
        address: int,
        and_mask: int,
        or_mask: int,
    ) -> tuple[int, int]:
        """Mask Write Register (Function Code 0x16).

        Args:
            address: Register address
            and_mask: AND mask (16-bit)
            or_mask: OR mask (16-bit)


        Returns:
            A tuple with the AND and OR masks that were written.

        Example:
            .. code-block:: python

                await client.mask_write_register(0, 0xFF00, 0x00FF)

        """
        return await self.execute(MaskWriteRegisterPDU(address, and_mask, or_mask))

    async def read_write_multiple_registers(
        self,
        read_start_address: int,
        read_quantity: int,
        write_start_address: int,
        write_values: list[int],
    ) -> list[int]:
        """Read/Write Multiple Registers (Function Code 0x17).

        Args:
            read_start_address: Starting address to read from
            read_quantity: Quantity of registers to read (1-125)
            write_start_address: Starting address to write to
            write_values: List of register values to write, each value 0-65535

        Returns:
            A list of register values read from the device.

        Example:
            .. code-block:: python

                await client.read_write_multiple_registers(0, 1, 0, [1234])

        """
        return await self.execute(
            ReadWriteMultipleRegistersPDU(
                read_start_address=read_start_address,
                read_quantity=read_quantity,
                write_start_address=write_start_address,
                write_values=write_values,
            )
        )

    async def read_fifo_queue(
        self,
        address: int,
    ) -> list[int]:
        """Read FIFO Queue (Function Code 0x18).

        Args:
            address: Address of the FIFO queue to read

        Returns:
            List of register values in the FIFO queue, each value is a 16-bit unsigned integer (0-65535)

        Example:
            .. code-block:: python

                fifo_values = await client.read_fifo_queue(0)  # Read FIFO queue at address 0
                # Returns [100, 200, 300, 400]

        """
        return await self.execute(ReadFifoQueuePDU(address=address))

    async def read_device_identification(
        self,
        device_code: Literal[0x01, 0x02, 0x03, 0x04],
        object_id: int,
    ) -> dict[int, bytes]:
        """Read Device Identification (Function Code 0x2B/0x0E).

        Args:
            device_code: Device code (0x01 for Basic, 0x02 for Regular, 0x03 for Extended, 0x04 for Specific)
            object_id: Object ID to start reading from (0x00 to 0xFF)


        Returns:
            A dictionary mapping object IDs to their raw byte values. Decode them
            with the encoding the device documents (commonly ASCII).

        Example:
            .. code-block:: python

                device_info = await client.read_device_identification(1, 0)
                # Returns {0: b'VendorName', 1: b'ProductCode', ...}
                device_info[0].decode("ascii")
                # Returns 'VendorName'

        """
        result: dict[int, bytes] = {}
        more = True
        number_of_objects: int | None = None
        requested_object_ids: set[int] = set()
        while more:
            if object_id in requested_object_ids:
                # The device says there is more to read but points back at an object we
                # already requested. Stop here instead of looping forever on a device that
                # never advances its next object id.
                logger.warning(
                    "Device repeated object id %#04x while streaming device identification; "
                    "stopping with the objects collected so far.",
                    object_id,
                )
                break
            requested_object_ids.add(object_id)

            response = await self.execute(ReadDeviceIdentificationPDU(device_code, object_id))
            result.update(response.objects)
            more = response.more
            object_id = response.next_object_id

            if number_of_objects is None:
                number_of_objects = response.number_of_objects
            elif number_of_objects != response.number_of_objects:
                logger.warning(
                    "Number of objects changed between requests: was %d, now %d",
                    number_of_objects,
                    response.number_of_objects,
                )

        return result

    async def __aenter__(self) -> Self:
        """Async context manager entry."""
        await self.transport.open()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Async context manager exit."""
        await self.transport.close()

    def for_unit_id(self, unit_id: int) -> "AsyncModbusClient":
        """Create a new client instance for a different unit ID, but using the same connection.

        Args:
            unit_id: The unit ID for the new client instance.

        Returns:
            A new instance of AsyncModbusClient configured for the specified unit ID.

        """
        return AsyncModbusClient(
            self.transport, unit_id=unit_id, word_order=self.word_order, byte_order=self.byte_order
        )
