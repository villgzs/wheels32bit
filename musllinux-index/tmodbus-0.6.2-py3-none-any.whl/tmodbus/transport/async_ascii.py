"""Async ASCII Transport Layer Implementation.

Implements async Modbus ASCII protocol transport based on asyncio, including LRC processing.
"""

import asyncio
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass
from functools import partial
from typing import Any, TypeVar, Unpack, cast

from tmodbus.const import BROADCAST_UNIT_ID, EXCEPTION_RESPONSE_BIT, FUNCTION_CODE_MASK
from tmodbus.exceptions import (
    ASCIIFrameError,
    FunctionCodeError,
    LRCError,
    ModbusConnectionError,
    UnknownModbusResponseError,
    error_code_to_exception_map,
)
from tmodbus.pdu import BaseClientPDU
from tmodbus.utils.lrc import calculate_lrc, validate_lrc
from tmodbus.utils.raw_traffic_logger import log_raw_traffic as base_log_raw_traffic

from .async_base import AsyncBaseTransport
from .async_rtu import SerialXOptions

logger = logging.getLogger(__name__)
log_raw_traffic = partial(base_log_raw_traffic, "ASCII")
RT = TypeVar("RT")

DEFAULT_TIMEOUT = 10.0  # Default timeout in seconds for async operations
MIN_INTERFRAME_GAP = 0.001  # Minimum gap between frames in seconds (1ms)


ASCII_FRAME_START = b":"
ASCII_FRAME_END = b"\r\n"
MAX_ASCII_FRAME_SIZE = 513  # 256 bytes (max RTU) * 2 + 1 for ':' + 2 for \r\n


def ascii_encode(data: bytes) -> bytes:
    """Encode binary data as ASCII hex, with upper-case letters."""
    return data.hex().upper().encode()


def ascii_decode(data: bytes) -> bytes:
    """Decode ASCII hex to binary data."""
    return bytes.fromhex(data.decode())


def build_ascii_frame(address: int, pdu: bytes) -> bytes:
    """Build a Modbus ASCII frame."""
    message = bytes([address]) + pdu
    lrc = calculate_lrc(message)
    # Add LRC as an extra byte to the message before encoding
    message_with_lrc = message + bytes([lrc])
    return ASCII_FRAME_START + ascii_encode(message_with_lrc) + ASCII_FRAME_END


def decode_ascii_frame(frame: bytes) -> bytes:
    """Decode Modbus ASCII frame without validating LRC."""
    if not frame.startswith(ASCII_FRAME_START) or not frame.endswith(ASCII_FRAME_END):
        msg = "Malformed ASCII frame: does not start with ':' and end with '\\r\\n'"
        raise ASCIIFrameError(msg, response_bytes=frame)
    # Remove ':' ... '\r\n'
    hex_payload = frame[1:-2]
    try:
        raw: bytes = ascii_decode(hex_payload)
    except Exception as e:
        msg = "Invalid hex in ASCII frame"
        raise ASCIIFrameError(msg, response_bytes=frame) from e
    if len(raw) < 3:
        msg = "ASCII frame too short"
        raise ASCIIFrameError(msg, response_bytes=frame)
    return raw  # address + pdu + lrc


def validate_ascii_frame(raw: bytes) -> bool:
    """Validate Modbus ASCII frame for correct LRC."""
    # We assume that the provided raw bytes were decoded by the `decode_ascii_frame` function,
    # which already checks for frame structure and minimum length.
    # Therefore, we only need to validate the LRC here.

    return validate_lrc(raw[:-1], raw[-1])


@dataclass(frozen=True)
class _ModbusAsciiMessage:
    """Dataclass representing a Modbus ASCII message with address, PDU, and LRC."""

    unit_id: int
    pdu_bytes: bytes
    lrc: bytes

    @property
    def bytes(self) -> bytes:
        """Get full message bytes including address, PDU, and LRC."""
        return bytes([self.unit_id]) + self.pdu_bytes + self.lrc


@dataclass(frozen=True)
class _PendingRequest:
    """Dataclass representing an in-flight request."""

    unit_id: int
    future: asyncio.Future[_ModbusAsciiMessage]
    pdu: BaseClientPDU[Any]


class ModbusAsciiProtocol(asyncio.Protocol):
    """Asyncio Protocol implementation for Modbus ASCII with frame detection."""

    transport: "asyncio.WriteTransport | None" = None

    on_connection_lost: Callable[[Exception | None], None]
    timeout: float
    interframe_gap: float

    _lock: asyncio.Lock
    _buffer: bytearray
    _last_frame_ended_at: float
    _pending_request: _PendingRequest | None
    _timed_out_requests: dict[int, BaseClientPDU[Any]]

    def __init__(
        self,
        *,
        on_connection_lost: Callable[[Exception | None], None],
        timeout: float = 10.0,
        interframe_gap: float = MIN_INTERFRAME_GAP,
    ) -> None:
        """Initialize Modbus ASCII Protocol."""
        super().__init__()

        self.on_connection_lost = on_connection_lost
        self.timeout = timeout
        self.interframe_gap = interframe_gap

        self._lock = asyncio.Lock()
        self._buffer = bytearray()
        self._last_frame_ended_at = 0.0
        self._pending_request = None
        self._timed_out_requests = {}

        self.connection_made_event = asyncio.Event()

    def connection_made(self, transport: asyncio.BaseTransport) -> None:
        """Handle connection made event."""
        if not isinstance(transport, asyncio.WriteTransport):
            msg = "Expected a WriteTransport"
            raise TypeError(msg)

        self.transport = transport
        logger.info("Modbus ASCII protocol connection established.")
        self.connection_made_event.set()

    async def send_and_receive(self, unit_id: int, pdu: BaseClientPDU[RT]) -> RT:
        r"""Async send PDU and receive response (ASCII mode).

        Implements complete ASCII protocol communication flow:
        1. Build ASCII frame (':' + hex + LRC + '\r\n')
        2. Wait for inter-frame gap
        3. Async send request
        4. Async receive response
        5. Validate LRC and address
        6. Return response PDU
        """
        async with self._lock:
            broadcast_response: RT | None = None
            if unit_id == BROADCAST_UNIT_ID:
                broadcast_response = pdu.get_broadcast_response()

            if self.transport is None or self.transport.is_closing():
                msg = "Not connected."
                raise ModbusConnectionError(msg)

            # Build request frame
            request_pdu_bytes = pdu.encode_request()
            request_adu = build_ascii_frame(unit_id, request_pdu_bytes)

            # Wait for inter-frame gap
            time_since_last_frame = time.monotonic() - self._last_frame_ended_at
            if time_since_last_frame < self.interframe_gap:
                to_wait = self.interframe_gap - time_since_last_frame
                await asyncio.sleep(to_wait)

            # Async send request
            if not pdu.expects_response or broadcast_response is not None:
                # We don't expect a response (broadcast or no-response PDU), so send and return immediately
                self.transport.write(request_adu)
                log_raw_traffic("sent", request_adu)
                self._last_frame_ended_at = time.monotonic()
                if broadcast_response is not None:
                    return broadcast_response
                return cast("RT", None)

            read_future: asyncio.Future[_ModbusAsciiMessage] = asyncio.get_running_loop().create_future()
            self._pending_request = _PendingRequest(unit_id=unit_id, future=read_future, pdu=pdu)

            self.transport.write(request_adu)
            log_raw_traffic("sent", request_adu)
            # Mark the end of this frame
            self._last_frame_ended_at = time.monotonic()

            # Async wait for response or timeout
            try:
                response = await asyncio.wait_for(read_future, timeout=self.timeout)
            except TimeoutError as e:
                # Save PDU for timed-out request so any delayed response can be discarded cleanly
                self._timed_out_requests[unit_id] = pdu
                msg = f"Response timeout after {self.timeout} seconds"
                raise TimeoutError(msg) from e
            except asyncio.CancelledError:
                # Caller cancelled while the request was on the wire: track it like a
                # timeout so a delayed response is not treated as garbage.
                self._timed_out_requests[unit_id] = pdu
                raise
            finally:
                self._pending_request = None

            return self._decode_response_pdu(response, pdu)

    def _decode_response_pdu(self, response: _ModbusAsciiMessage, pdu: BaseClientPDU[RT]) -> RT:
        """Validate and decode the received PDU response."""
        # Check if it's an exception response
        if len(response.pdu_bytes) > 0 and response.pdu_bytes[0] & EXCEPTION_RESPONSE_BIT:
            function_code = response.pdu_bytes[0] & FUNCTION_CODE_MASK
            exception_code = response.pdu_bytes[1] if len(response.pdu_bytes) > 1 else 0

            if exception_code in error_code_to_exception_map:
                raise error_code_to_exception_map[exception_code](function_code)
            raise UnknownModbusResponseError(exception_code, function_code)

        # Validate function code
        response_function_code = response.pdu_bytes[0]
        if response_function_code != pdu.function_code:
            msg = f"Function code mismatch: expected {pdu.function_code}, received {response_function_code}"
            raise FunctionCodeError(msg, response_bytes=response.bytes)

        # Return decoded response
        return pdu.decode_response(response.pdu_bytes)

    def _discard_garbage_data(self) -> None:
        """Discard garbage data from the buffer until we find a frame start."""
        # Look for the next ASCII_FRAME_START (':')
        start_pos = self._buffer.find(ASCII_FRAME_START)

        if start_pos == -1:
            # No start marker found, discard everything
            if len(self._buffer) > 0:
                logger.warning(
                    "No frame start found. Discarding %d bytes: %s",
                    len(self._buffer),
                    self._buffer.hex(" ").upper(),
                )
                self._buffer.clear()
        elif start_pos > 0:
            # Found start marker, discard everything before it
            discarded = bytes(self._buffer[:start_pos])
            logger.warning(
                "Discarding %d byte(s) before frame start: %s",
                start_pos,
                discarded.hex(" ").upper(),
            )
            del self._buffer[:start_pos]

    def _handle_inactive_unit_data(self, unit_id: int, base_function_code: int, raw: bytes) -> None:
        """Handle data for a unit ID with no active request."""
        timed_out_pdu = self._timed_out_requests.get(unit_id)
        if timed_out_pdu is None and self._pending_request is not None and self._pending_request.unit_id == unit_id:
            timed_out_pdu = self._pending_request.pdu

        if timed_out_pdu is not None and base_function_code == (timed_out_pdu.function_code & FUNCTION_CODE_MASK):
            # Only clear tracking when the LRC validates (mirrors RTU's CRC check):
            # a corrupted frame must not consume the tracking for the real delayed response.
            if not validate_ascii_frame(raw):
                logger.warning(
                    "LRC validation failed for delayed response on unit %d. Discarding frame, keeping tracking.",
                    unit_id,
                )
                return
            logger.info(
                "Received delayed response (FC 0x%02X) for timed-out unit %d. Discarding.",
                base_function_code,
                unit_id,
            )
            self._timed_out_requests.pop(unit_id, None)
            return

        logger.warning(
            "Received frame for unit %d with no pending request. Discarding frame.",
            unit_id,
        )

    def _try_discard_delayed_matching_frame(
        self,
        unit_id: int,
        base_function_code: int,
        raw: bytes,
        pending: _PendingRequest,
    ) -> bool:
        """Discard a delayed response for a timed-out request arriving during an active request.

        Returns:
            True if the frame was consumed (discarded), False if it belongs to the active request.

        """
        if base_function_code == (pending.pdu.function_code & FUNCTION_CODE_MASK):
            return False

        timed_out_pdu = self._timed_out_requests.get(unit_id)
        if timed_out_pdu is None or base_function_code != (timed_out_pdu.function_code & FUNCTION_CODE_MASK):
            return False

        # Only clear tracking when the LRC validates (mirrors RTU's CRC check):
        # a corrupted frame must not consume the tracking for the real delayed response.
        if not validate_ascii_frame(raw):
            logger.warning(
                "LRC validation failed for delayed response on unit %d. Discarding frame, keeping tracking.",
                unit_id,
            )
            return True

        logger.info(
            "Received delayed response (FC 0x%02X) for previous timed-out request on unit %d during "
            "active request (FC 0x%02X). Discarding.",
            base_function_code,
            unit_id,
            pending.pdu.function_code,
        )
        self._timed_out_requests.pop(unit_id, None)
        return True

    def data_received(self, data: bytes) -> None:
        """Handle data received event."""
        self._buffer.extend(data)
        log_raw_traffic("recv", data)

        # Try to process complete frames
        while len(self._buffer) >= 1:
            # Look for a complete frame: ':' ... '\r\n'
            if not self._buffer.startswith(ASCII_FRAME_START):
                # Buffer doesn't start with ':', discard garbage
                self._discard_garbage_data()
                continue

            # Look for frame end
            end_pos = self._buffer.find(ASCII_FRAME_END)
            if end_pos == -1:
                # No complete frame yet
                # Check if buffer is getting too large (potential garbage/flood)
                if len(self._buffer) > MAX_ASCII_FRAME_SIZE:
                    logger.warning(
                        "Buffer exceeded max frame size. Discarding %d bytes: %s",
                        len(self._buffer),
                        self._buffer.hex(" ").upper(),
                    )
                    self._buffer.clear()
                return  # Wait for more data

            # Extract complete frame
            frame_length = end_pos + len(ASCII_FRAME_END)
            frame = bytes(self._buffer[:frame_length])
            del self._buffer[:frame_length]

            # Parse framing and hex payload first, then attribute checksum failures by unit_id.
            try:
                raw = decode_ascii_frame(frame)
            except ASCIIFrameError as e:
                logger.warning("Invalid frame received: %s", e)
                # Continue to next frame
                continue

            # Extract unit_id and function code from frame
            unit_id = raw[0]
            pdu_bytes = raw[1:-1]
            base_function_code = pdu_bytes[0] & FUNCTION_CODE_MASK if pdu_bytes else 0

            # Check if this unit_id has an active pending request
            pending = self._pending_request
            has_active_request = pending is not None and pending.unit_id == unit_id and not pending.future.done()

            if not has_active_request:
                self._handle_inactive_unit_data(unit_id, base_function_code, raw)
                continue

            assert pending is not None

            # Active request is present. Check if incoming frame belongs to active request or timed-out request.
            if self._try_discard_delayed_matching_frame(unit_id, base_function_code, raw, pending):
                continue

            if not validate_ascii_frame(raw):
                # The unit id is also part of the raw frame, so in theory it is possible that the LRC is caused by
                # a bit flip on the unit id.

                # However, in most cases this corrupt unit id would not correspond with a pending request,
                # and the frame would have been discarded already anyway.

                # As we're trying to recover from a bad frame, we prefer to fail fast instead of letting pending
                # requests wait for a timeout. Therefore, we set an exception on the pending future and continue.

                pending.future.set_exception(LRCError(response_bytes=frame))
                continue

            # Frame matches active request (or mismatch to be handled downstream) and passed the LRC check
            self._timed_out_requests.pop(unit_id, None)

            # Deliver response to pending request
            pending.future.set_result(
                _ModbusAsciiMessage(
                    unit_id=unit_id,
                    pdu_bytes=pdu_bytes,  # Remove address and LRC
                    lrc=raw[-1:],
                )
            )

    def connection_lost(self, exc: Exception | None) -> None:
        """Handle connection lost event."""
        if self._pending_request is not None and not self._pending_request.future.done():
            self._pending_request.future.set_exception(
                ModbusConnectionError("Connection lost before response was received.")
            )

        self._pending_request = None
        self._timed_out_requests.clear()
        self.transport = None
        self.on_connection_lost(exc)


class AsyncAsciiTransport(AsyncBaseTransport):
    """Async Modbus ASCII Transport Layer Implementation.

    Handles async Modbus Serial communication using the ASCII framing, LRC checking, and timeouts.
    """

    _transport: asyncio.Transport | None = None
    _protocol: "ModbusAsciiProtocol | None" = None

    def __init__(
        self,
        port: str,
        *,
        timeout: float | None = None,
        on_connection_lost: Callable[[Exception | None], None] | None = None,
        **serialx_options: Unpack[SerialXOptions],
    ) -> None:
        """Initialize async Serial transport layer for ASCII.

        Args:
            port: Target serial port (e.g., '/dev/ttyUSB0')
            timeout: Optional timeout for connection and response operations (in seconds)
            on_connection_lost: Optional callback invoked the moment the connection is lost.
                                Receives the causing exception, or None on a clean close.
            serialx_options: Additional SerialX options like baudrate, parity, stopbits, etc.

        """
        self.port = port
        if timeout is None:
            timeout = DEFAULT_TIMEOUT
        self.timeout = timeout
        self.on_connection_lost = on_connection_lost
        self.serialx_options = serialx_options

    async def open(self) -> None:
        """Establish Serial connection."""
        try:
            import serialx  # noqa: PLC0415
        except ImportError as e:  # pragma: no cover
            msg = (
                "The 'serialx' package is required for AsyncAsciiTransport."
                " Install with 'pip install tmodbus[async-serial]'"
            )
            raise ImportError(msg) from e

        loop = asyncio.get_running_loop()
        if self.is_open():
            logger.debug("Serial connection already open: %s", self.port)
            return

        try:
            # Use serialx to create a serial connection with Protocol
            transport, protocol = await asyncio.wait_for(
                serialx.create_serial_connection(
                    loop,
                    lambda: ModbusAsciiProtocol(
                        on_connection_lost=self._on_connection_lost,
                        timeout=self.timeout,
                        interframe_gap=MIN_INTERFRAME_GAP,
                    ),
                    url=self.port,
                    **self.serialx_options,
                ),
                timeout=self.timeout,
            )

            assert isinstance(transport, asyncio.WriteTransport)
            assert isinstance(protocol, ModbusAsciiProtocol)
            self._transport = transport
            self._protocol = protocol

            logger.info("Async Serial connection established to '%s'", self.port)

            # serialx can be slow to call connection_made, we explicitly wait for it here
            assert self._protocol
            await asyncio.wait_for(
                self._protocol.connection_made_event.wait(),
                timeout=self.timeout,
            )

        except TimeoutError:
            logger.debug("Async Serial connection timeout: %s", self.port, exc_info=True)
            self._abort_failed_open()
            raise
        except Exception as e:
            logger.debug("Async Serial connection error: %s", self.port, exc_info=True)
            self._abort_failed_open()
            raise ModbusConnectionError from e

    def _abort_failed_open(self) -> None:
        """Close and clear a partially opened transport after a failed open."""
        if self._transport is not None:
            self._transport.close()
        self._transport = None
        self._protocol = None

    async def close(self) -> None:
        """Close Serial connection."""
        if not self._transport or self._transport.is_closing():
            logger.debug("Serial connection already closed: %s", self.port)
            return

        try:
            self._transport.close()
            logger.info("Serial connection closed: %s", self.port)
        except Exception as e:  # noqa: BLE001
            logger.debug("Error during async connection close: %s", e)

    def is_open(self) -> bool:
        """Check Serial connection status."""
        return self._transport is not None and not self._transport.is_closing()

    def _on_connection_lost(self, exc: Exception | None) -> None:
        if exc:
            logger.error("Async Serial connection lost due to error: %s", exc)
        else:
            logger.info("Async Serial connection closed.")

        self._transport = None
        self._protocol = None

        self._notify_connection_lost(exc)

    async def send_and_receive(self, unit_id: int, pdu: BaseClientPDU[RT]) -> RT:
        """Async send PDU and receive response.

        Args:
            unit_id: Unit identifier (slave address)
            pdu: PDU object to send

        """
        if not self.is_open() or self._protocol is None:
            msg = "Transport is not connected."
            raise ModbusConnectionError(msg)

        return await self._protocol.send_and_receive(unit_id, pdu)
