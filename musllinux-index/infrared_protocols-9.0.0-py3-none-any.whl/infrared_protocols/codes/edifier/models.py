"""Edifier speaker models, command-set groupings, and their mapping.

Mappings can also be found in
https://support.edifier-online.com/hc/en-us/articles/4412111975059-Speaker-Remote-Control-Compatibility-List
"""

from enum import StrEnum


class EdifierCommandSet(StrEnum):
    """Edifier command set groupings."""

    R1700BT_PRE_2017 = "r1700bt_pre_2017"
    R1700BT_2017 = "r1700bt_2017"
    R1700BTS = "r1700bts"
    R1280DB = "r1280db"
    R1280T = "r1280t"
    R2000DB = "r2000db"
    R2730DB = "r2730db"
    S360DB = "s360db"
    RC20G = "rc20g"
    S3000PRO = "s3000pro"


class EdifierModel(StrEnum):
    """Edifier speaker models."""

    # R1700BT (pre-2017) command set
    R1700BT_PRE_2017 = "R1700BT (pre-2017)"
    # R1700BT (2017) command set
    R1700BT_2017 = "R1700BT (2017)"
    # R1700BTs command set
    R1700BTS = "R1700BTs"
    RC17A = "RC17A"
    RC80B = "RC80B"
    R1855DB = "R1855DB"
    # R1280DB command set
    R1280DB = "R1280DB"
    # R1280T command set (basic)
    R1280T = "R1280T"
    # R2000DB command set (RC10D remote)
    R2000DB = "R2000DB"
    # R2730DB command set (RC10D1 remote)
    R2730DB = "R2730DB"
    RC10D1 = "RC10D1"
    # S360DB command set
    S360DB = "S360DB"
    RC31A = "RC31A"
    # RC20G command set (unique left/right volume controls)
    RC20G = "RC20G"
    # S3000 Pro command set (RCA10B remote)
    S3000PRO = "S3000 Pro"


MODEL_TO_COMMAND_SET: dict[EdifierModel, EdifierCommandSet] = {
    # R1700BT (pre-2017) command set
    EdifierModel.R1700BT_PRE_2017: EdifierCommandSet.R1700BT_PRE_2017,
    # R1700BT (2017) command set
    EdifierModel.R1700BT_2017: EdifierCommandSet.R1700BT_2017,
    # R1700BTs command set
    EdifierModel.R1700BTS: EdifierCommandSet.R1700BTS,
    EdifierModel.RC17A: EdifierCommandSet.R1700BTS,
    EdifierModel.RC80B: EdifierCommandSet.R1700BTS,
    EdifierModel.R1855DB: EdifierCommandSet.R1700BTS,
    # R1280DB command set
    EdifierModel.R1280DB: EdifierCommandSet.R1280DB,
    # R1280T command set
    EdifierModel.R1280T: EdifierCommandSet.R1280T,
    # R2000DB command set
    EdifierModel.R2000DB: EdifierCommandSet.R2000DB,
    # R2730DB command set
    EdifierModel.R2730DB: EdifierCommandSet.R2730DB,
    EdifierModel.RC10D1: EdifierCommandSet.R2730DB,
    # S360DB command set
    EdifierModel.S360DB: EdifierCommandSet.S360DB,
    EdifierModel.RC31A: EdifierCommandSet.S360DB,
    # RC20G command set
    EdifierModel.RC20G: EdifierCommandSet.RC20G,
    # S3000 Pro command set
    EdifierModel.S3000PRO: EdifierCommandSet.S3000PRO,
}
