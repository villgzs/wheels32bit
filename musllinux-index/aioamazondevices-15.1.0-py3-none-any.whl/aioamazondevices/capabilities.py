# Copyright 2024 Simone Chemelli and contributors
# SPDX-License-Identifier: Apache-2.0

"""Device capabilities."""

from .const.http import HTTP2_DIRECTIVES_VERSION

DEVICE_CAPABILITIES = {
    "legacyFlags": {
        "SUPPORTS_COMMS": True,
        "SUPPORTS_ARBITRATION": True,
        "SCREEN_WIDTH": 1170,
        "SUPPORTS_SCRUBBING": True,
        "SPEECH_SYNTH_SUPPORTS_TTS_URLS": False,
        "SUPPORTS_HOME_AUTOMATION": True,
        "SUPPORTS_DROPIN_OUTBOUND": True,
        "FRIENDLY_NAME_TEMPLATE": "VOX",
        "SUPPORTS_SIP_OUTBOUND_CALLING": True,
        "VOICE_PROFILE_SWITCHING_DISABLED": True,
        "SUPPORTS_LYRICS_IN_CARD": False,
        "SUPPORTS_DATAMART_NAMESPACE": "Vox",
        "SUPPORTS_VIDEO_CALLING": True,
        "SUPPORTS_PFM_CHANGED": True,
        "SUPPORTS_TARGET_PLATFORM": "TABLET",
        "SUPPORTS_SECURE_LOCKSCREEN": False,
        "AUDIO_PLAYER_SUPPORTS_TTS_URLS": False,
        "SUPPORTS_KEYS_IN_HEADER": False,
        "SUPPORTS_MIXING_BEHAVIOR_FOR_AUDIO_PLAYER": False,
        "AXON_SUPPORT": True,
        "SUPPORTS_TTS_SPEECHMARKS": True,
    },
    "envelopeVersion": HTTP2_DIRECTIVES_VERSION,
    "capabilities": [
        {
            "version": "0.1",
            "interface": "CardRenderer",
            "type": "AlexaInterface",
        },
        {"interface": "Navigation", "type": "AlexaInterface", "version": "1.1"},
        {
            "type": "AlexaInterface",
            "version": "2.0",
            "interface": "Alexa.Comms.PhoneCallController",
        },
        {
            "type": "AlexaInterface",
            "version": "1.1",
            "interface": "ExternalMediaPlayer",
        },
        {
            "type": "AlexaInterface",
            "interface": "Alerts",
            "configurations": {
                "maximumAlerts": {"timers": 2, "overall": 99, "alarms": 2}
            },
            "version": "1.3",
        },
        {
            "version": "1.0",
            "interface": "Alexa.Display.Window",
            "type": "AlexaInterface",
            "configurations": {
                "templates": [
                    {
                        "type": "STANDARD",
                        "id": "app_window_template",
                        "configuration": {
                            "sizes": [
                                {
                                    "id": "fullscreen",
                                    "type": "DISCRETE",
                                    "value": {
                                        "value": {
                                            "height": 1440,
                                            "width": 3200,
                                        },
                                        "unit": "PIXEL",
                                    },
                                }
                            ],
                            "interactionModes": ["mobile_mode", "auto_mode"],
                        },
                    }
                ]
            },
        },
        {
            "type": "AlexaInterface",
            "interface": "AccessoryKit",
            "version": "0.1",
        },
        {
            "type": "AlexaInterface",
            "interface": "Alexa.AudioSignal.ActiveNoiseControl",
            "version": "1.0",
            "configurations": {
                "ambientSoundProcessingModes": [
                    {"name": "ACTIVE_NOISE_CONTROL"},
                    {"name": "PASSTHROUGH"},
                ]
            },
        },
        {
            "interface": "PlaybackController",
            "type": "AlexaInterface",
            "version": "1.0",
        },
        {"version": "1.0", "interface": "Speaker", "type": "AlexaInterface"},
        {
            "version": "1.0",
            "interface": "SpeechSynthesizer",
            "type": "AlexaInterface",
        },
        {
            "version": "1.0",
            "interface": "AudioActivityTracker",
            "type": "AlexaInterface",
        },
        {
            "type": "AlexaInterface",
            "interface": "Alexa.Camera.LiveViewController",
            "version": "1.0",
        },
        {
            "type": "AlexaInterface",
            "version": "1.0",
            "interface": "Alexa.Input.Text",
        },
        {
            "type": "AlexaInterface",
            "interface": "Alexa.PlaybackStateReporter",
            "version": "1.0",
        },
        {
            "version": "1.1",
            "interface": "Geolocation",
            "type": "AlexaInterface",
        },
        {
            "interface": "Alexa.Health.Fitness",
            "version": "1.0",
            "type": "AlexaInterface",
        },
        {"interface": "Settings", "type": "AlexaInterface", "version": "1.0"},
        {
            "configurations": {
                "interactionModes": [
                    {
                        "dialog": "SUPPORTED",
                        "interactionDistance": {"value": 18, "unit": "INCHES"},
                        "video": "SUPPORTED",
                        "keyboard": "SUPPORTED",
                        "id": "mobile_mode",
                        "uiMode": "MOBILE",
                        "touch": "SUPPORTED",
                    },
                    {
                        "video": "UNSUPPORTED",
                        "dialog": "SUPPORTED",
                        "interactionDistance": {"value": 36, "unit": "INCHES"},
                        "uiMode": "AUTO",
                        "touch": "SUPPORTED",
                        "id": "auto_mode",
                        "keyboard": "UNSUPPORTED",
                    },
                ]
            },
            "type": "AlexaInterface",
            "interface": "Alexa.InteractionMode",
            "version": "1.0",
        },
        {
            "type": "AlexaInterface",
            "configurations": {
                "catalogs": [
                    {
                        "type": "IOS_APP_STORE",
                        "identifierTypes": [
                            "URI_HTTP_SCHEME",
                            "URI_CUSTOM_SCHEME",
                        ],
                    }
                ]
            },
            "version": "0.2",
            "interface": "Alexa.Launcher",
        },
        {"interface": "System", "version": "1.0", "type": "AlexaInterface"},
        {
            "interface": "Alexa.IOComponents",
            "type": "AlexaInterface",
            "version": "1.4",
        },
        {
            "type": "AlexaInterface",
            "interface": "Alexa.FavoritesController",
            "version": "1.0",
        },
        {
            "version": "1.0",
            "type": "AlexaInterface",
            "interface": "Alexa.Mobile.Push",
        },
        {
            "type": "AlexaInterface",
            "interface": "InteractionModel",
            "version": "1.1",
        },
        {
            "interface": "Alexa.PlaylistController",
            "type": "AlexaInterface",
            "version": "1.0",
        },
        {
            "interface": "SpeechRecognizer",
            "type": "AlexaInterface",
            "version": "2.1",
        },
        {
            "interface": "AudioPlayer",
            "type": "AlexaInterface",
            "version": "1.3",
        },
        {
            "type": "AlexaInterface",
            "version": "3.1",
            "interface": "Alexa.RTCSessionController",
        },
        {
            "interface": "VisualActivityTracker",
            "version": "1.1",
            "type": "AlexaInterface",
        },
        {
            "interface": "Alexa.PlaybackController",
            "version": "1.0",
            "type": "AlexaInterface",
        },
        {
            "type": "AlexaInterface",
            "interface": "Alexa.SeekController",
            "version": "1.0",
        },
        {
            "interface": "Alexa.Comms.MessagingController",
            "type": "AlexaInterface",
            "version": "1.0",
        },
    ],
}
