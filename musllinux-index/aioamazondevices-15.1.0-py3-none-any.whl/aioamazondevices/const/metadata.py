# Copyright 2024 Simone Chemelli and contributors
# SPDX-License-Identifier: Apache-2.0

"""Metadata constants for Amazon devices."""

SENSOR_STATE_OFF = "NOT_DETECTED"

SENSORS: dict[str, dict[str, str | None]] = {
    "temperatureSensor": {
        "name": "temperature",
        "key": "value",
        "subkey": "value",
        "scale": "scale",
    },
    "motionSensor": {
        "name": "detectionState",
        "key": "detectionStateValue",
        "subkey": None,
        "scale": None,
    },
    "lightSensor": {
        "name": "illuminance",
        "key": "illuminanceValue",
        "subkey": "value",
        "scale": None,
    },
    "connectivity": {
        "name": "reachability",
        "key": "reachabilityStatusValue",
        "subkey": None,
        "scale": None,
    },
    "range": {
        "name": "rangeValue",
        "key": "rangeValue",
        "subkey": "value",
        "scale": None,
    },
}

AQM_RANGE_SENSORS: dict[str, dict[str, str | None]] = {
    "4": {
        "name": "Humidity",
        "scale": "%",
    },
    "5": {
        "name": "VOC",
        "scale": None,
    },
    "6": {
        "name": "PM25",
        "scale": "MicroGramsPerCubicMeter",
    },
    "7": {
        "name": "PM10",
        "scale": "MicroGramsPerCubicMeter",
    },
    "8": {
        "name": "CO",
        "scale": "ppm",
    },
    "9": {
        "name": "Air Quality",
        "scale": None,
    },
}


ALEXA_INFO_SKILLS = [
    "Alexa.Calendar.PlayToday",
    "Alexa.Calendar.PlayTomorrow",
    "Alexa.Calendar.PlayNext",
    "Alexa.Date.Play",
    "Alexa.Time.Play",
    "Alexa.News.NationalNews",
    "Alexa.FlashBriefing.Play",
    "Alexa.Traffic.Play",
    "Alexa.Weather.Play",
    "Alexa.CleanUp.Play",
    "Alexa.GoodMorning.Play",
    "Alexa.SingASong.Play",
    "Alexa.FunFact.Play",
    "Alexa.Joke.Play",
    "Alexa.TellStory.Play",
    "Alexa.ImHome.Play",
    "Alexa.GoodNight.Play",
]

SEQUENCE_BATCH_DELAY = 0.3  # seconds

CUSTOMER_ACCOUNT_MAX_RETRIES = 30
CUSTOMER_ACCOUNT_DELAY_BETWEEN_RETRIES = 2  # seconds

VOLUME_MAX = 100
VOLUME_MIN = 0
