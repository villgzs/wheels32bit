"""Midea local BF device."""

import logging
from enum import StrEnum
from typing import Any, ClassVar, Unpack

from midealocal.const import DeviceType
from midealocal.device import MideaDevice, MideaDeviceInitKwargs, dict_translator

from .message import MessageBFResponse, MessageQuery

_LOGGER = logging.getLogger(__name__)


class DeviceAttributes(StrEnum):
    """Midea BF device attributes."""

    door = "door"
    status = "status"
    time_remaining = "time_remaining"
    current_temperature = "current_temperature"
    tank_ejected = "tank_ejected"
    water_change_reminder = "water_change_reminder"
    water_shortage = "water_shortage"


class MideaBFDevice(MideaDevice):
    """Midea BF device."""

    _status: ClassVar[dict[int, str]] = {
        0x01: "power_save",
        0x02: "standby",
        0x03: "working",
        0x04: "finished",
        0x05: "delay",
        0x06: "paused",
    }

    def __init__(
        self,
        *,
        customize: str,  # noqa: ARG002
        **kwargs: Unpack[MideaDeviceInitKwargs],
    ) -> None:
        """Initialize Midea BF device."""
        super().__init__(
            device_type=DeviceType.BF,
            **kwargs,
            attributes={
                DeviceAttributes.door: None,
                DeviceAttributes.status: None,
                DeviceAttributes.time_remaining: None,
                DeviceAttributes.current_temperature: None,
                DeviceAttributes.tank_ejected: None,
                DeviceAttributes.water_change_reminder: None,
                DeviceAttributes.water_shortage: None,
            },
        )

    def build_query(self) -> list[MessageQuery]:
        """Midea BF device build query."""
        return [MessageQuery(self._message_protocol_version)]

    def process_message(self, msg: bytes) -> dict[str, Any]:
        """Midea BF device process message."""
        message = MessageBFResponse(msg)
        _LOGGER.debug("[%s] Received: %s", self.device_id, message)
        return self.update_attributes_from_message(
            message,
            {
                DeviceAttributes.status: dict_translator(
                    MideaBFDevice._status,
                    default="unknown",
                ),
            },
        )

    def set_attribute(self, attr: str, value: bool | float | str) -> None:
        """Midea BF device set attribute."""


class MideaAppliance(MideaBFDevice):
    """Midea BF appliance."""
