from typing import Dict

ALARM_MESSAGES = [
    {"key": None, "text": "No error"},
    {"key": "alarm_extract_stop", "text": "Extract air fan "},
    {"key": "alarm_supply_stop", "text": "Supply air fan "},
    {"key": "alarm_cell_frozen", "text": "HR cell frozen"},
    {"key": "alarm_temp_sensor1", "text": "Temp. sensor 1"},
    {"key": "alarm_temp_sensor2", "text": "Temp. sensor 2"},
    {"key": "alarm_temp_sensor3", "text": "Temp. sensor 3"},
    {"key": "alarm_temp_sensor4", "text": "Temp. sensor 4"},
    {"key": "alarm_temp_sensor5", "text": "Temp. sensor 5"},
    {"key": "alarm_filter", "text": "Filters dirty"},
    {"key": "alarm_optional_temp_sensor", "text": "External sensor"},
    {"key": "alarm_postheater", "text": "Post-heater"},
    {"key": "alarm_liquid_radiator_freezing", "text": "Liquid radiator freezing risk"},
    {"key": "alarm_tor0_duct_sensor", "text": "Duct temperature sensor module 1"},
    {"key": "alarm_tor0_STB2", "text": "STB 2 module 1"},
    {"key": "alarm_tor1_duct_sensor", "text": "Duct temperature sensor module 2"},
    {"key": "alarm_tor1_STB2", "text": "STB 2 module 2"},
    {"key": "alarm_tor0_STB1", "text": "STB 1 module 1"},
    {"key": "alarm_tor1_STB1", "text": "STB 1 module 2"},
    {"key": "alarm_tor0_frost_temp", "text": "Water temperature sensor module 1"},
    {"key": "alarm_tor1_frost_temp", "text": "Water temperature sensor module 2"},
    {"key": "alarm_tor0_frost_coil", "text": "Water temperature module 1"},
    {"key": "alarm_tor1_frost_coil", "text": "Water temperature module 2"},
    {"key": "alarm_supply_too_low", "text": "Low supply air temperature"},
    {"key": "alarm_tor0_communication", "text": "Communication error"},
]


ConstantsDict = Dict[str, Dict[str, int]]
