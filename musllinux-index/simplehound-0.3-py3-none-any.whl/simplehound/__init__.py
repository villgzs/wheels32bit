"""Init file for Simplehound."""
