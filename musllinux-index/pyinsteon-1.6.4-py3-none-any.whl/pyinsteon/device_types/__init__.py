"""Insteon device types."""
