"""Constants used by device groups and events."""

ON_INBOUND = "on_inbound"
OFF_INBOUND = "off_inbound"
ON_FAST_INBOUND = "on_fast_inbound"
OFF_FAST_INBOUND = "off_fast_inbound"
ON_ALL_LINK_CLEANUP = "on_all_link_cleanup"
OFF_ALL_LINK_CLEANUP = "off_all_link_cleanup"
OPEN_INBOUND = "open_inbound"
CLOSE_INBOUND = "close_inbound"

ON_HEARTBEAT_INBOUND = "on_heartbeat_inbound"
OFF_HEARTBEAT_INBOUND = "off_heartbeat_inbound"

STATUS_COMMAND = "status_command"

ON_COMMAND = "on_command"
OFF_COMMAND = "off_command"
ON_FAST_COMMAND = "on_fast_command"
OFF_FAST_COMMAND = "off_fast_command"

GET_OPERATING_FLAGS_COMMAND = "get_operating_flags"
SET_OPERATING_FLAGS_COMMAND = "set_operating_flags"
EXTENDED_GET_COMMAND = "extended_get"
EXTENDED_SET_COMMAND = "extended_set"
EXTENDED_GET_RESPONSE = "extended_get_response"

SET_LEDS_COMMAND = "set_leds"
TRIGGER_SCENE_ON_COMMAND = "trigger_scene_on"
TRIGGER_SCENE_OFF_COMMAND = "trigger_scene_off"

GET_IM_CONFIG_COMMAND = "get_im_config"
SET_IM_CONFIG_COMMAND = "set_im_config"

MANUAL_CHANGE = "manual_change"
ON_AT_RAMP_RATE = "on_at_ramp_rate"
OFF_AT_RAMP_RATE = "off_at_ramp_rate"
