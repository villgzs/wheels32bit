"""Data types for pyinsteon."""
