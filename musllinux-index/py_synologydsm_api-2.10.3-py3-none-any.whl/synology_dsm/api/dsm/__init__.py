"""Synology DSM API models."""
