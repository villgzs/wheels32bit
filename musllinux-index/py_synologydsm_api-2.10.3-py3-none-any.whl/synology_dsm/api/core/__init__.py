"""Synology Core API models."""
