"""Model for the forecast endpoint."""

from dataclasses import dataclass, field
import datetime
from dataclasses_json import dataclass_json, config
from enum import Enum
import time


class Condition(Enum):
    CLEAR = "Clear"
    RAIN_LIKELY = "Rain Likely"
    RAIN_POSSIBLE = "Rain Possible"
    SNOW = "Snow"
    SNOW_LIKELY = "Snow Likely"
    SNOW_POSSIBLE = "Snow Possible"
    WINTRY_MIX_LIKELY = "Wintry Mix Likely"
    WINTRY_MIX_POSSIBLE = "Wintry Mix Possible"
    THUNDERSTORMS_LIKELY = "Thunderstorms Likely"
    THUNDERSTORMS_POSSIBLE = "Thunderstorms Possible"
    WINDY = "Windy"
    FOGGY = "Foggy"
    CLOUDY = "Cloudy"
    PARTLY_CLOUDY = "Partly Cloudy"
    VERY_LIGHT_RAIN = "Very Light Rain"
    LIGHT_RAIN = "Light Rain"
    MODERATE_RAIN = "Moderate Rain"
    HEAVY_RAIN = "Heavy Rain"
    VERY_HEAVY_RAIN = "Very Heavy Rain"
    EXTREME_RAIN = "Extreme Rain"
    UNKNOWN = ""


class Icon(Enum):
    CLEAR_DAY = "clear-day"
    CLEAR_NIGHT = "clear-night"
    CLOUDY = "cloudy"
    FOGGY = "foggy"
    PARTLY_CLOUDY_DAY = "partly-cloudy-day"
    PARTLY_CLOUDY_NIGHT = "partly-cloudy-night"
    POSSIBLY_RAINY_DAY = "possibly-rainy-day"
    POSSIBLY_RAINY_NIGHT = "possibly-rainy-night"
    POSSIBLY_SLEET_DAY = "possibly-sleet-day"
    POSSIBLY_SLEET_NIGHT = "possibly-sleet-night"
    POSSIBLY_SNOW_DAY = "possibly-snow-day"
    POSSIBLY_SNOW_NIGHT = "possibly-snow-night"
    POSSIBLY_THUNDERSTORM_DAY = "possibly-thunderstorm-day"
    POSSIBLY_THUNDERSTORM_NIGHT = "possibly-thunderstorm-night"
    RAINY = "rainy"
    SLEET = "sleet"
    SNOW = "snow"
    THUNDERSTORM = "thunderstorm"
    WINDY = "windy"
    UNKNOWN = ""

    @property
    def emoji(self) -> str:
        icon_mapping = {
            Icon.CLEAR_DAY: "☀️",
            Icon.CLEAR_NIGHT: "🌌️",
            Icon.CLOUDY: "☁️",
            Icon.FOGGY: "🌫️",
            Icon.PARTLY_CLOUDY_DAY: "⛅️",
            Icon.PARTLY_CLOUDY_NIGHT: "☁️",
            Icon.POSSIBLY_RAINY_DAY: "🌧️",
            Icon.POSSIBLY_RAINY_NIGHT: "🌧️",
            Icon.POSSIBLY_SLEET_DAY: "🌨️",
            Icon.POSSIBLY_SLEET_NIGHT: "🌨️",
            Icon.POSSIBLY_SNOW_DAY: "❄️",
            Icon.POSSIBLY_SNOW_NIGHT: "❄️",
            Icon.POSSIBLY_THUNDERSTORM_DAY: "⛈️",
            Icon.POSSIBLY_THUNDERSTORM_NIGHT: "⛈️",
            Icon.RAINY: "🌧️",
            Icon.SLEET: "🌨️",
            Icon.SNOW: "❄️️",
            Icon.THUNDERSTORM: "⛈️",
            Icon.WINDY: "💨️",
        }
        return icon_mapping.get(self, "❓️")

    @property
    def ha_icon(self) -> str:
        icon_mapping = {
            Icon.CLEAR_DAY: "sunny",
            Icon.CLEAR_NIGHT: "clear-night",
            Icon.CLOUDY: "cloudy",
            Icon.FOGGY: "fog",
            Icon.PARTLY_CLOUDY_DAY: "partlycloudy",
            Icon.PARTLY_CLOUDY_NIGHT: "partlycloudy",
            Icon.POSSIBLY_RAINY_DAY: "rainy",
            Icon.POSSIBLY_RAINY_NIGHT: "rainy",
            Icon.POSSIBLY_SLEET_DAY: "snowy-rainy",
            Icon.POSSIBLY_SLEET_NIGHT: "snowy-rainy",
            Icon.POSSIBLY_SNOW_DAY: "snowy",
            Icon.POSSIBLY_SNOW_NIGHT: "snowy",
            Icon.POSSIBLY_THUNDERSTORM_DAY: "lightning-rainy",
            Icon.POSSIBLY_THUNDERSTORM_NIGHT: "lightning-rainy",
            Icon.RAINY: "rainy",
            Icon.SLEET: "snowy-rainy",
            Icon.SNOW: "snowy",
            Icon.THUNDERSTORM: "lightning-rainy",
            Icon.WINDY: "windy",
        }
        return icon_mapping.get(self, "exceptional")


class PrecipType(Enum):
    RAIN = "rain"
    SNOW = "snow"
    SLEET = "sleet"
    STORM = "storm"
    NONE = "none"

    @classmethod
    def from_string(cls, value: str) -> "PrecipType":
        value_map = {
            "mixed_winter_precip": cls.SLEET,
            **{member.value: member for member in cls},
        }
        return value_map.get(value.lower(), cls.NONE)

    @staticmethod
    def _decoder(value):
        if isinstance(value, PrecipType):
            return value
        if value is None:
            return PrecipType.NONE
        return PrecipType.from_string(value)

    @staticmethod
    def _encoder(value):
        return value.value


class PrecipIcon(Enum):
    CHANCE_RAIN = "chance-rain"
    CHANCE_SNOW = "chance-snow"
    CHANCE_SLEET = "chance-sleet"
    NONE = "none"


class PressureTrend(Enum):
    FALLING = "falling"
    STEADY = "steady"
    RISING = "rising"
    UNKNOWN = "unknown"


class WindDirection(Enum):
    N = "N"
    NNE = "NNE"
    NE = "NE"
    ENE = "ENE"
    E = "E"
    ESE = "ESE"
    SE = "SE"
    SSE = "SSE"
    S = "S"
    SSW = "SSW"
    SW = "SW"
    WSW = "WSW"
    W = "W"
    WNW = "WNW"
    NW = "NW"
    NNW = "NNW"


class TemperatureUnit(Enum):
    CELSIUS = "C"
    FAHRENHEIT = "F"


class WindSpeedUnit(Enum):
    METERS_PER_SECOND = "m/s"
    KILOMETERS_PER_HOUR = "km/h"
    MILES_PER_HOUR = "mph"


class VisibilityUnit(Enum):
    KILOMETERS = "km"
    MILES = "mi"


@dataclass_json()
@dataclass(frozen=True, eq=True)
class CurrentConditions:
    conditions: Condition

    feels_like: float
    icon: Icon  # Added missing field
    is_precip_local_day_rain_check: bool

    relative_humidity: int
    sea_level_pressure: float

    wind_avg: float
    wind_direction: float
    wind_direction_cardinal: WindDirection
    wind_gust: float

    time: int = int(time.time())
    air_temperature: float | None = None
    uv: int | None = None
    wet_bulb_globe_temperature: float | None = None
    wet_bulb_temperature: float | None = None
    solar_radiation: int | None = None
    pressure_trend: PressureTrend = PressureTrend.UNKNOWN

    brightness: int | None = None
    station_pressure: float | None = None
    delta_t: float | None = None
    dew_point: float | None = None
    lightning_strike_count_last_1hr: int = 0
    lightning_strike_count_last_3hr: int = 0
    lightning_strike_last_distance: int = 0
    lightning_strike_last_distance_msg: str = ""
    lightning_strike_last_epoch: int | None = None
    precip_accum_local_day: int | None = None
    precip_accum_local_yesterday: int | None = None
    precip_minutes_local_day: int | None = None
    precip_minutes_local_yesterday: int | None = None
    air_density: float | None = None
    is_precip_local_yesterday_rain_check: bool | None = None


@dataclass_json
@dataclass(frozen=True, eq=True)
class ForecastDaily:
    air_temp_high: float
    air_temp_low: float
    day_num: int
    day_start_local: int
    icon: Icon
    month_num: int
    precip_probability: int
    sunrise: int
    sunset: int
    conditions: Condition
    # precip_type: PrecipType = PrecipType.NONE
    precip_type: PrecipType | None = field(
        default=PrecipType.NONE,
        metadata=config(encoder=PrecipType._encoder, decoder=PrecipType._decoder),
    )
    precip_icon: PrecipIcon = PrecipIcon.NONE

    @property
    def rfc3939_datetime(self):
        utc_datetime = datetime.datetime.fromtimestamp(
            self.day_start_local, datetime.UTC
        )
        return utc_datetime.strftime("%Y-%m-%dT%H:%M:%SZ")

    @property
    def ha_forecast(self) -> dict:
        return {
            "datetime": self.rfc3939_datetime,
            "is_daytime": None,
            "cloud_coverage": None,
            "condition": self.icon.ha_icon,
            "humidity": None,
            "native_apparent_temperature": None,
            "native_dew_point": None,
            "native_precipitation": None,
            "native_pressure": None,
            "native_temperature": self.air_temp_high,
            "native_templow": self.air_temp_low,
            "native_wind_gust_speed": None,
            "native_wind_speed": None,
            "precipitation_probability": self.precip_probability,
            "uv_index": None,
            "wind_bearing": None,
        }


@dataclass_json
@dataclass(frozen=True, eq=True)
class ForecastHourly:
    air_temperature: float

    local_day: int
    local_hour: int
    precip: float
    # precip_type: PrecipType
    precip_type: PrecipType = field(
        metadata=config(encoder=PrecipType._encoder, decoder=PrecipType._decoder)
    )
    relative_humidity: int
    time: int
    wind_avg: float
    wind_direction_cardinal: WindDirection
    wind_direction: float
    wind_gust: float

    conditions: Condition | None = None
    icon: Icon | None = None
    feels_like: float | None = None
    uv: float | None = None
    sea_level_pressure: float | None = None
    precip_probability: int | None = None

    @property
    def rfc3939_datetime(self):
        utc_datetime = datetime.datetime.fromtimestamp(self.time, datetime.UTC)
        return utc_datetime.strftime("%Y-%m-%dT%H:%M:%SZ")

    @property
    def ha_forecast(self) -> dict:
        """Property for Home Assistant to use"""
        return {
            # UTC Date time in RFC 3339 format.
            "datetime": self.rfc3939_datetime,
            "condition": self.icon.ha_icon if self.icon else None,
            "humidity": self.relative_humidity,
            "native_apparent_temperature": self.feels_like,
            "native_precipitation": self.precip,
            "native_pressure": self.sea_level_pressure,
            "native_temperature": self.air_temperature,
            "native_wind_gust_speed": int(self.wind_gust),
            "native_wind_speed": self.wind_avg,
            "precipitation_probability": self.precip_probability,
            "uv_index": self.uv,
            "wind_bearing": self.wind_direction,
        }


@dataclass_json
@dataclass(frozen=True, eq=True)
class Forecast:
    daily: list[ForecastDaily]
    hourly: list[ForecastHourly]


@dataclass_json
@dataclass(frozen=True, eq=True)
class ForecastUnits:
    units_air_density: str
    units_brightness: str
    units_distance: str
    units_other: str
    units_precip: str
    units_pressure: str
    units_solar_radiation: str
    units_temp: str
    units_wind: str


@dataclass_json
@dataclass(frozen=True, eq=True)
class WeatherDataForecastREST:
    forecast: Forecast
    latitude: float
    longitude: float
    location_name: str
    timezone: str
    timezone_offset_minutes: int
    units: ForecastUnits
    current_conditions: CurrentConditions
