"""Async client for AWS services, wrapping botocore with aiohttp/httpx."""

__version__ = '3.7.0'
