"""Provides handling of TCC gateways."""

from __future__ import annotations

from functools import cached_property
from typing import TYPE_CHECKING, Final

from .const import (
    SZ_ACTIVE_FAULTS,
    SZ_GATEWAY_ID,
    SZ_GATEWAY_INFO,
    SZ_MAC,
    SZ_SYSTEM_ID,
    SZ_TEMPERATURE_CONTROL_SYSTEMS,
)
from .control_system import ControlSystem
from .schemas.const import TccEntityType
from .schemas.helpers import Case
from .schemas.status import factory_gwy_status
from .typedefs import EvoGwyStatusT
from .zone import ActiveFaultsBase

if TYPE_CHECKING:
    import logging

    import voluptuous as vol

    from . import Location
    from .auth import Auth
    from .typedefs import EvoGwyConfigResponseT, EvoGwyConfigT, EvoGwyStatusResponseT


class Gateway(ActiveFaultsBase[EvoGwyStatusT]):
    """Instance of a location's gateway."""

    _TCC_TYPE = TccEntityType.GWY

    SCH_STATUS: vol.Schema = factory_gwy_status(Case.PYTHONIC)

    def __init__(self, location: Location, config: EvoGwyConfigResponseT) -> None:
        super().__init__(config[SZ_GATEWAY_INFO][SZ_GATEWAY_ID])

        self.location = location  # parent

        # children
        self.systems: list[ControlSystem] = []
        self.system_by_id: dict[str, ControlSystem] = {}  # tcs by id

        self._config: Final = config[SZ_GATEWAY_INFO]

        for tcs_entry in config[SZ_TEMPERATURE_CONTROL_SYSTEMS]:
            tcs = ControlSystem(self, tcs_entry)

            self.systems.append(tcs)
            self.system_by_id[tcs.id] = tcs

    @cached_property
    def _auth(self) -> Auth:
        return self.location.client.auth

    @cached_property
    def _logger(self) -> logging.Logger:
        return self.location.client.logger

    @property  # not strictly static, but library largely assumes so
    def config(self) -> EvoGwyConfigT:
        """Return the latest config of the entity."""
        return self._config

    # Config attrs...

    @cached_property
    def mac_address(self) -> str:
        return self._config[SZ_MAC]

    # Status (state) attrs & methods...

    def _update_status(self, status: EvoGwyStatusResponseT) -> None:
        """Update the GWY's status and cascade to its descendants."""

        self._update_faults(status[SZ_ACTIVE_FAULTS])

        # cascade the child status to descendants...
        for tcs_status in status[SZ_TEMPERATURE_CONTROL_SYSTEMS]:
            if tcs := self.system_by_id.get(tcs_status[SZ_SYSTEM_ID]):
                tcs._update_status(tcs_status)  # noqa: SLF001

            else:
                self._logger.warning(
                    f"{self}: system_id='{tcs_status[SZ_SYSTEM_ID]}' not known"
                    ", (has the gateway configuration been changed?)"
                )

        # the entity's own status, without its children's...
        self._status = {
            SZ_GATEWAY_ID: status[SZ_GATEWAY_ID],
            SZ_ACTIVE_FAULTS: status[SZ_ACTIVE_FAULTS],
        }
