"""The Eheim Digital package."""

__version__ = "1.7.1"
