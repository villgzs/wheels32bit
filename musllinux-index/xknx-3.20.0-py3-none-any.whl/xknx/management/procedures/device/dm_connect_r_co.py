"""DM_Connect — KNX v02.01.02 - Management Procedures 03.05.02 - §3.2.1."""

from __future__ import annotations

from xknx.exceptions import ManagementConnectionError
from xknx.management.management import P2PConnection
from xknx.telegram import apci

__all__ = ["dmp_connect_r_co"]


async def dmp_connect_r_co(conn: P2PConnection) -> int:
    """
    Confirm an open P2P connection by reading the device descriptor (DD0).

    DMP_Connect_RCo — KNX v02.01.02 - Management Procedures 03.05.02 -
    §3.2.1. The transport-layer connection must already be established.
    Returns the mask version (DD0 value).

    :param conn: an established P2P connection to the device
    :return: Device Descriptor Type 0 value (mask version, 2 bytes)
    """
    response = await conn.request(
        payload=apci.DeviceDescriptorRead(descriptor=0),
        expected=apci.DeviceDescriptorResponse,
    )
    # `expected` guarantees this via `P2PConnection._receive`
    assert isinstance(response.payload, apci.DeviceDescriptorResponse)
    if response.payload.descriptor != 0:
        raise ManagementConnectionError(
            f"Expected Device Descriptor Type 0, got type {response.payload.descriptor}"
        )
    return response.payload.value
