"""XKNX version."""

__version__ = "3.20.0"
