"""Abstraction for a KNXnet/IP device management connection."""

from __future__ import annotations

from abc import ABC, abstractmethod
import asyncio
from collections.abc import Callable
import logging

from xknx.cemi import (
    CEMIErrorCode,
    CEMIFrame,
    CEMIMessageCode,
    CEMIMPropInfo,
    CEMIMPropReadRequest,
    CEMIMPropReadResponse,
    CEMIMPropWriteRequest,
    CEMIMPropWriteResponse,
)
from xknx.exceptions import (
    CommunicationError,
    CouldNotParseCEMI,
    UnsupportedCEMIMessage,
)
from xknx.knxip import (
    HPAI,
    ConnectRequestInformation,
    DeviceConfigurationRequest,
    DisconnectRequest,
    DisconnectResponse,
    HostProtocol,
    KNXIPFrame,
    KNXIPServiceType,
)
from xknx.knxip.knxip_enum import ConnectRequestType
from xknx.profile.const import ResourceObjectType, ResourcePropertyId
from xknx.typing import Self
from xknx.util import asyncio_timeout

from .const import (
    DEVICE_CONFIGURATION_REQUEST_REPETITIONS,
    DEVICE_CONFIGURATION_REQUEST_TIMEOUT,
)
from .data_connection import ConnectionHeartbeat
from .device_management import DeviceManagement
from .ip_secure import SecureSession
from .request_response import Connect, ConnectionState, DeviceConfiguration, Disconnect
from .transport import KNXIPTransport, TCPTransport, UDPTransport

logger = logging.getLogger("xknx.log")


def _same_property(one: CEMIMPropInfo, other: CEMIMPropInfo) -> bool:
    """Tell whether two property infos address the same Property."""
    return (
        one.object_type is other.object_type
        and one.object_instance == other.object_instance
        and one.property_id == other.property_id
    )


def _format_error_code(error_code: CEMIErrorCode | int) -> str:
    """Return a readable form of an error code, defined by the spec or not."""
    if isinstance(error_code, CEMIErrorCode):
        return error_code.name
    return f"0x{error_code:02x}"


class _DeviceManagementConnection(ABC):
    """
    A KNXnet/IP device management connection to one server.

    Reads and writes the Properties of the server's own Interface Objects -
    its KNXnet/IP Parameter Object and Device Object - over a device
    management connection, which is a separate connection type from
    tunnelling and unrelated to the KNX bus behind the server. It is
    therefore not an `Interface`: it carries no telegrams, has no individual
    address and does not touch `xknx.current_address` or the connection
    manager.

    Requests are answered by the server with a cEMI frame of its own, so the
    connection tracks which request is outstanding and returns the matching
    answer. Frames the server sends unprompted - `M_PropInfo.ind` for the
    evented device state, and the cEMI Transport Layer indications - go to
    `indication_callback` instead.

    The connection is supervised: a heartbeat keeps it alive and closes it
    when the server stops answering, and a DisconnectRequest of the server
    is answered and ends it as well.
    """

    __slots__ = (
        "_data_endpoint_addr",
        "_disconnect_callback",
        "_heartbeat",
        "_pending",
        "_request_lock",
        "communication_channel",
        "gateway_ip",
        "gateway_port",
        "indication_callback",
        "local_hpai",
        "sequence_number",
        "transport",
    )

    transport: KNXIPTransport

    def __init__(
        self,
        gateway_ip: str,
        gateway_port: int,
        indication_callback: Callable[[CEMIFrame], None] | None = None,
    ) -> None:
        """Initialize _DeviceManagementConnection class."""
        self.gateway_ip = gateway_ip
        self.gateway_port = gateway_port
        self.indication_callback = indication_callback

        self.local_hpai = HPAI()
        self.communication_channel: int | None = None
        self.sequence_number = 0
        self._data_endpoint_addr: tuple[str, int] | None = None
        self._disconnect_callback: KNXIPTransport.Callback | None = None
        self._pending: asyncio.Future[CEMIFrame] | None = None
        self._request_lock = asyncio.Lock()
        self._heartbeat = ConnectionHeartbeat(
            name="Device management connection",
            send_connectionstate=self._connectionstate_request,
            on_failure=self.disconnect,
        )

        self._init_transport()

    @abstractmethod
    def _init_transport(self) -> None:
        """Initialize transport."""
        # set up self.transport

    @abstractmethod
    async def _setup_connection(self) -> None:
        """Set up the connection before sending a ConnectRequest."""
        # eg. set the local HPAI used for the control and data endpoint

    @abstractmethod
    def _start_receiving(self) -> None:
        """Start handling DeviceConfigurationRequests the server sends."""

    @abstractmethod
    def _stop_receiving(self) -> None:
        """Stop handling DeviceConfigurationRequests the server sends."""

    @abstractmethod
    async def _send_request(self, cemi: CEMIFrame) -> None:
        """Send a request. Raise CommunicationError when that fails."""

    async def __aenter__(self) -> Self:
        """Connect on entering a context."""
        await self.connect()
        return self

    async def __aexit__(self, *args: object) -> None:
        """Disconnect on leaving a context."""
        await self.disconnect()

    ####################
    #
    # CONNECT DISCONNECT
    #
    ####################

    async def connect(self) -> None:
        """Open the device management connection. Raise CommunicationError if it fails."""
        if self.communication_channel is not None:
            raise CommunicationError(
                "Device management connection is already open. "
                f"communication_channel={self.communication_channel}"
            )
        try:
            await self.transport.connect()
            await self._setup_connection()
            await self._connect_request()
        except (OSError, CommunicationError) as ex:
            # `_connect_request` may have failed after setting up connection
            # state, so a failed attempt does not leave a channel behind.
            self._connection_lost()
            raise CommunicationError(
                f"Device management connection could not be established: {ex}"
            ) from ex

        self._heartbeat.start()

    async def _connect_request(self) -> None:
        """Send a ConnectRequest and set up the connection from its response."""
        connect = Connect(
            transport=self.transport,
            local_hpai=self.local_hpai,
            cri=ConnectRequestInformation(
                connection_type=ConnectRequestType.DEVICE_MGMT_CONNECTION,
            ),
        )
        await connect.start()
        if not connect.success:
            raise CommunicationError(
                f"ConnectRequest failed. Status code: {connect.response_status_code}"
            )

        self.communication_channel = connect.communication_channel
        self.sequence_number = 0
        self._data_endpoint_addr = (
            None
            if connect.data_endpoint.route_back
            else connect.data_endpoint.addr_tuple
        )
        self._start_receiving()
        self._disconnect_callback = self.transport.register_callback(
            self._disconnect_request_received,
            [KNXIPServiceType.DISCONNECT_REQUEST],
        )
        logger.debug(
            "Device management connection established. communication_channel=%s",
            self.communication_channel,
        )

    async def disconnect(self) -> None:
        """Close the device management connection."""
        self._stop()
        # Cleared before the Disconnect exchange, so a request failed by
        # `_stop()` already sees the connection closed when it wakes up.
        channel = self.communication_channel
        self.communication_channel = None
        try:
            if channel is not None:
                disconnect = Disconnect(
                    transport=self.transport,
                    communication_channel_id=channel,
                    local_hpai=self.local_hpai,
                )
                await disconnect.start()
                if not disconnect.success:
                    logger.debug(
                        "DisconnectRequest was not answered by the server (%s).",
                        "timeout"
                        if disconnect.response_status_code is None
                        else disconnect.response_status_code,
                    )
        finally:
            self.transport.stop()

    def _stop(self) -> None:
        """Stop answering and expecting frames of the current connection."""
        self._heartbeat.stop()
        self._stop_receiving()
        if self._disconnect_callback is not None:
            self.transport.unregister_callback(self._disconnect_callback)
            self._disconnect_callback = None
        if self._pending is not None and not self._pending.done():
            # Fail a request waiting for an answer instead of timing it out.
            self._pending.cancel()

    def _connection_lost(self) -> None:
        """Tear the connection state down without a Disconnect exchange."""
        self.communication_channel = None
        self._stop()
        self.transport.stop()

    def _disconnect_request_received(
        self, knxipframe: KNXIPFrame, source: HPAI, _transport: KNXIPTransport
    ) -> None:
        """Handle a DisconnectRequest sent by the server."""
        if not isinstance(knxipframe.body, DisconnectRequest):
            return
        if knxipframe.body.communication_channel_id != self.communication_channel:
            logger.debug(
                "Received DisconnectRequest for another communication channel "
                "than %s. Discarding frame: %s",
                self.communication_channel,
                knxipframe.body,
            )
            return
        logger.info("Device management connection was closed by the server.")
        self.transport.send(
            KNXIPFrame.init_from_body(
                DisconnectResponse(communication_channel_id=self.communication_channel)
            )
        )
        self._connection_lost()

    async def _connectionstate_request(self) -> tuple[bool, str | None] | None:
        """Send a ConnectionStateRequest and return its outcome. Heartbeat callback."""
        if self.communication_channel is None:
            # The connection is already gone - end the heartbeat quietly.
            return None
        conn_state = ConnectionState(
            transport=self.transport,
            communication_channel_id=self.communication_channel,
            local_hpai=self.local_hpai,
        )
        await conn_state.start()
        status_code: str | None = None
        if error_code := conn_state.response_status_code:
            status_code = error_code.name
        return conn_state.success, status_code

    ####################
    #
    # REQUESTS
    #
    ####################

    async def request(
        self,
        cemi: CEMIFrame,
        matches: Callable[[CEMIFrame], bool] | None = None,
    ) -> CEMIFrame:
        """
        Send one cEMI frame and return the one the server answers with.

        `matches` tells whether a received frame is the awaited answer;
        frames it rejects - e.g. the late answer to an earlier, timed out
        request for another property - are discarded. A retry of the very
        same request is indistinguishable from its predecessor, so a stale
        answer can still satisfy that. Without `matches`, the first frame
        that is not an indication is returned. Note that xknx only parses
        the Property service message codes, so e.g. a M_FuncProp request
        cannot see its answer - and M_Reset.req has none at all.

        Raise CommunicationError when the request is not acknowledged or the
        server does not answer it.
        """
        # A device management connection carries one request at a time, and
        # the sequence counter and the pending answer are shared state.
        async with self._request_lock:
            if self.communication_channel is None:
                raise CommunicationError("No active device management connection.")
            pending: asyncio.Future[CEMIFrame] = (
                asyncio.get_running_loop().create_future()
            )
            self._pending = pending
            try:
                await self._send_request(cemi)
                # The spec defines this timeout for the acknowledgement only;
                # reusing it as the answer deadline is merely a sensible choice.
                async with asyncio_timeout(DEVICE_CONFIGURATION_REQUEST_TIMEOUT):
                    while True:
                        answer = await pending
                        if matches is None or matches(answer):
                            return answer
                        logger.debug(
                            "Discarding cEMI frame not answering the request: %s",
                            answer,
                        )
                        pending = asyncio.get_running_loop().create_future()
                        self._pending = pending
            except asyncio.TimeoutError:
                raise CommunicationError(
                    f"No answer to {cemi.code} within "
                    f"{DEVICE_CONFIGURATION_REQUEST_TIMEOUT} seconds."
                ) from None
            except asyncio.CancelledError:
                # A cancelled task cancels the future it awaits as well, so
                # only a closed connection tells that `_stop()` was the one
                # failing the request; everything else is task cancellation.
                if pending.cancelled() and self.communication_channel is None:
                    raise CommunicationError(
                        "Device management connection was closed."
                    ) from None
                raise
            finally:
                self._pending = None

    def _cemi_received(self, raw_cemi: bytes) -> None:
        """Handle a cEMI frame the server sent."""
        try:
            cemi = CEMIFrame.from_knx(raw_cemi)
        except (CouldNotParseCEMI, UnsupportedCEMIMessage, ValueError) as err:
            logger.warning("Could not parse received cEMI frame: %s", err)
            return
        except Exception:  # pylint: disable=broad-exception-caught
            # Last-resort guard: this runs in the transport's datagram
            # callback, where an unforeseen parsing bug must not escape.
            logger.exception("Unexpected error parsing cEMI frame: %s", raw_cemi.hex())
            return

        # Of what a server sends, M_PropInfo.ind is the only message that is
        # not an answer to a request. The cEMI Transport Layer indications
        # would be the others, but xknx does not know those message codes.
        if cemi.code is CEMIMessageCode.M_PROP_INFO_IND:
            if self.indication_callback is not None:
                try:
                    self.indication_callback(cemi)
                except Exception:  # pylint: disable=broad-exception-caught
                    logger.exception("Unexpected error in indication_callback")
            return
        if self._pending is not None and not self._pending.done():
            self._pending.set_result(cemi)
            return
        logger.debug("Received an unexpected cEMI frame: %s", cemi)

    ####################
    #
    # PROPERTIES
    #
    ####################

    async def read_property(
        self,
        object_type: ResourceObjectType,
        property_id: ResourcePropertyId | int,
        object_instance: int = 1,
        number_of_elements: int = 1,
        start_index: int = 1,
    ) -> bytes:
        """
        Read a Property of one of the server's own Interface Objects.

        Raise CommunicationError when the server reports an error instead.
        """
        property_info = CEMIMPropInfo(
            object_type=object_type,
            object_instance=object_instance,
            property_id=property_id,
            number_of_elements=number_of_elements,
            start_index=start_index,
        )
        answer = await self.request(
            CEMIFrame(
                code=CEMIMessageCode.M_PROP_READ_REQ,
                data=CEMIMPropReadRequest(property_info=property_info),
            ),
            matches=lambda frame: (
                isinstance(frame.data, CEMIMPropReadResponse)
                and _same_property(frame.data.property_info, property_info)
            ),
        )
        # `matches` only accepts a CEMIMPropReadResponse for this property
        assert isinstance(answer.data, CEMIMPropReadResponse)
        if (error_code := answer.data.error_code) is not None:
            raise CommunicationError(
                f"Reading the property failed: {_format_error_code(error_code)}"
            )
        return answer.data.data

    async def write_property(
        self,
        object_type: ResourceObjectType,
        property_id: ResourcePropertyId | int,
        data: bytes,
        object_instance: int = 1,
        number_of_elements: int = 1,
        start_index: int = 1,
    ) -> None:
        """
        Write a Property of one of the server's own Interface Objects.

        Raise CommunicationError when the server reports an error.
        """
        property_info = CEMIMPropInfo(
            object_type=object_type,
            object_instance=object_instance,
            property_id=property_id,
            number_of_elements=number_of_elements,
            start_index=start_index,
        )
        answer = await self.request(
            CEMIFrame(
                code=CEMIMessageCode.M_PROP_WRITE_REQ,
                data=CEMIMPropWriteRequest(property_info=property_info, data=data),
            ),
            matches=lambda frame: (
                isinstance(frame.data, CEMIMPropWriteResponse)
                and _same_property(frame.data.property_info, property_info)
            ),
        )
        # `matches` only accepts a CEMIMPropWriteResponse for this property
        assert isinstance(answer.data, CEMIMPropWriteResponse)
        if (error_code := answer.data.error_code) is not None:
            raise CommunicationError(
                f"Writing the property failed: {_format_error_code(error_code)}"
            )


class UDPDeviceManagementConnection(_DeviceManagementConnection):
    """
    A KNXnet/IP device management connection over UDP.

    UDP frames are acknowledged: every received DeviceConfigurationRequest
    is answered with a DeviceConfigurationAck and its sequence counter is
    tracked, and a sent request that stays unacknowledged for
    DEVICE_CONFIGURATION_REQUEST_TIMEOUT (10 seconds) is repeated
    DEVICE_CONFIGURATION_REQUEST_REPETITIONS (3) times and then terminates
    the connection, as KNX v01.07.03 - Device Management 03.08.03 - §2.3.2
    requires.
    """

    __slots__ = (
        "_device_management",
        "local_ip",
        "local_port",
        "route_back",
    )

    transport: UDPTransport

    def __init__(
        self,
        gateway_ip: str,
        gateway_port: int,
        local_ip: str,
        local_port: int = 0,
        route_back: bool = False,
        indication_callback: Callable[[CEMIFrame], None] | None = None,
    ) -> None:
        """Initialize UDPDeviceManagementConnection class."""
        self.local_ip = local_ip
        self.local_port = local_port
        self.route_back = route_back
        self._device_management: DeviceManagement | None = None
        super().__init__(
            gateway_ip=gateway_ip,
            gateway_port=gateway_port,
            indication_callback=indication_callback,
        )

    def _init_transport(self) -> None:
        """Initialize transport."""
        self.transport = UDPTransport(
            local_addr=(self.local_ip, self.local_port),
            remote_addr=(self.gateway_ip, self.gateway_port),
            multicast=False,
        )

    async def _setup_connection(self) -> None:
        """Set the local HPAI used for the control and data endpoint."""
        if self.route_back:
            self.local_hpai = HPAI()
            return
        local_addr, local_port = self.transport.getsockname()
        self.local_hpai = HPAI(ip_addr=local_addr, port=local_port)

    def _start_receiving(self) -> None:
        """Start acknowledging and handling requests the server sends."""
        assert self.communication_channel is not None
        self._device_management = DeviceManagement(
            transport=self.transport,
            communication_channel=self.communication_channel,
            cemi_received_callback=self._cemi_received,
            data_endpoint=self._data_endpoint_addr,
        )
        self._device_management.start()

    def _stop_receiving(self) -> None:
        """Stop acknowledging and handling requests the server sends."""
        if self._device_management is not None:
            self._device_management.stop()
            self._device_management = None

    async def _send_request(self, cemi: CEMIFrame) -> None:
        """Send a request, repeating it while it stays unacknowledged."""
        if (channel := self.communication_channel) is None:
            raise CommunicationError("No active device management connection.")

        raw_cemi = cemi.to_knx()
        # A repetition keeps the sequence counter of the frame it repeats.
        for attempt in range(DEVICE_CONFIGURATION_REQUEST_REPETITIONS + 1):
            device_configuration = DeviceConfiguration(
                transport=self.transport,
                data_endpoint=self._data_endpoint_addr,
                device_configuration_request=DeviceConfigurationRequest(
                    communication_channel_id=channel,
                    sequence_counter=self.sequence_number,
                    raw_cemi=raw_cemi,
                ),
                timeout_in_seconds=DEVICE_CONFIGURATION_REQUEST_TIMEOUT,
            )
            await device_configuration.start()
            answered = (
                # The acknowledgement went missing, but the answer arrived -
                # so the server did accept the request.
                self._pending is not None
                and self._pending.done()
                and not self._pending.cancelled()
            )
            if device_configuration.success or answered:
                self.sequence_number = self.sequence_number + 1 & 0xFF
                return
            logger.debug(
                "DeviceConfigurationRequest was not acknowledged (attempt %s of %s%s).",
                attempt + 1,
                DEVICE_CONFIGURATION_REQUEST_REPETITIONS + 1,
                ""
                if device_configuration.response_status_code is None
                else f"; error status {device_configuration.response_status_code.name}",
            )

        # Repeated to no avail, so the connection is terminated as required.
        await self.disconnect()
        raise CommunicationError(
            "DeviceConfigurationRequest was not acknowledged after "
            f"{DEVICE_CONFIGURATION_REQUEST_REPETITIONS} repetitions. Disconnected."
        )


class TCPDeviceManagementConnection(_DeviceManagementConnection):
    """
    A KNXnet/IP device management connection over TCP.

    TCP frames are not acknowledged: no DeviceConfigurationAck is sent and a
    received one is ignored (KNX v01.07.03 - Device Management 03.08.03 -
    §2.3.2), and sequence counters are not evaluated (KNX v01.06.02 - Core
    03.08.02 - §8.4.3.4.1). The transport reports a lost TCP connection,
    which ends the device management connection.
    """

    __slots__ = ("_receive_callback",)

    transport: TCPTransport

    def __init__(
        self,
        gateway_ip: str,
        gateway_port: int,
        indication_callback: Callable[[CEMIFrame], None] | None = None,
    ) -> None:
        """Initialize TCPDeviceManagementConnection class."""
        self._receive_callback: KNXIPTransport.Callback | None = None
        super().__init__(
            gateway_ip=gateway_ip,
            gateway_port=gateway_port,
            indication_callback=indication_callback,
        )
        # TCP always uses 0.0.0.0:0
        self.local_hpai = HPAI(protocol=HostProtocol.IPV4_TCP)

    def _init_transport(self) -> None:
        """Initialize transport."""
        self.transport = TCPTransport(
            remote_addr=(self.gateway_ip, self.gateway_port),
            connection_lost_cb=self._transport_connection_lost,
        )

    def _transport_connection_lost(self) -> None:
        """Handle the TCP connection being lost. Callback of the transport."""
        logger.info("Device management TCP connection was lost.")
        self._connection_lost()

    async def _setup_connection(self) -> None:
        """Set the local HPAI used for the control and data endpoint."""
        self.local_hpai = HPAI(protocol=HostProtocol.IPV4_TCP)

    def _start_receiving(self) -> None:
        """Start handling requests the server sends. TCP is not acknowledged."""
        self._receive_callback = self.transport.register_callback(
            self._request_received,
            [KNXIPServiceType.DEVICE_CONFIGURATION_REQUEST],
        )

    def _stop_receiving(self) -> None:
        """Stop handling requests the server sends."""
        if self._receive_callback is not None:
            self.transport.unregister_callback(self._receive_callback)
            self._receive_callback = None

    def _request_received(
        self, knxipframe: KNXIPFrame, source: HPAI, _transport: KNXIPTransport
    ) -> None:
        """Handle an incoming DeviceConfigurationRequest."""
        if not isinstance(knxipframe.body, DeviceConfigurationRequest):
            return
        if knxipframe.body.communication_channel_id != self.communication_channel:
            logger.debug(
                "Received DeviceConfigurationRequest for another communication "
                "channel than %s. Discarding frame: %s",
                self.communication_channel,
                knxipframe.body,
            )
            return
        # No acknowledgement, and the sequence counter is not evaluated.
        self._cemi_received(knxipframe.body.raw_cemi)

    async def _send_request(self, cemi: CEMIFrame) -> None:
        """Send a request. TCP is reliable, so it is not acknowledged."""
        if (channel := self.communication_channel) is None:
            raise CommunicationError("No active device management connection.")
        self.transport.send(
            KNXIPFrame.init_from_body(
                DeviceConfigurationRequest(
                    communication_channel_id=channel,
                    sequence_counter=self.sequence_number,
                    raw_cemi=cemi.to_knx(),
                )
            )
        )
        self.sequence_number = self.sequence_number + 1 & 0xFF


class SecureDeviceManagementConnection(TCPDeviceManagementConnection):
    """A KNXnet/IP device management connection over an IP Secure session."""

    __slots__ = ("_device_authentication_password", "_user_id", "_user_password")

    transport: SecureSession

    def __init__(
        self,
        gateway_ip: str,
        gateway_port: int,
        user_id: int,
        user_password: str,
        device_authentication_password: str | None = None,
        indication_callback: Callable[[CEMIFrame], None] | None = None,
    ) -> None:
        """Initialize SecureDeviceManagementConnection class."""
        self._device_authentication_password = device_authentication_password
        self._user_id = user_id
        self._user_password = user_password
        super().__init__(
            gateway_ip=gateway_ip,
            gateway_port=gateway_port,
            indication_callback=indication_callback,
        )

    def _init_transport(self) -> None:
        """Initialize transport."""
        self.transport = SecureSession(
            remote_addr=(self.gateway_ip, self.gateway_port),
            user_id=self._user_id,
            user_password=self._user_password,
            device_authentication_password=self._device_authentication_password,
            connection_lost_cb=self._transport_connection_lost,
        )
