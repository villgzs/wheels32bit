"""DIDL-Lite (Digital Item Declaration Language) tools for Python."""

from didl_lite import didl_lite  # noqa: F401

__version__ = "1.5.1"
